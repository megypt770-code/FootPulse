# FootPulse — Validation checklist

## 2.18.0

- Checked Euro search variants, provider mapping, league follow and display activation, legacy preference migration and Arabic WE SC alias in JVM checks.
- Re-ran stadium, H2H and Cairo calendar checks. Verified build and certificate compatibility with 2.17.0.
- Android device visual and installation testing remain pending.

## 2.17.0

- Reviewed the home rendering path to confirm every fixture loaded for the selected date goes into its competition group.
- Verified the build and matching 2.16.0 certificate. Re-ran featured fixture, stadium, H2H and Cairo date checks.
- Android device visual and installation testing remain pending.

## 2.16.0

- Verified Arabic and English club names, alias search and provider-name fallback in JVM checks.
- Re-ran featured fixture, stadium, H2H and Cairo calendar checks.
- Verified package version and certificate match with 2.15.0. Device visual and installation testing remain pending.

## 2.15.0

- Built the APK and verified the package, launch activity, packaged hero artwork and signer compatibility with 2.14.0.
- Checked featured fixture selection for upcoming, live, historical and empty dates.
- Re-ran venue, completed H2H results and tally, home filter, Cairo time and month alignment checks.
- Android device installation and visual testing remain pending.

## 2.14.0

- Verified stadium, kickoff, past-only H2H results, the 21/2/0 tally and home filter with the live FotMob match-page payload.
- Verified Saturday-first month alignment, release archive integrity and signer compatibility with 2.13.0.
- Android device UI testing remains pending.

## 2.13.0

- Compiled Java and Android resources, verified APK integrity, version and the 2.12.0 signing certificate.
- Ran the isolated club aliases, events, statistics labels and Cairo-time smoke tests.
- An Android device visual comparison and notification delivery during a live fixture remain pending.

## 2.12.0

- Compiled Java and Android resources, built the APK, and verified the manifest, ZIP integrity and APK v2/v3 signatures.
- Ran isolated JVM checks for Arabic club aliases, event/card classification, Arabic statistics and Cairo winter/summer offsets.
- The APK is signed with a new test certificate. Updating an existing 2.11.0 installation requires the 2.11.0 signing key.
- On Android, verify that switching dates removes leagues with no listed fixtures, and returning to a tab restores date and scroll position.
- In Following, search in Arabic and English for Zamalek, Manchester and Real Madrid. Follow a result and reopen the app to verify persistence.
- On a covered live match, verify the goal and card notifications while locked, live statistics, the confirmed TV listings and correct navigation from the notification. Compare actual screenshots with the supplied design in both languages. These device and live-source checks remain pending.

## 2.11.0

- Parsed broadcast listings from public FotMob, FilGoal and Yallakora pages. Checked wrong ID, team, date and kickoff rejection.
- Matched the same Barcelona fixture from FotMob with two independent schedule pages in summer, and matched the Egypt Cup fixture using the FotMob team names.
- Verified APK integrity, package, version and signer compatibility with 2.10.0. Android device testing remains pending.

## 2.10.0

- Compiled Java and Android resources. Checked archive integrity, alignment, Android package metadata, and APK v2/v3 signatures.
- The APK uses a test signer different from 2.9.0. An in-place update requires the original 2.9.0 signer.
- Android device and emulator testing remains pending.

## Statistics, lineups and Middle East broadcasters

- Parsed the real Champions League Qualification pages for 2026/2027 and 2023/2024, including 37 current player categories and 29 team categories. Checked both seasons’ full scoring rankings against their separate FotMob data URLs.
- Confirmed current player statistics for the Champions League and Egyptian Premier League.
- Validated starting player portraits, ratings and match markers using the archived Arsenal–Liverpool match on 4 February 2024.
- Verified Egypt broadcast listings for Egypt–South Africa and regional listings for Chelsea–Leeds. Tested rejection when kickoff and fixture details differ. Broadcast schedules come from Live Soccer TV.
- Built and signature-checked the APK against 2.6.0. Android device and emulator testing remains pending.

## FotMob competition and archive migration

- Validated the public FotMob fixture payload for all 30 listed competitions.
- Validated season selection, an archived Premier League fixture and its exact historic match ID, score, lineups and statistics.
- Confirmed FotMob news feed parsing and that match and competition data remain inside the app.
- Built the APK and verified the signer against 2.5.0. Mobile visual testing remains pending.

## FotMob Egyptian football

- Parsed 190 Egyptian Premier League fixtures, 20 standings rows and 16 Egypt Cup fixtures from the public competition pages.
- Validated a real Al Ahly result with both starting lineups, statistics and events, and real Egypt Cup goals.
- Checked local Cairo date selection and rejection of a detail response for a different match.
- Built the new launcher resources and compared the APK signature with 2.4.0. Device UI testing remains pending.

## Match home and Live Score

- Compiled the updated activity, drawables and shared match cards into the signed Android APK.
- Confirmed package version and signer compatibility with 2.3.0.
- Re-ran the existing football fixture, formation and score parsing checks.
- Device screenshots and touch testing remain pending.

## Match centre and Champions League

- Decoded 18 ESPN Champions League fixtures from two matchdays and checked the competition badge and standings endpoints.
- Decoded real starting elevens from Premier League and Champions League match summaries, including 3-4-2-1, 4-3-3, 4-4-2 and 4-2-3-1.
- Checked final score and event extraction, and verified that a missing formation position falls back to the roster list.
- Compiled Android resources and DEX. Device and emulator visual testing remains pending.

## Build checks (completed)

- Compiled and linked Android resources with AAPT2 and Android SDK 35.
- Compiled all Java source with JDK 17 and generated DEX using D8 (minSdk 26).
- Checked APK archive integrity and alignment, verified v2 and v3 signatures, and confirmed package, version, launcher, and permissions.

## Provider and parser checks

- Fetched and parsed actual responses from FilGoal's public article index, BBC Sport and The Guardian. Checked publication dates, HTTPS story links and thumbnails.
- FilGoal RSS returned HTTP 403 with a discontinued-service notice. The article index and an individual article returned HTTP 200.
- Checked ESPN's Premier League scoreboard and its timestamps, including kickoff dates that omit seconds. Its Egyptian league scoreboard request returned HTTP 400 for the tested date.
- The APK is signed using the 2.1.0 signing certificate. No Android device or emulator was attached for UI testing.

## Previous source checks

- All Java source files parsed successfully with Java Compiler API (syntax-only).
- All manifest, layout, vector and widget XML files parsed successfully.
- Source archive created and ZIP integrity checked.
- No ad / analytics / billing package dependencies in app Gradle file.

## Device acceptance tests (pending)

1. Open with Android Studio (JDK 17+, Android SDK 35) and run `assembleDebug` to reproduce the IDE build.
2. Install and launch on Android 8+, then test Android 13+ POST_NOTIFICATIONS permission.
3. Verify no crash after language selection and theme change; confirm RTL and LTR layouts.
4. Check 7-day strip navigation, calendar, all/live/followed filters and league collapse.
5. Pin a league and verify it appears before others on home and in Following.
6. Under Settings, enable/disable available competitions; verify that results reflect selected leagues after reloading.
7. Open a fixture; test Summary, Timeline, Stats, Lineups, H2H, Table tabs. Unavailable upstream values must show honest empty states, not fabricated stats.
8. Check player/team badges load from HTTPS when online; images should have placeholders offline.
9. Tap a team name or logo to open TeamActivity; check following, fixture list, and team identification across leagues.
10. Open league details, change dates, view table and news. Tap a team row and a match.
11. Test news list, headline image and in-app story summary.
12. Add widget to home screen. Open the app and refresh today's data, then verify widget snapshot changes; it does not promise real-time background refresh.
13. Enable alerts, follow a team, and verify JobScheduler scheduling after any future score changes; expect delays under Android Doze or battery restrictions.
14. Turn off Wi-Fi and mobile data. Previously cached responses may display; otherwise empty states are acceptable.
15. Check manifest, dependency tree, and network monitor for trackers/ad modules; there are no such runtime dependencies in source.
16. Confirm that updating an earlier FootPulse install requires the same signing key.

## Known limitations

- FotMob public pages may return missing data, empty fixtures or change payload format.
- No xG / shot maps / player ratings / audio commentary / verified 500+ competition coverage.
- No 1:1 FotMob branding or copyrighted interface assets.
- The signed APK has not been run on a device or emulator in this environment.
