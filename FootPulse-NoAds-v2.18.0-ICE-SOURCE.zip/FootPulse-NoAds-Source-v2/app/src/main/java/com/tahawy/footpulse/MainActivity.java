package com.tahawy.footpulse;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.graphics.Color;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.content.res.ColorStateList;
import java.time.Instant;
import java.time.ZoneId;
import android.view.*;
import android.widget.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private LinearLayout app, body;
    private ScrollView contentScroll;
    private int renderedPage = -1;
    private final int[] pageScroll = new int[7];
    private boolean settingsOpen;
    private boolean scoresOpen;
    private String scoreLeague = "";
    private LinearLayout scoreResults;
    private ScoresStyle matchStyle;
    private Runnable clubSearch;
    private String clubQuery = "";
    private EditText clubInput;
    private LinearLayout clubList;
    private boolean editLeagues;
    private String leagueQuery = "";
    private final Map<String, Match> nextFixtures = new HashMap<>();
    private final Set<String> pendingFixtures = new HashSet<>();
    private final Map<String, Long> checkedFixtures = new HashMap<>();
    private final ExecutorService fixtureLoader = Executors.newFixedThreadPool(3);
    private List<Match> games=new ArrayList<>();
    private List<Match> aheadGames=new ArrayList<>();
    private LocalDate day=LocalDate.now(ScoreRepository.CAIRO);
    private int tab=0; // 0 matches, 2 leagues, 3 following, 4 more
    private int filter=0; // 0 all, 1 live, 2 followed
    private String search="";
    private boolean busy=false, active=false;
    private int requestSerial=0;
    private Set<String> requestedLeagues = Collections.emptySet();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable autoRefresh=new Runnable(){@Override public void run(){if(active&&tab==0)loadGames(false);if(active)handler.postDelayed(this,90000);}};

    @Override public void onCreate(Bundle state){super.onCreate(state);
        Settings.enableEgyptOnUpgrade(this);
        Settings.enablePreviouslyFollowedLeagues(this);
        int requestedTab = getIntent().getIntExtra("openTab",0);
        if (requestedTab >= 0 && requestedTab <= 4) tab = requestedTab;
        if (state != null) {
            scoresOpen = state.getBoolean("scoresOpen");
            tab = state.getInt("mainTab", 0);
            if (tab == 1) tab = 0;
            int[] savedScroll = state.getIntArray("pageScroll");
            if (savedScroll != null && savedScroll.length == pageScroll.length)
                System.arraycopy(savedScroll, 0, pageScroll, 0, pageScroll.length);
            day = LocalDate.ofEpochDay(state.getLong("scoreDay", LocalDate.now(ScoreRepository.CAIRO).toEpochDay()));
            filter = state.getInt("scoreFilter", 0);
            scoreLeague = state.getString("scoreLeague", "");
            search = state.getString("scoreSearch", "");
        }
        showTab();
        loadGames(false);
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        rememberScroll();
        state.putInt("mainTab",tab);
        state.putIntArray("pageScroll",pageScroll);
        state.putBoolean("scoresOpen",scoresOpen);
        state.putLong("scoreDay",day.toEpochDay());
        state.putInt("scoreFilter",filter);
        state.putString("scoreLeague",scoreLeague);
        state.putString("scoreSearch",search);
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        int target = intent.getIntExtra("openTab",0);
        if (target >= 0 && target <= 4) selectTab(target);
    }

    @Override protected void onResume(){super.onResume();active=true;handler.removeCallbacks(autoRefresh);handler.postDelayed(autoRefresh,90000);if(app!=null)showTab();if(!requestedLeagues.equals(Settings.enabledLeagues(this)))loadGames(false);if(tab==3) refreshFollowing();}
    @Override protected void onPause(){active=false;handler.removeCallbacks(autoRefresh);super.onPause();}

    private String t(String ar, String en) {
        return Settings.t(this, ar, en);
    }

    private String[] navigationLabels() {
        return new String[]{t("المباريات","Matches"), "",
            t("الدوريات","Leagues"), t("المتابعة","Following"), t("المزيد","More")};
    }

    private void selectTab(int target) {
        if (target == 1) target = 0;
        if (tab == target && !settingsOpen) return;
        tab = target;
        settingsOpen = false;
        editLeagues = false;
        showTab();
        if (tab == 3) refreshFollowing();
    }

    private void rememberScroll() {
        if (contentScroll != null && renderedPage >= 0 && !((renderedPage == 0 || renderedPage == 6) && busy)) pageScroll[renderedPage] = contentScroll.getScrollY();
    }

    private void showTab() {
        int page = settingsOpen ? 5 : tab == 0 && scoresOpen ? 6 : tab;
        scoreResults = null;
        matchStyle = new ScoresStyle(this);
        rememberScroll();
        int scrollY = pageScroll[page];
        renderedPage = page;
        U.systemBar(this);
        if (tab == 0 && !scoresOpen && Settings.dark(this)) getWindow().setStatusBarColor(0xFF125FB4);
        app = U.col(this);
        app.setLayoutDirection(Settings.ar(this) ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        app.setBackground(tab == 0 && !scoresOpen ? U.homeBackdrop(this) : U.backdrop(this));
        setContentView(app);
        if (tab != 0) addToolbar();
        else if (scoresOpen) addLiveScoreHeader();
        else addFootballHeader();
        contentScroll = U.scroll(this);
        body = U.col(this);
        int horizontal = tab == 0 ? 9 : tab == 3 ? 13 : 8;
        U.pad(body, horizontal, 8, horizontal, 20);
        contentScroll.addView(body);
        app.addView(contentScroll,new LinearLayout.LayoutParams(-1,0,1));
        app.addView(U.navigation(this,tab,this::selectTab));
        switch (tab) {
            case 0:
                if (scoresOpen) showScores();
                else showMatchHome();
                break;
            case 2: showLeagues(); break;
            case 3: showFollowing(); break;
            default: if (settingsOpen) showSettings(); else showMore(); break;
        }
        ScrollView current = contentScroll;
        if (scrollY > 0 && !(busy && tab == 0)) current.post(() -> current.scrollTo(0, scrollY));
    }

    private View action(int icon, String label, Runnable run) {
        return U.roundAction(this,icon,label,run);
    }

    private void addToolbar() {
        LinearLayout bar = U.row(this);
        U.pad(bar, 17, 3, 11, 3);
        if (settingsOpen) {
            View back = action(R.drawable.ui_back, t("رجوع","Back"), this::closeSettings);
            if (Settings.ar(this)) back.setScaleX(-1);
            bar.addView(back, U.lp(this,44,48));
        }
        String title = settingsOpen ? t("الإعدادات","Settings") : tab == 3 ? t("متابعة الأندية","Follow clubs") : navigationLabels()[tab];
        TextView name = U.txt(this,title,24,true,U.text(this));
        name.setSingleLine();
        name.setEllipsize(TextUtils.TruncateAt.END);
        bar.addView(name,new LinearLayout.LayoutParams(0,U.dp(this,53),1));
        if (tab == 3) {
            bar.addView(U.icon(this,R.drawable.ui_brand,34,U.accent(this)));
            bar.addView(new View(this),U.lp(this,5,1));
            FrameLayout plus = U.roundAction(this,R.drawable.ui_plus,t("إضافة نادٍ","Add a club"),this::openTeamPicker);
            plus.setBackground(U.selected(this));
            ((ImageView) plus.getChildAt(0)).setColorFilter(U.selectedInk());
            bar.addView(plus,U.lp(this,42,42));
        }
        app.addView(bar);
    }

    private TextView textAction(String label, Runnable run) {
        TextView view = U.txt(this, label, 14, true, U.accent(this));
        U.pad(view, 10, 0, 10, 0);
        view.setMinimumHeight(U.dp(this,44));
        view.setOnClickListener(v -> run.run());
        return view;
    }

    private Locale uiLocale() {
        return Settings.ar(this) ? new Locale("ar","EG") : Locale.ENGLISH;
    }

    private void showCalendar() {
        new MatchCalendar(this,day,busy ? null : games,target -> {
            scoresOpen = false;
            boolean sameDay = day.equals(target);
            selectDate(target);
            if (sameDay) showTab();
        },() -> {
            if (!requestedLeagues.equals(Settings.enabledLeagues(this))) loadGames(false);
        }).show();
    }

    private void selectDate(LocalDate target) {
        if (tab != 0) selectTab(0);
        if (day.equals(target)) return;
        day = target;
        games = new ArrayList<>();
        aheadGames = new ArrayList<>();
        renderedPage = -1;
        pageScroll[0] = pageScroll[6] = 0;
        scoreLeague = "";
        loadGames(false);
    }

    private void addFootballHeader() {
        LinearLayout header = U.row(this);
        U.pad(header,10,7,10,6);
        header.addView(roundAction(R.drawable.ui_dots,t("خيارات فوت بلس","FootPulse options"),this::homeOptions),
            U.lp(this,43,43));
        LinearLayout wordmark = U.row(this);
        wordmark.setGravity(Gravity.CENTER);
        wordmark.addView(U.icon(this,R.drawable.ui_brand,34,U.text(this)));
        TextView brand = U.txt(this,t("فوت بلس","FootPulse"),23,true,U.text(this));
        U.pad(brand,4,0,4,0);
        brand.setSingleLine();
        wordmark.addView(brand);
        header.addView(wordmark,U.weight(this,1));
        header.addView(roundAction(R.drawable.ui_search,t("بحث عن مباراة","Search matches"),() -> openScores("",0)),
            U.lp(this,43,43));
        header.addView(new View(this),U.lp(this,5,1));
        View calendar = roundAction(R.drawable.ui_calendar,t("التقويم","Calendar"),this::showCalendar);
        calendar.setOnLongClickListener(v -> { loadGames(true); return true; });
        header.addView(calendar,U.lp(this,43,43));
        FrameLayout masthead = new FrameLayout(this);
        ImageView football = new ImageView(this);
        football.setImageResource(R.drawable.ice_football_hero);
        football.setScaleType(ImageView.ScaleType.CENTER_CROP);
        football.setAlpha(.22f);
        football.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        masthead.addView(football,new FrameLayout.LayoutParams(-1,-1));
        masthead.addView(header,new FrameLayout.LayoutParams(-1,-1));
        app.addView(masthead,U.lp(this,-1,75));
    }

    private void homeOptions() {
        String[] options = {t("تحديث المباريات","Refresh matches"),t("التنبيهات","Notifications"),t("الإعدادات","Settings")};
        U.dialog(this).setTitle(t("فوت بلس","FootPulse")).setItems(options,(dialog,which) -> {
            if (which == 0) loadGames(true);
            else if (which == 1) notificationOptions();
            else {
                tab = 4;
                settingsOpen = true;
                showTab();
            }
        }).show();
    }

    private void notificationOptions() {
        U.dialog(this).setTitle(t("التنبيهات","Notifications")).setMessage(notificationSummary())
            .setPositiveButton(Settings.alerts(this) ? t("إيقاف","Turn off") : t("تفعيل","Enable"),
                (dialog,which) -> toggleAlerts())
            .setNegativeButton(t("رجوع","Back"),null).show();
    }

    private FrameLayout roundAction(int icon, String label, Runnable callback) {
        return U.roundAction(this,icon,label,callback);
    }

    private void showMatchHome() {
        addScoreDays(body,false);
        U.space(body,13);
        Map<String,List<Match>> groups = new LinkedHashMap<>();
        for (Match match : games) {
            groups.computeIfAbsent(match.leagueId,ignored -> new ArrayList<>()).add(match);
        }
        renderGroups(body,groups,true);
    }

    private void renderGroups(LinearLayout parent,Map<String,List<Match>> groups,boolean matchday) {
        if (groups.isEmpty()) {
            matchEmpty(parent);
            return;
        }
        ScoresCards cards = new ScoresCards(this,matchStyle);
        int lookups = 0;
        for (Map.Entry<String,List<Match>> group : groups.entrySet()) {
            LinearLayout heading = U.row(this);
            U.pad(heading,11,8,11,8);
            heading.setBackground(matchday ? U.matchdayHeading(this) : U.glass(this,12));
            if (matchday) heading.addView(U.logo(this,FotMob.leagueLogo(group.getKey()),25));
            else heading.addView(U.icon(this,R.drawable.ui_shield,22,U.accent(this)));
            TextView title = U.txt(this,League.byId(group.getKey()).name(this),17,true,U.text(this));
            U.pad(title,8,0,8,0);
            heading.addView(title,U.weight(this,1));
            if (matchday) heading.setOnClickListener(v -> openLeague(group.getKey()));
            parent.addView(heading,U.lp(this,-1,43));
            if (!matchday) {
                View edge = new View(this);
                edge.setBackground(new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{0x0055C7FF,0xE855C7FF,0x0055C7FF}));
                parent.addView(edge,U.lp(this,-1,1));
                U.space(parent,7);
            }
            for (Match match : group.getValue()) {
                boolean showTv = !match.isLive() && Upcoming.open(match) && lookups < 10;
                if (showTv) lookups++;
                View card = matchday ? cards.matchday(match,Settings.condensed(this),showTv)
                    : cards.fixture(match,Settings.condensed(this),showTv,false);
                card.setOnLongClickListener(v -> { chooseFollow(match); return true; });
                parent.addView(card,U.lp(this,-1,-2));
                U.space(parent,7);
            }
            U.space(parent,6);
        }
    }

    private void openScores(String league, int kind) {
        scoresOpen = true;
        scoreLeague = league;
        filter = kind;
        search = "";
        showTab();
    }

    private void closeScores() {
        scoresOpen = false;
        showTab();
    }

    private void addLiveScoreHeader() {
        LinearLayout header = U.row(this);
        U.pad(header,16,8,16,9);
        View back = roundAction(R.drawable.ui_back,t("رجوع","Back"),this::closeScores);
        if (Settings.ar(this)) back.setScaleX(-1);
        header.addView(back,U.lp(this,44,44));
        TextView title = U.txt(this,t("النتائج المباشرة","Live Score"),21,true,matchStyle.ink);
        title.setGravity(Gravity.CENTER);
        header.addView(title,U.weight(this,1));
        header.addView(roundAction(R.drawable.ui_dots,t("خيارات النتائج","Score options"),this::scoreOptions),
            U.lp(this,44,44));
        app.addView(header);

        LinearLayout controls = U.row(this);
        U.pad(controls,16,0,16,8);
        LinearLayout searchField = U.row(this);
        searchField.setBackground(U.glass(this,23));
        U.pad(searchField,11,0,11,0);
        searchField.addView(U.icon(this,R.drawable.ui_search,18,matchStyle.muted));
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setTextSize(13);
        input.setTextColor(matchStyle.ink);
        input.setHintTextColor(matchStyle.muted);
        input.setHint(t("ابحث عن فريق","Search team"));
        input.setText(search);
        input.setBackgroundColor(Color.TRANSPARENT);
        U.pad(input,7,0,7,0);
        searchField.addView(input,new LinearLayout.LayoutParams(0,U.dp(this,44),1));
        controls.addView(searchField,new LinearLayout.LayoutParams(0,U.dp(this,44),1));
        appendChipGap(controls);
        controls.addView(roundAction(R.drawable.ui_filter,t("فلترة المباريات","Filter matches"),this::chooseScoreFilter),
            U.lp(this,44,44));
        app.setFocusableInTouchMode(true);
        app.requestFocus();
        app.addView(controls);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence value,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence value,int start,int before,int count) {
                search = value.toString();
                if (scoreResults != null) renderScoreResults();
            }
            @Override public void afterTextChanged(Editable text) {}
        });
        addScoreDays();
    }

    private void scoreOptions() {
        String[] actions = {t("التقويم","Calendar"),t("تحديث النتائج","Refresh scores"),
            matchStyle.dark ? t("الوضع الفاتح","Light mode") : t("الوضع الداكن","Dark mode")};
        U.dialog(this).setItems(actions,(dialog,which) -> {
            if (which == 0) showCalendar();
            else if (which == 1) loadGames(true);
            else {
                Settings.dark(this,!matchStyle.dark);
                showTab();
            }
        }).show();
    }

    private void chooseScoreFilter() {
        String[] labels = {t("الكل","All matches"),t("المباشر فقط","Live only"),t("الفرق التي أتابعها","Following"),
            t("القادمة","Upcoming"),t("النتائج","Results")};
        U.dialog(this).setTitle(t("فلترة المباريات","Filter matches"))
            .setSingleChoiceItems(labels,filter,(dialog,which) -> {
                filter = which;
                dialog.dismiss();
                renderScoreResults();
            }).show();
    }

    private void addScoreDays() { addScoreDays(app,true); }

    private void addScoreDays(LinearLayout parent,boolean calendarButton) {
        LinearLayout strip = U.row(this);
        strip.setBackground(U.glass(this,12));
        U.pad(strip,5,4,5,4);
        LocalDate today = LocalDate.now(ScoreRepository.CAIRO);
        if (calendarButton) {
            View calendar = U.roundAction(this,R.drawable.ui_calendar,t("التقويم","Calendar"),this::showCalendar);
            calendar.setOnLongClickListener(v -> { loadGames(true); return true; });
            strip.addView(calendar,U.lp(this,43,43));
        }
        String[] labels = {t("الأمس","Yesterday"),t("اليوم","Today"),t("غدًا","Tomorrow")};
        for (int offset=-1;offset<=1;offset++) {
            LocalDate target = today.plusDays(offset);
            boolean selected = day.equals(target);
            TextView label = U.txt(this,labels[offset+1],14,true,selected ? U.selectedInk() : U.text(this));
            label.setGravity(Gravity.CENTER);
            label.setSingleLine();
            if (selected) label.setBackground(U.selected(this));
            label.setSelected(selected);
            label.setOnClickListener(v -> selectDate(target));
            strip.addView(label,new LinearLayout.LayoutParams(0,U.dp(this,43),1));
        }
        LinearLayout.LayoutParams params = U.lp(this,-1,-2);
        if (calendarButton) params.setMargins(U.dp(this,12),0,U.dp(this,12),U.dp(this,5));
        parent.addView(strip,params);
        if (day.isBefore(today.minusDays(1)) || day.isAfter(today.plusDays(1))) {
            TextView date = U.txt(this,day.format(DateTimeFormatter.ofPattern("EEEE d MMMM",uiLocale())),13,true,U.accent(this));
            date.setGravity(Gravity.CENTER);
            date.setOnClickListener(v -> showCalendar());
            parent.addView(date,U.lp(this,-1,28));
        }
    }

    private void showScores() {
        U.space(body,6);
        U.line(body);
        U.space(body,12);
        scoreResults = U.col(this);
        body.addView(scoreResults);
        renderScoreResults();
    }

    private void renderScoreResults() {
        if (scoreResults == null) return;
        scoreResults.removeAllViews();
        LinearLayout leagues = U.row(this);
        List<Match> fixtures = new ArrayList<>(games);
        if (filter == 3 && day.equals(LocalDate.now(ScoreRepository.CAIRO))) fixtures.addAll(aheadGames);
        Set<String> visibleLeagues = new LinkedHashSet<>();
        for (Match match : fixtures) visibleLeagues.add(match.leagueId);
        if (!busy && !visibleLeagues.contains(scoreLeague)) scoreLeague = "";
        leagues.addView(matchChip(R.drawable.ui_ball,t("الكل","All"),scoreLeague.isEmpty(),() -> selectScoreLeague("")));
        for (String league : visibleLeagues) {
            appendChipGap(leagues);
            addLeagueChip(leagues,league);
        }
        HorizontalScrollView chipScroll = addChipStrip(scoreResults,leagues);
        View selected = leagues.findViewWithTag("selected-league");
        if (selected != null) chipScroll.post(() ->
            chipScroll.scrollTo(Math.max(0,selected.getLeft() - chipScroll.getWidth()/3),0));
        U.space(scoreResults,12);
        Set<String> followed = Settings.matchFavorites(this);
        String query = search.trim().toLowerCase(Locale.ROOT);
        Map<String,List<Match>> byLeague = new LinkedHashMap<>();
        for (Match match : fixtures) {
            if (!scoreLeague.isEmpty() && !scoreLeague.equals(match.leagueId)) continue;
            if (filter == 1 && !match.isLive() || filter == 2 && !match.concerns(followed)) continue;
            if (filter == 3 && (match.isLive() || !Upcoming.open(match))) continue;
            if (filter == 4 && Upcoming.open(match)) continue;
            String names = match.home + " " + match.away + " " + Club.name(this,match.home) + " " +
                Club.name(this,match.away) + " " + League.byId(match.leagueId).name(this);
            if (!names.toLowerCase(Locale.ROOT).contains(query)) continue;
            byLeague.computeIfAbsent(match.leagueId,ignored -> new ArrayList<>()).add(match);
        }
        renderGroups(scoreResults,byLeague,false);
    }

    private void addLeagueChip(LinearLayout strip, String id) {
        String label = League.CHAMPIONS.equals(id) ? t("أبطال أوروبا","UEFA") : League.byId(id).name(this);
        boolean selected = id.equals(scoreLeague);
        LinearLayout chip = (LinearLayout) matchChip(R.drawable.ui_cup,label,selected,() -> selectScoreLeague(id));
        chip.removeViewAt(0);
        chip.addView(U.logo(this,FotMob.leagueLogo(id),19),0);
        if (selected) chip.setTag("selected-league");
        strip.addView(chip);
    }

    private void selectScoreLeague(String league) {
        scoreLeague = league;
        renderScoreResults();
    }

    private View matchChip(int icon,String label,boolean selected,Runnable callback) {
        LinearLayout chip = U.row(this);
        chip.setMinimumHeight(U.dp(this,40));
        U.pad(chip,9,4,12,4);
        chip.setBackground(selected ? U.selected(this) : U.glass(this,22));
        chip.addView(U.icon(this,icon,19,selected ? U.selectedInk() : matchStyle.ink));
        TextView text = U.txt(this,label,12,true,selected ? U.selectedInk() : matchStyle.ink);
        U.pad(text,6,0,0,0);
        chip.addView(text);
        chip.setSelected(selected);
        chip.setOnClickListener(v -> callback.run());
        return chip;
    }

    private void appendChipGap(LinearLayout strip) {
        strip.addView(new View(this),U.lp(this,7,1));
    }

    private HorizontalScrollView addChipStrip(LinearLayout parent,LinearLayout strip) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.addView(strip);
        parent.addView(scroll);
        return scroll;
    }

    private void matchEmpty(LinearLayout parent) {
        if (busy) {
            ProgressBar progress = new ProgressBar(this);
            progress.setIndeterminateTintList(ColorStateList.valueOf(matchStyle.dark ? matchStyle.accent : U.iceLine()));
            LinearLayout.LayoutParams params = U.lp(this,31,31);
            params.gravity = Gravity.CENTER_HORIZONTAL;
            parent.addView(progress,params);
            return;
        }
        LinearLayout card = U.col(this);
        U.pad(card,14,14,14,9);
        card.setBackground(U.glass(this,21));
        String caption = games.isEmpty() ? t("لا توجد مباريات متاحة لهذا اليوم.","No matches are available on this date.")
            : t("لا توجد مباريات مطابقة.","No matches fit the current filters.");
        TextView text = U.txt(this,caption,14,false,matchStyle.muted);
        text.setGravity(Gravity.CENTER);
        card.addView(text);
        TextView retry = textAction(t("تحديث","Refresh"),() -> loadGames(true));
        retry.setTextColor(matchStyle.dark ? matchStyle.accent : U.accent(this));
        retry.setGravity(Gravity.CENTER);
        card.addView(retry);
        if (scoresOpen && FotMob.supports(scoreLeague)) {
            String league = scoreLeague;
            TextView competition = textAction(t("صفحة البطولة","Competition page"),() -> openLeague(league));
            competition.setTextColor(matchStyle.dark ? matchStyle.accent : U.accent(this));
            competition.setGravity(Gravity.CENTER);
            card.addView(competition);
        }
        parent.addView(card);
    }

    private boolean matchesQuery(String value) {
        return value.toLowerCase(Locale.ROOT).contains(search);
    }

    private void chooseFollow(Match m){
        U.dialog(this).setTitle(Settings.t(this,"متابعة فريق","Follow a team"))
          .setItems(new String[]{(Settings.isFavorite(this,m.homeId,m.leagueId)?"★ ":"☆ ")+m.home,(Settings.isFavorite(this,m.awayId,m.leagueId)?"★ ":"☆ ")+m.away},(d,which)->{
              Settings.follow(this,which==0?m.homeId:m.awayId,which==0?m.home:m.away,m.leagueId,which==0?m.homeLogo:m.awayLogo);
              requestNotifications();showTab();
          }).show();
    }
    private void requestNotifications(){if(Build.VERSION.SDK_INT>=33 && Settings.alerts(this) && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);}
    private void openLeague(String id){Intent i=new Intent(this,LeagueActivity.class);i.putExtra("league",id);startActivity(i);}
    private void empty(String message){
        LinearLayout box=U.card(this);box.setGravity(Gravity.CENTER);U.pad(box,22,45,22,45);
        box.addView(U.icon(this, R.drawable.ui_pitch, 28, U.accent(this)));
        U.space(box, 10);
        TextView t=U.txt(this,message,14,false,U.sub(this));t.setGravity(Gravity.CENTER);box.addView(t);body.addView(box);
    }
    private void loading() {
        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminateTintList(ColorStateList.valueOf(U.accent(this)));
        LinearLayout.LayoutParams params = U.lp(this, 30, 30);
        params.gravity = Gravity.CENTER_HORIZONTAL;
        body.addView(progress, params);
        U.space(body, 9);
    }

    private void loadGames(boolean force){
        rememberScroll();
        requestedLeagues = Settings.enabledLeagues(this);
        busy = true;
        if (tab == 0 && scoresOpen && scoreResults != null && renderedPage == 6) renderScoreResults();
        else if (tab == 0) showTab();
        LocalDate queried=day;int ticket=++requestSerial;
        new Thread(()->{List<Match> result=ScoreRepository.matches(getApplicationContext(),queried,force);
           List<Match> ahead=new ArrayList<>();
           if(queried.equals(LocalDate.now(ScoreRepository.CAIRO))){boolean anyOpen=false;for(Match m:result)if(Upcoming.open(m)){anyOpen=true;break;}
               if(!anyOpen)ahead=ScoreRepository.nextOpenDay(getApplicationContext(),queried,false);}
           List<Match> lookAhead=ahead;
           runOnUiThread(()->{if(isDestroyed()||ticket!=requestSerial)return;busy=false;if(queried.equals(day)){games=result;aheadGames=lookAhead;if(queried.equals(LocalDate.now(ScoreRepository.CAIRO)))ScoreWidget.publish(this,result);if(tab==0 && scoresOpen && scoreResults!=null)renderScoreResults();else if(tab==0)showTab();else if(tab==3 && clubList!=null && clubQuery.trim().isEmpty())savedClubs(clubList);}});
        },"fetch-scores").start();
    }
    private void showLeagues() {

        LinearLayout field = U.row(this);
        field.setBackground(U.shape(U.elevated(this), 14, this));
        U.pad(field, 14, 0, 14, 0);
        field.addView(U.icon(this, R.drawable.ui_search, 20, U.text(this)));
        EditText input = new EditText(this);
        input.setTextSize(16);
        input.setTextColor(U.text(this));
        input.setHintTextColor(U.sub(this));
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setSingleLine();
        input.setHint(t("ابحث عن دوري","Find leagues"));
        input.setText(leagueQuery);
        U.pad(input, 10, 0, 10, 0);
        field.addView(input, new LinearLayout.LayoutParams(0, U.dp(this,50), 1));
        body.setFocusableInTouchMode(true);
        body.requestFocus();
        body.addView(field);
        U.space(body, 10);
        LinearLayout results = U.col(this);
        body.addView(results);
        renderLeagues(results);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence text,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence text,int start,int before,int count) {
                leagueQuery = text.toString();
                renderLeagues(results);
            }
            @Override public void afterTextChanged(Editable text) {}
        });
    }

    private void renderLeagues(LinearLayout results) {
        results.removeAllViews();
        Set<String> pinned = Settings.favoriteLeagues(this);
        String query = leagueQuery.trim().toLowerCase(Locale.ROOT);
        List<League> followed = new ArrayList<>();
        List<League> others = new ArrayList<>();
        for (League league : League.ALL) {
            if (!league.matchesQuery(query)) continue;
            (pinned.contains(league.id) ? followed : others).add(league);
        }
        if (query.isEmpty() || !followed.isEmpty()) {
            LinearLayout group = U.card(this);
            LinearLayout header = U.row(this);
            U.pad(header, 15, 4, 10, 0);
            header.addView(U.txt(this,t("المتابعة","Following"),17,true,U.text(this)), U.weight(this,1));
            header.addView(textAction(editLeagues ? t("تم","Done") : t("تعديل","Edit"), () -> {
                editLeagues = !editLeagues;
                renderLeagues(results);
            }));
            group.addView(header);
            if (followed.isEmpty()) {
                TextView hint = U.txt(this,t("أضف الدوريات بالضغط على النجمة.","Tap a star to follow a league."),13,false,U.sub(this));
                U.pad(hint, 15, 0, 15, 14);
                group.addView(hint);
            }
            for (League league : followed) group.addView(leagueRow(league, true, editLeagues, results));
            results.addView(group);
            U.space(results, 10);
        }
        if (!others.isEmpty()) {
            LinearLayout group = U.card(this);
            TextView header = U.txt(this,t("استكشف الدوريات","Explore leagues"),17,true,U.text(this));
            U.pad(header, 15, 13, 15, 8);
            group.addView(header);
            for (League league : others) group.addView(leagueRow(league, false, true, results));
            results.addView(group);
        }
        if (followed.isEmpty() && others.isEmpty() && !query.isEmpty()) {
            TextView message = U.txt(this,t("لا توجد دوريات مطابقة.","No matching leagues."),15,false,U.sub(this));
            U.pad(message, 15);
            results.addView(message);
        }
    }

    private View leagueMark(League league, int size) {
        return U.logo(this,FotMob.leagueLogo(league.id),size);
    }

    private View leagueRow(League league, boolean pinned, boolean editable, LinearLayout results) {
        LinearLayout row = U.row(this);
        row.setMinimumHeight(U.dp(this,49));
        U.pad(row, 15, 0, 8, 0);
        row.addView(leagueMark(league,24));
        TextView name = U.txt(this, league.name(this), 16, false, U.text(this));
        U.pad(name, 12, 4, 4, 4);
        row.addView(name, U.weight(this,1));
        if (editable) {
            TextView star = textAction(pinned ? "★" : "☆", () -> {
                Settings.toggleLeague(this, league.id);
                if (!requestedLeagues.equals(Settings.enabledLeagues(this))) loadGames(false);
                renderLeagues(results);
            });
            star.setContentDescription(pinned ? t("إلغاء متابعة الدوري","Unfollow league") : t("متابعة الدوري","Follow league"));
            star.setTextSize(22);
            star.setGravity(Gravity.CENTER);
            row.addView(star, U.lp(this,44,44));
        }
        row.setOnClickListener(v -> openLeague(league.id));
        return row;
    }

    private void openTeamPicker() {
        if (clubInput == null) return;
        clubInput.requestFocus();
        ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
            .showSoftInput(clubInput,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
    }

    private void showFollowing() {
        LinearLayout searchBar = U.row(this);
        searchBar.setBackground(U.glass(this,13));
        U.pad(searchBar,12,0,12,0);
        clubInput = new EditText(this);
        clubInput.setSingleLine(true);
        clubInput.setTextSize(16);
        clubInput.setTextColor(U.text(this));
        clubInput.setHintTextColor(U.sub(this));
        clubInput.setHint(t("ابحث عن نادٍ","Find a club"));
        clubInput.setBackgroundColor(Color.TRANSPARENT);
        clubInput.setText(clubQuery);
        clubInput.setInputType(InputType.TYPE_CLASS_TEXT);
        searchBar.addView(clubInput,new LinearLayout.LayoutParams(0,U.dp(this,49),1));
        searchBar.addView(U.icon(this,R.drawable.ui_search,23,U.text(this)));
        body.addView(searchBar,U.lp(this,-1,-2));
        U.space(body,9);
        clubList = U.col(this);
        body.addView(clubList,U.lp(this,-1,-2));
        clubInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence value,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence value,int start,int before,int count) {
                clubQuery = value.toString();
                updateClubs();
            }
            @Override public void afterTextChanged(Editable value) {}
        });
        clubInput.setOnFocusChangeListener((view,focused) -> { if (!focused && clubQuery.trim().isEmpty()) savedClubs(clubList); });
        updateClubs();
    }

    private void updateClubs() {
        if (clubSearch != null) handler.removeCallbacks(clubSearch);
        LinearLayout target = clubList;
        String query = clubQuery.trim();
        if (query.isEmpty()) {
            savedClubs(target);
            return;
        }
        target.removeAllViews();
        if (query.length() < 2) return;
        target.addView(U.txt(this,t("جارٍ البحث…","Searching…"),14,false,U.sub(this)),U.lp(this,-1,47));
        clubSearch = () -> fixtureLoader.execute(() -> {
            List<Club> clubs = ScoreRepository.searchClubs(getApplicationContext(),query);
            runOnUiThread(() -> {
                if (isDestroyed() || tab != 3 || target != clubList || !query.equals(clubQuery.trim())) return;
                target.removeAllViews();
                if (clubs.isEmpty()) target.addView(U.txt(this,t("لا توجد أندية بهذا الاسم","No clubs found"),14,false,U.sub(this)),U.lp(this,-1,47));
                for (Club club : clubs) addClubRow(target,club.id,club.name,club.league,FotMob.teamLogo(club.id));
            });
        });
        handler.postDelayed(clubSearch,240);
    }

    private void savedClubs(LinearLayout target) {
        target.removeAllViews();
        List<String> followed = new ArrayList<>(Settings.favorites(this));
        followed.sort(Comparator.<String>comparingLong(key -> Settings.followedAt(this,key)).reversed()
            .thenComparing(key -> Settings.teamName(this,key),String.CASE_INSENSITIVE_ORDER));
        if (followed.isEmpty()) {
            TextView empty = U.txt(this,t("ابحث عن ناديك واضغط + لمتابعته","Search for a club and tap + to follow it"),14,false,U.sub(this));
            empty.setGravity(Gravity.CENTER);
            target.addView(empty,U.lp(this,-1,62));
            return;
        }
        target.addView(U.heading(this,t("أنديتك الأخيرة","Recently followed")));
        LinearLayout recent = U.row(this);
        for (int i=0;i<Math.min(3,followed.size());i++) {
            String key = followed.get(i);
            LinearLayout pill = U.row(this);
            U.pad(pill,7,5,7,5);
            pill.setBackground(U.outlined(this,U.surface(this),i == 0 ? U.accent(this) : U.border(this),16));
            pill.addView(U.logo(this,clubLogo(key),23));
            TextView label = U.txt(this,Club.name(this,Settings.teamName(this,key)),11,true,U.text(this));
            U.pad(label,4,0,4,0);
            label.setMaxLines(2);
            label.setEllipsize(TextUtils.TruncateAt.END);
            pill.addView(label,U.weight(this,1));
            pill.setOnClickListener(v -> U.openTeam(this,teamId(key),Settings.teamName(this,key),clubLogo(key),teamLeague(key)));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,U.dp(this,40),1);
            params.setMarginEnd(U.dp(this,4));
            recent.addView(pill,params);
        }
        target.addView(recent,U.lp(this,-1,-2));
        U.space(target,11);
        for (String key : followed) addClubRow(target,teamId(key),Settings.teamName(this,key),teamLeague(key),clubLogo(key));
        Match next = null;
        for (String key : followed) {
            Match fixture = nextFixtures.get(key);
            if (fixture != null && (next == null || Upcoming.start(fixture).isBefore(Upcoming.start(next)))) next = fixture;
        }
        if (next != null) {
            target.addView(U.heading(this,t("المباراة القادمة","Next match")));
            target.addView(new ScoresCards(this,matchStyle).fixture(next,false,false,true),U.lp(this,-1,-2));
        }
        List<Match> fixtures = new ArrayList<>();
        Set<String> keys = Settings.matchFavorites(this);
        for (Match match : games) if (match.concerns(keys)) fixtures.add(match);
        if (!fixtures.isEmpty()) {
            target.addView(U.heading(this,t("مباريات التاريخ المختار","Matches on the selected date")));
            ScoresCards cards = new ScoresCards(this,matchStyle);
            for (Match fixture : fixtures) {
                target.addView(cards.result(fixture,Settings.condensed(this)),U.lp(this,-1,-2));
                U.space(target,6);
            }
        }
    }

    private String clubLogo(String key) {
        String logo = Settings.teamLogo(this,key);
        if (logo.isEmpty()) logo = knownTeamLogo(teamId(key),teamLeague(key));
        return logo.isEmpty() ? FotMob.teamLogo(teamId(key)) : logo;
    }

    private void addClubRow(LinearLayout parent,String id,String name,String league,String logo) {
        LinearLayout row = U.row(this);
        row.setBackground(U.glass(this,12));
        U.pad(row,11,7,11,7);
        row.addView(U.logo(this,logo,41));
        LinearLayout caption = U.col(this);
        U.pad(caption,10,0,10,0);
        caption.addView(U.txt(this,Club.name(this,name),16,true,U.text(this)));
        if (!league.isEmpty()) {
            U.space(caption,4);
            caption.addView(U.txt(this,League.byId(league).name(this),11,false,U.sub(this)));
        }
        row.addView(caption,U.weight(this,1));
        TextView toggle = U.txt(this,"",22,true,U.text(this));
        toggle.setGravity(Gravity.CENTER);
        Runnable update = () -> {
            boolean selected = Settings.isFavorite(this,id,league);
            toggle.setText(selected ? "✓" : "+");
            toggle.setTextColor(selected ? U.selectedInk() : U.text(this));
            toggle.setBackground(selected ? U.selected(this) : U.outlined(this,U.surface(this),U.sub(this),9));
            toggle.setContentDescription((selected ? t("إلغاء متابعة ","Unfollow ") : t("متابعة ","Follow ")) + Club.name(this,name));
        };
        update.run();
        row.addView(toggle,U.lp(this,42,42));
        toggle.setOnClickListener(v -> {
            Settings.follow(this,id,name,league,logo);
            update.run();
            refreshFollowing();
            if (clubQuery.trim().isEmpty()) savedClubs(parent);
        });
        row.setOnClickListener(v -> U.openTeam(this,id,name,logo,league));
        parent.addView(row,U.lp(this,-1,-2));
        U.space(parent,6);
    }

    private String teamId(String key) {
        return key.substring(key.indexOf(':')+1);
    }

    private String teamLeague(String key) {
        String league = Settings.teamLeague(this, key);
        int divider = key.indexOf(':');
        return league.isEmpty() && divider >= 0 ? key.substring(0, divider) : league;
    }

    private String knownTeamLogo(String id, String league) {
        for (Match match : games) {
            if (!league.isEmpty() && !league.equals(match.leagueId)) continue;
            if (id.equals(match.homeId)) return match.homeLogo;
            if (id.equals(match.awayId)) return match.awayLogo;
        }
        return "";
    }

    private boolean refreshFollowing() {
        boolean started = false;
        long now = SystemClock.elapsedRealtime();
        for (String key : Settings.favorites(this)) {
            String league = teamLeague(key);
            if (league.isEmpty() || pendingFixtures.contains(key)) continue;
            Long checkedAt = checkedFixtures.get(key);
            if (checkedAt != null && now - checkedAt < 300_000L) continue;
            pendingFixtures.add(key);
            started = true;
            String id = teamId(key);
            fixtureLoader.execute(() -> {
                Match next = null;
                for (Match match : ScoreRepository.teamSchedule(getApplicationContext(), league, id)) {
                    if (!"pre".equalsIgnoreCase(match.state)) continue;
                    try {
                        if (ScoreRepository.kickoff(match.isoDate).isBefore(Instant.now())) continue;
                    } catch (java.time.DateTimeException ignored) { continue; }
                    next = match;
                    break;
                }
                Match result = next;
                runOnUiThread(() -> {
                    if (isDestroyed()) return;
                    pendingFixtures.remove(key);
                    if (!Settings.favorites(this).contains(key)) return;
                    checkedFixtures.put(key, SystemClock.elapsedRealtime());
                    if (result == null) nextFixtures.remove(key);
                    else nextFixtures.put(key,result);
                    if (tab == 3 && clubList != null && clubQuery.trim().isEmpty()) savedClubs(clubList);
                });
            });
        }
        return started;
    }

    private void showMore() {
        menuRow(R.drawable.ui_star,t("المتابعة","Following"),"",() -> selectTab(3));
        menuRow(R.drawable.ui_cup,t("الدوريات","Leagues"),"",() -> selectTab(2));
        menuRow(R.drawable.ui_bell, t("التنبيهات","Notifications"), notificationSummary(), this::toggleAlerts);
        menuRow(R.drawable.ui_cup, t("الدوريات المعروضة","Displayed leagues"),
            Settings.enabledLeagues(this).size() + " " + t("دوري","leagues"), this::chooseLeagues);
        menuRow(R.drawable.ui_gear, t("الإعدادات","Settings"),
            t("اللغة والمظهر وعرض المباريات","Language, appearance and match display"), () -> {
                settingsOpen = true;
                showTab();
            });
        menuRow(R.drawable.ui_info, t("عن FootPulse","About FootPulse"), appVersion(), this::showAbout);
    }

    private String notificationSummary() {
        if (!Settings.alerts(this)) return t("تنبيهات الأهداف متوقفة","Goal alerts are off");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return t("اسمح بالإشعارات من إعدادات أندرويد","Allow notifications in Android settings");
        }
        return t("تنبيهات الأهداف للفرق المتابعة","Goal alerts for followed teams");
    }

    private void toggleAlerts() {
        boolean enabled = !Settings.alerts(this);
        Settings.alerts(this,enabled);
        ScoreAlertJob.schedule(this);
        requestNotifications();
        showTab();
    }

    private void closeSettings() {
        settingsOpen = false;
        showTab();
    }

    @Override public void onBackPressed() {
        if (settingsOpen) closeSettings();
        else if (tab != 0) selectTab(0);
        else if (scoresOpen) closeScores();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (clubSearch != null) handler.removeCallbacks(clubSearch);
        fixtureLoader.shutdownNow();
        super.onDestroy();
    }

    private String appVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(),0).versionName; }
        catch (PackageManager.NameNotFoundException ignored) { return ""; }
    }

    private void showAbout() {
        U.dialog(this).setTitle("FootPulse " + appVersion())
            .setMessage(t("تطبيق مستقل بدون إعلانات. بيانات البطولات والمباريات من FotMob.",
                "Independent app with no ads. Competition and match data from FotMob."))
            .setPositiveButton(t("إغلاق","Close"), null).show();
    }

    private void menuRow(int icon, String title, String summary, Runnable action) {
        LinearLayout row = U.row(this);
        row.setBackground(U.glass(this,20));
        row.setMinimumHeight(U.dp(this, 70));
        U.pad(row, 15, 10, 15, 10);
        row.addView(U.icon(this, icon, 23, U.accent(this)));
        LinearLayout text = U.col(this);
        U.pad(text, 16, 0, 8, 0);
        text.addView(U.txt(this, title, 17, true, U.text(this)));
        if (!summary.isEmpty()) text.addView(U.txt(this, summary, 13, false, U.sub(this)));
        row.addView(text,U.weight(this,1));
        ImageView arrow = U.icon(this,R.drawable.ui_back,16,U.sub(this));
        if (!Settings.ar(this)) arrow.setScaleX(-1);
        row.addView(arrow);
        row.setOnClickListener(v -> action.run());
        body.addView(row);
        U.space(body,7);
    }

    private void showSettings() {
        menuRow(R.drawable.ui_globe, t("اللغة","Language"), Settings.ar(this)?"العربية":"English", () ->
            U.dialog(this).setTitle(t("اختيار اللغة","Choose language"))
                .setSingleChoiceItems(new String[]{"العربية","English"}, Settings.ar(this)?0:1, (dialog,i) -> {
                    Settings.lang(this,i==0?"ar":"en");
                    dialog.dismiss();
                    showTab();
                }).show());
        menuRow(R.drawable.ui_appearance, t("المظهر","Appearance"), Settings.dark(this)?t("أزرق جليدي داكن","Ice blue dark"):t("فاتح","Light"), () ->
            U.dialog(this).setTitle(t("المظهر","Appearance"))
                .setSingleChoiceItems(new String[]{t("فاتح","Light"),t("أزرق جليدي داكن","Ice blue dark")}, Settings.dark(this)?1:0, (dialog,i) -> {
                    Settings.dark(this,i==1);
                    dialog.dismiss();
                    showTab();
                }).show());
        menuRow(R.drawable.ui_bell, t("التنبيهات","Notifications"), notificationSummary(), this::toggleAlerts);
        menuRow(R.drawable.ui_cup, t("الدوريات المعروضة","Displayed leagues"),
            Settings.enabledLeagues(this).size() + " " + t("دوري","leagues"), this::chooseLeagues);
        menuRow(R.drawable.ui_pitch, t("كثافة عرض المباريات","Match row density"),
            Settings.condensed(this)?t("مضغوط","Compact"):t("مريح","Comfortable"), () -> {
                Settings.condensed(this,!Settings.condensed(this));
                showTab();
            });
    }

    private void chooseLeagues(){
        String[] names=new String[League.ALL.size()];boolean[] enabled=new boolean[League.ALL.size()];
        final Set<String> selected=Settings.enabledLeagues(this);
        for(int i=0;i<League.ALL.size();i++){League l=League.ALL.get(i);names[i]=l.flag+" "+l.name(this);enabled[i]=selected.contains(l.id);}
        U.dialog(this).setTitle(Settings.t(this,"اختر البطولات","Choose competitions"))
          .setMultiChoiceItems(names,enabled,(dialog,which,isChecked)->{String id=League.ALL.get(which).id;if(isChecked)selected.add(id);else selected.remove(id);})
          .setPositiveButton(Settings.t(this,"حفظ","Save"),(dialog,which)->{Settings.enabledLeagues(this,selected);games.clear();showTab();loadGames(true);})
          .setNegativeButton(Settings.t(this,"إلغاء","Cancel"),null)
          .show();
    }
}
