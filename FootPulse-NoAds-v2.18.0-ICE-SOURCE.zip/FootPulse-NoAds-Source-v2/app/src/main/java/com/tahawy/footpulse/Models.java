package com.tahawy.footpulse;

import android.content.Context;
import java.util.*;

/** League IDs are provider codes, not an assertion of guaranteed coverage. */
final class League {
    static final String EURO = "uefa.euro";
    static final String CHAMPIONS = "uefa.champions";
    static final String CHAMPIONS_LOGO = "https://images.fotmob.com/image_resources/logo/leaguelogo/42.png";
    final String id, en, ar, flag;
    League(String id, String en, String ar, String flag) { this.id=id; this.en=en; this.ar=ar; this.flag=flag; }
    String name(Context c) { return Settings.ar(c) ? ar : en; }
    static final List<League> ALL = Collections.unmodifiableList(Arrays.asList(
        new League("eng.1", "Premier League", "الدوري الإنجليزي", "🏴"),
        new League("esp.1", "La Liga", "الدوري الإسباني", "🇪🇸"),
        new League(CHAMPIONS, "Champions League", "دوري أبطال أوروبا", "🏆"),
        new League("ita.1", "Serie A", "الدوري الإيطالي", "🇮🇹"),
        new League("ger.1", "Bundesliga", "الدوري الألماني", "🇩🇪"),
        new League("fra.1", "Ligue 1", "الدوري الفرنسي", "🇫🇷"),
        new League("uefa.europa", "Europa League", "الدوري الأوروبي", "🏆"),
        new League("ned.1", "Eredivisie", "الدوري الهولندي", "🇳🇱"),
        new League("por.1", "Primeira Liga", "الدوري البرتغالي", "🇵🇹"),
        new League("usa.1", "MLS", "الدوري الأمريكي", "🇺🇸"),
        new League("fifa.world", "FIFA World Cup", "كأس العالم", "🌍"),
        new League("eng.2", "Championship", "تشامبيونشيب إنجلترا", "🏴"),
        new League(FotMob.PREMIER, "Egyptian Premier League", "الدوري المصري", "🇪🇬"),
        new League("ksa.1", "Saudi Pro League", "الدوري السعودي", "🇸🇦"),
        new League("uefa.conference", "Conference League", "دوري المؤتمر الأوروبي", "🏆"),
        new League("eng.fa", "FA Cup", "كأس الاتحاد الإنجليزي", "🏆"),
        new League("eng.league_cup", "EFL Cup", "كأس الرابطة الإنجليزية", "🏆"),
        new League("sco.1", "Scottish Premiership", "الدوري الأسكتلندي", "🏴"),
        new League("tur.1", "Turkish Super Lig", "الدوري التركي", "🇹🇷"),
        new League("bel.1", "Belgian Pro League", "الدوري البلجيكي", "🇧🇪"),
        new League("arg.1", "Argentina Primera", "الدوري الأرجنتيني", "🇦🇷"),
        new League("bra.1", "Brazil Serie A", "الدوري البرازيلي", "🇧🇷"),
        new League("mex.1", "Liga MX", "الدوري المكسيكي", "🇲🇽"),
        new League("jpn.1", "J1 League", "الدوري الياباني", "🇯🇵"),
        new League("aus.1", "A-League", "الدوري الأسترالي", "🇦🇺"),
        new League("uefa.nations", "Nations League", "دوري الأمم الأوروبية", "🏆"),
        new League(EURO, "European Championship", "بطولة أمم أوروبا", "🏆"),
        new League("fifa.worldq.uefa", "World Cup Qualifying UEFA", "تصفيات كأس العالم أوروبا", "🌍"),
        new League("fifa.worldq.conmebol", "World Cup Qualifying CONMEBOL", "تصفيات كأس العالم أمريكا الجنوبية", "🌍"),
        new League(FotMob.CUP, "Egypt Cup", "كأس مصر", "🇪🇬"),
        new League("uefa.champions.qual","Champions League Qualification","تصفيات دوري أبطال أوروبا","🏆")
    ));
    boolean matchesQuery(String query) {
        String value = searchKey(query);
        String names = en + " " + ar + (EURO.equals(id) ? " UEFA Euro اليورو يورو كأس أمم أوروبا" : "");
        return searchKey(names).contains(value);
    }

    private static String searchKey(String text) {
        return java.text.Normalizer.normalize(text,java.text.Normalizer.Form.NFD)
            .replaceAll("\\p{M}+","").trim().toLowerCase(Locale.ROOT);
    }

    static League byId(String id) { for (League l:ALL) if(l.id.equals(id)) return l; return ALL.get(0); }
}

final class Match {
    String id, leagueId, leagueLogo, home, away, homeId, awayId, homeLogo, awayLogo, homeScore, awayScore, state, status, isoDate, venue, competitionName;
    boolean isLive(){ return "in".equalsIgnoreCase(state); }
    boolean finished(){ return "post".equalsIgnoreCase(state); }
    boolean concerns(Set<String> favorites){ return favorites.contains(League.byId(leagueId).id+":"+homeId) || favorites.contains(League.byId(leagueId).id+":"+awayId) || favorites.contains(homeId) || favorites.contains(awayId); }
    String matchKey(){return leagueId+":"+id;}
}

final class Standing {
    String id, name, logo, played="-", won="-", drawn="-", lost="-", points="-", difference="-";
}
