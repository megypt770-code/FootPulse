package com.tahawy.footpulse;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;
import java.util.List;

final class PitchView extends View {
    private final PitchLineup lineup;
    private final java.util.Map<PitchLineup.Player,android.graphics.Bitmap> portraits = new java.util.HashMap<>();
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());
    private final boolean dark;
    private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG);

    PitchView(Context c, PitchLineup lineup) {
        super(c);
        this.lineup = lineup;
        dark = Settings.dark(c);
        text.setTypeface(Typeface.create("sans-serif-condensed",Typeface.NORMAL));
        text.setTextAlign(Paint.Align.CENTER);
        StringBuilder description = new StringBuilder(Settings.t(c,"تشكيلة الفريق على الملعب","Starting eleven on the pitch"));
        description.append(". ").append(lineup.formation);
        for (List<PitchLineup.Player> row : lineup.lines) {
            for (PitchLineup.Player player : row) {
                description.append(", ").append(player.number).append(' ').append(player.name);
                LogoLoader.load(player.photo,bitmap -> ui.post(() -> {
                    portraits.put(player,bitmap);
                    invalidate();
                }));
            }
        }
        setContentDescription(description);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        setMeasuredDimension(width, resolveSize(Math.round(width * 1.07f), heightSpec));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.save();
        canvas.scale(getWidth() / 360f, getHeight() / 378f);
        ink.setShader(new LinearGradient(0,0,0,378,dark ? 0xFF254B7D : 0xFFD8EEFF,
            dark ? 0xFF132F56 : 0xFFEEF7FF,Shader.TileMode.CLAMP));
        canvas.drawRoundRect(1,1,359,377,8,8,ink);
        ink.setShader(null);
        marks(canvas);
        players(canvas);
        canvas.restore();
    }

    private void marks(Canvas c) {
        ink.setStyle(Paint.Style.STROKE);
        ink.setStrokeWidth(1.15f);
        ink.setColor(dark ? 0xA07295A7 : 0x6F8DA6B4);
        c.drawRect(8,5,352,373,ink);
        c.drawLine(8,189,352,189,ink);
        c.drawCircle(180,189,43,ink);
        c.drawRect(105,5,255,68,ink);
        c.drawRect(141,5,219,33,ink);
        c.drawRect(105,310,255,373,ink);
        c.drawRect(141,345,219,373,ink);
        c.drawArc(136,45,224,111,24,132,false,ink);
        c.drawArc(136,267,224,333,204,132,false,ink);
        c.drawArc(-7,-10,23,20,0,90,false,ink);
        c.drawArc(337,-10,367,20,90,90,false,ink);
        c.drawArc(-7,358,23,388,270,90,false,ink);
        c.drawArc(337,358,367,388,180,90,false,ink);
        ink.setStyle(Paint.Style.FILL);
        c.drawCircle(180,189,2,ink);
        c.drawCircle(180,50,1.6f,ink);
        c.drawCircle(180,328,1.6f,ink);
    }

    private void players(Canvas c) {
        int rows = lineup.lines.size();
        for (int r=0;r<rows;r++) {
            List<PitchLineup.Player> line = lineup.lines.get(r);
            float y = 345f - r*305f/(rows-1);
            float slot = 334f/line.size();
            for (int i=0;i<line.size();i++) {
                PitchLineup.Player player = line.get(i);
                float x = 13f + (i+.5f)*slot;
                portrait(c,player,x,y,Math.min(124,slot-6));
            }
        }
    }

    private void portrait(Canvas c, PitchLineup.Player player, float x, float y, float maxLabel) {
        c.save();
        c.translate(x, y);
        ink.setColor(dark ? 0xFF225894 : 0xFFF1F8FB);
        c.drawCircle(0,-1,13,ink);
        android.graphics.Bitmap bitmap = portraits.get(player);
        if (bitmap != null) {
            int side = Math.min(bitmap.getWidth(),bitmap.getHeight());
            int bx = (bitmap.getWidth()-side)/2, by = (bitmap.getHeight()-side)/2;
            c.save();
            Path circle = new Path();
            circle.addCircle(0,-1,12,Path.Direction.CW);
            c.clipPath(circle);
            c.drawBitmap(bitmap,new android.graphics.Rect(bx,by,bx+side,by+side),
                new android.graphics.RectF(-12,-13,12,11),ink);
            c.restore();
        } else {
            text.setColor(dark ? Color.WHITE : 0xFF24465B);
            text.setTextSize(10);
            c.drawText(player.number,0,3,text);
        }
        ink.setStyle(Paint.Style.STROKE);
        ink.setStrokeWidth(1.2f);
        ink.setColor(dark ? 0xFF88CEFF : 0xFFF6FBFE);
        c.drawCircle(0,-1,12.5f,ink);
        ink.setStyle(Paint.Style.FILL);
        boolean secondYellow = player.events.contains("secondYellow") || player.events.contains("secondYellowCard");
        boolean red = player.events.contains("redCard") || secondYellow;
        if (secondYellow || (!red && player.events.contains("yellowCard"))) {
            ink.setColor(0xFFFFC928);
            c.drawRoundRect(7,-17,14,-7,1,1,ink);
        }
        if (red) {
            ink.setColor(0xFFE23646);
            int offset = secondYellow ? 5 : 0;
            c.drawRoundRect(7+offset,-16,14+offset,-6,1,1,ink);
        }
        text.setTextSize(9);
        String full = player.number + " " + player.name;
        String label = TextUtils.ellipsize(full,text,maxLabel-4,TextUtils.TruncateAt.END).toString();
        text.setColor(dark ? Color.WHITE : 0xFF1A3444);
        c.drawText(label,0,22,text);
        c.restore();
    }
}
