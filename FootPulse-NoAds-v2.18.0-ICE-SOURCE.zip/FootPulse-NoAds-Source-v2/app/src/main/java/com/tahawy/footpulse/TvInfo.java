package com.tahawy.footpulse;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** Shares one lookup per fixture between the match cards and the detail screen. */
final class TvInfo {
    interface Listener { void ready(String text); }

    private static final class Entry {
        final long at = System.currentTimeMillis();
        final Map<String,List<String>> channels;
        Entry(Map<String,List<String>> channels) { this.channels = channels; }
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final LruCache<String,Entry> MEMORY = new LruCache<>(128);
    private static final Map<String,List<Consumer<Map<String,List<String>>>>> PENDING = new LinkedHashMap<>();

    private TvInfo() {}

    static void load(Activity activity,Match match,Listener listener) {
        if (!Upcoming.open(match)) return;
        loadCoverage(activity,match,channels -> {
            String names = summary(channels);
            if (!names.isEmpty()) listener.ready(names);
        });
    }

    static void loadCoverage(Activity activity,Match match,Consumer<Map<String,List<String>>> listener) {
        Consumer<Map<String,List<String>>> callback = channels -> {
            if (!activity.isDestroyed() && !activity.isFinishing()) listener.accept(channels);
        };
        if (match.isoDate == null) {
            MAIN.post(() -> callback.accept(Collections.emptyMap()));
            return;
        }
        String key = match.matchKey() + "|" + match.isoDate;
        Entry known = MEMORY.get(key);
        if (known != null && System.currentTimeMillis()-known.at < (known.channels.isEmpty() ? 90_000L : 600_000L)) {
            MAIN.post(() -> callback.accept(known.channels));
            return;
        }
        List<Consumer<Map<String,List<String>>>> waiting = PENDING.get(key);
        if (waiting != null) {
            waiting.add(callback);
            return;
        }
        List<Consumer<Map<String,List<String>>>> listeners = new ArrayList<>();
        listeners.add(callback);
        PENDING.put(key,listeners);
        Context app = activity.getApplicationContext();
        String id = match.id, home = match.home, away = match.away, iso = match.isoDate;
        POOL.execute(() -> {
            Map<String,List<String>> result = ScoreRepository.tvChannels(app,id,home,away,iso);
            MAIN.post(() -> {
                MEMORY.put(key,new Entry(result));
                PENDING.remove(key);
                for (Consumer<Map<String,List<String>>> ready : listeners) ready.accept(result);
            });
        });
    }

    static String summary(Map<String,List<String>> channels) {
        Map<String,String> unique = new LinkedHashMap<>();
        for (List<String> names : channels.values()) {
            for (String name : names) unique.putIfAbsent(TvSchedule.channelKey(name),name);
        }
        List<String> names = new ArrayList<>(unique.values());
        List<String> shown = names.subList(0,Math.min(2,names.size()));
        return String.join(" · ",shown) + (names.size()>2 ? " +" + (names.size()-2) : "");
    }
}
