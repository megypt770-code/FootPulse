package com.tahawy.footpulse;

import android.app.Activity;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

final class ScoresCards {
    private final Activity c;
    private final ScoresStyle style;

    ScoresCards(Activity activity,ScoresStyle style) {
        c = activity;
        this.style = style;
    }

    View result(Match match,boolean compact) { return fixture(match,compact,false,false); }

    View fixture(Match match,boolean compact,boolean channels,boolean highlight) {
        LinearLayout card = U.card(c);
        card.setBackground(highlight ? U.stadium(c) : U.glass(c,14));
        U.pad(card,10,compact ? 8 : 12,10,compact ? 8 : 12);
        if (highlight) {
            TextView league = U.txt(c,League.byId(match.leagueId).name(c),12,true,highlightInk());
            league.setGravity(Gravity.CENTER);
            card.addView(league,U.lp(c,-1,-2));
            U.space(card,7);
        }
        LinearLayout row = U.row(c);
        row.addView(team(match,true,false,compact?29:40,highlight),U.weight(c,1));
        LinearLayout center = U.col(c);
        center.setGravity(Gravity.CENTER);
        TextView plate = score(match,false);
        center.addView(plate,U.lp(c,-1,compact?31:36));
        if (match.isLive()) {
            U.space(center,4);
            center.addView(status(match));
        } else if (channels && Upcoming.open(match)) {
            TextView badge = U.txt(c,t("القنوات الناقلة","TV channels"),10,true,U.accent(c));
            badge.setSingleLine();
            badge.setGravity(Gravity.CENTER);
            badge.setBackground(U.outlined(c,U.bg(c),U.accent(c),13));
            badge.setVisibility(View.GONE);
            LinearLayout.LayoutParams params = U.lp(c,-1,22);
            params.topMargin = U.dp(c,5);
            center.addView(badge,params);
            TvInfo.load(c,match,text -> {
                badge.setContentDescription(t("القنوات الناقلة ","TV channels ") + text);
                badge.setVisibility(View.VISIBLE);
            });
        }
        if (highlight) {
            TextView date = U.txt(c,format(match,"EEE d MMM"),10,false,highlightInk());
            date.setGravity(Gravity.CENTER);
            U.space(center,5);
            center.addView(date);
        }
        row.addView(center,U.lp(c,compact?65:82,-2));
        row.addView(team(match,false,false,compact?29:40,highlight),U.weight(c,1));
        card.addView(row);
        card.setOnClickListener(v -> U.openMatch(c,match));
        return card;
    }

    View matchday(Match match,boolean compact,boolean channels) {
        LinearLayout card = U.card(c);
        card.setBackground(U.glass(c,14));
        U.pad(card,10,8,10,8);
        LinearLayout row = U.row(c);
        LinearLayout teams = U.col(c);
        boolean scored = (match.isLive() || match.finished()) && filled(match.homeScore) && filled(match.awayScore);
        teams.addView(matchdayTeam(match.home,match.homeLogo,scored ? match.homeScore : "–",compact));
        teams.addView(matchdayTeam(match.away,match.awayLogo,scored ? match.awayScore : "–",compact));
        row.addView(teams,U.weight(c,1));

        View divider = new View(c);
        divider.setBackgroundColor(U.border(c));
        LinearLayout.LayoutParams edge = U.lp(c,1,compact ? 54 : 67);
        edge.setMarginStart(U.dp(c,5));
        edge.setMarginEnd(U.dp(c,5));
        row.addView(divider,edge);

        LinearLayout meta = U.col(c);
        meta.setGravity(Gravity.CENTER);
        String label = MatchText.status(c,match);
        if (match.finished() && label.isEmpty()) label = t("انتهت","Finished");
        if (match.isLive() && label.isEmpty()) label = t("مباشر","Live");
        boolean scheduled = !match.isLive() && !match.finished();
        if (scheduled && (label.isEmpty() || label.equals(t("قادمة","Upcoming"))))
            label = t("لم تبدأ","Not started");
        TextView status = U.txt(c,label,11,true,match.isLive() ? U.accent(c) : style.muted);
        status.setGravity(Gravity.CENTER);
        if (match.isLive()) {
            status.setBackground(U.shape(U.accentSurface(c),12,c));
            U.pad(status,6,4,6,4);
        }
        meta.addView(status);
        if (scheduled) {
            U.space(meta,4);
            TextView time = U.scorePlate(c,format(match,"HH:mm"),14);
            meta.addView(time,U.lp(c,57,24));
        }
        if (channels) {
            TextView tv = U.txt(c,t("القنوات الناقلة","TV channels"),9,true,U.accent(c));
            tv.setGravity(Gravity.CENTER);
            tv.setVisibility(View.GONE);
            U.pad(tv,0,4,0,0);
            meta.addView(tv);
            TvInfo.load(c,match,text -> {
                tv.setContentDescription(t("القنوات الناقلة ","TV channels ") + text);
                tv.setVisibility(View.VISIBLE);
            });
        }
        row.addView(meta,U.lp(c,72,-2));
        card.addView(row,U.lp(c,-1,-2));
        card.setOnClickListener(v -> U.openMatch(c,match));
        return card;
    }

    private View matchdayTeam(String name,String logo,String value,boolean compact) {
        LinearLayout row = U.row(c);
        row.setMinimumHeight(U.dp(c,compact ? 34 : 42));
        row.addView(U.logo(c,logo,compact ? 26 : 32));
        TextView title = U.txt(c,Club.name(c,name),compact ? 13 : 15,true,style.ink);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        U.pad(title,8,0,4,0);
        row.addView(title,U.weight(c,1));
        TextView score = U.txt(c,value,compact ? 17 : 20,true,style.ink);
        score.setGravity(Gravity.CENTER);
        row.addView(score,U.lp(c,31,-2));
        return row;
    }

    LinearLayout header(Match match,Runnable openCoverage) {
        LinearLayout card = U.card(c);
        card.setBackground(U.stadium(c));
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        U.pad(card,12,11,12,11);
        card.addView(status(match));
        U.space(card,7);
        LinearLayout row = U.row(c);
        row.addView(team(match,true,true,62,true),U.weight(c,1));
        TextView plate = score(match,true);
        row.addView(plate,U.lp(c,108,51));
        row.addView(team(match,false,true,62,true),U.weight(c,1));
        card.addView(row,U.lp(c,-1,-2));
        if ("pre".equalsIgnoreCase(match.state)) {
            U.space(card,6);
            TextView date = U.txt(c,format(match,"EEEE d MMM") + " · " + t("توقيت القاهرة","Cairo time"),12,true,highlightInk());
            date.setGravity(Gravity.CENTER);
            card.addView(date,U.lp(c,-1,-2));
        }
        U.space(card,9);
        LinearLayout tv = U.row(c);
        U.pad(tv,9,5,9,5);
        tv.setBackground(U.outlined(c,Settings.dark(c)?0xE9113464:U.surface(c),U.accent(c),18));
        tv.addView(U.icon(c,R.drawable.ui_tv,17,U.accent(c)));
        TextView label = U.txt(c,t("القنوات الناقلة","TV channels"),11,true,U.accent(c));
        U.pad(label,6,0,6,0);
        tv.addView(label);
        TextView names = U.txt(c,"",11,true,highlightInk());
        names.setSingleLine();
        names.setMaxWidth(U.dp(c,142));
        names.setEllipsize(TextUtils.TruncateAt.END);
        tv.addView(names);
        tv.setOnClickListener(v -> openCoverage.run());
        card.addView(tv);
        TvInfo.loadCoverage(c,match,bySource -> {
            String text = TvInfo.summary(bySource);
            if (!text.isEmpty()) names.setText(text);
        });
        return card;
    }

    private TextView score(Match match,boolean large) {
        boolean known = !"pre".equalsIgnoreCase(match.state) && filled(match.homeScore) && filled(match.awayScore);
        String value = known ? match.homeScore + " - " + match.awayScore : format(match,"h:mm a");
        TextView plate = U.scorePlate(c,value,known ? (large?31:21) : (large?21:14));
        if (Settings.ar(c) && known) plate.setText(match.awayScore + " - " + match.homeScore);
        if (!known || large) plate.setTextColor(large ? highlightInk() : style.ink);
        return plate;
    }

    private TextView status(Match match) {
        String status = MatchText.status(c,match);
        if (match.isLive()) status = t("● مباشر","● Live") + (status.isEmpty() || status.equalsIgnoreCase(t("مباشر","Live")) ? "" : "  " + status);
        if (status.isEmpty()) status = t("قادمة","Upcoming");
        TextView badge = U.txt(c,status,11,true,match.isLive() ? 0xFFFFE7D7 : style.ink);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(match.isLive() ? U.outlined(c,0xFF6B2321,0xFFA23931,13) : U.glass(c,13));
        U.pad(badge,7,4,7,4);
        return badge;
    }

    private View team(Match match,boolean home,boolean hero,int size,boolean highlight) {
        String rawName = home ? match.home : match.away;
        String name = Club.name(c,rawName);
        String logo = home ? match.homeLogo : match.awayLogo;
        String id = home ? match.homeId : match.awayId;
        LinearLayout team = hero ? U.col(c) : U.row(c);
        team.setGravity(Gravity.CENTER);
        TextView label = U.txt(c,name,hero?15:13,true,highlight ? highlightInk() : style.ink);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        label.setEllipsize(TextUtils.TruncateAt.END);
        if (hero || home) team.addView(U.logo(c,logo,size));
        if (hero) U.space(team,5);
        team.addView(label,hero ? U.lp(c,-1,-2) : U.weight(c,1));
        if (!hero && !home) team.addView(U.logo(c,logo,size));
        if (hero) {
            team.setOnClickListener(v -> U.openTeam(c,id,rawName,logo,match.leagueId));
            team.setOnLongClickListener(v -> { Settings.follow(c,id,rawName,match.leagueId,logo); return true; });
        }
        return team;
    }

    private int highlightInk() { return Settings.dark(c) ? 0xFFF1FAFF : style.ink; }
    private String format(Match match,String pattern) {
        try {
            Locale locale = Settings.ar(c) ? new Locale("ar","EG") : Locale.ENGLISH;
            return DateTimeFormatter.ofPattern(pattern,locale).withZone(ScoreRepository.CAIRO)
                .format(ScoreRepository.kickoff(match.isoDate));
        } catch (RuntimeException ignored) { return "—"; }
    }

    private String t(String ar,String en) { return Settings.t(c,ar,en); }
    private static boolean filled(String value) { return value != null && !value.isEmpty(); }
}
