package com.tahawy.footpulse;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class LogoLoader {
    private static final int MAX_IMAGE_BYTES = 3 * 1024 * 1024;
    private static final LruCache<String,Bitmap> cache = new LruCache<>(16 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap bitmap) {
            return bitmap.getAllocationByteCount();
        }
    };
    private static final ExecutorService pool=Executors.newFixedThreadPool(3);
    static void into(ImageView img,String url){
        img.setTag(url);
        load(url,b -> img.post(() -> { if (url.equals(img.getTag())) img.setImageBitmap(b); }));
    }

    static void load(String url,java.util.function.Consumer<Bitmap> consumer) {
        if(url==null||!url.startsWith("https://"))return;
        Bitmap have=cache.get(url);if(have!=null){consumer.accept(have);return;}
        pool.execute(()->{
            HttpURLConnection conn=null;
            try {
                conn=(HttpURLConnection)new URL(url).openConnection();conn.setConnectTimeout(5000);conn.setReadTimeout(5000);
                if(conn.getResponseCode()!=200)return;
                Bitmap b;
                try (InputStream in = conn.getInputStream()) {
                    b = decodeImage(in);
                }
                if (b == null) return;
                cache.put(url,b);
                consumer.accept(b);
            }catch(Exception ignored){}finally{if(conn!=null)conn.disconnect();}
        });
    }

    private static Bitmap decodeImage(InputStream input) throws java.io.IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        while ((count = input.read(buffer)) != -1) {
            if (output.size() + count > MAX_IMAGE_BYTES) return null;
            output.write(buffer, 0, count);
        }
        byte[] bytes = output.toByteArray();
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
        int dimension = Math.max(options.outWidth, options.outHeight);
        if (dimension <= 0) return null;
        options.inSampleSize = 1;
        while (dimension / options.inSampleSize > 1000) options.inSampleSize *= 2;
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
    }
}
