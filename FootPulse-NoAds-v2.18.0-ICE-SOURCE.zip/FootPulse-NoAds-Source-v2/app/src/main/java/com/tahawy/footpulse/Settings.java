package com.tahawy.footpulse;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;

final class Settings {
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("footpulse",Context.MODE_PRIVATE); }
    static boolean ar(Context c) { return prefs(c).getString("lang","ar").equals("ar"); }
    static boolean dark(Context c) { return prefs(c).getBoolean("ice_dark",true); }
    static boolean alerts(Context c) { return prefs(c).getBoolean("alerts",false); }
    static String t(Context c,String arabic,String english) { return ar(c)?arabic:english; }
    static void lang(Context c,String code){prefs(c).edit().putString("lang",code).apply();}
    static void dark(Context c,boolean b){prefs(c).edit().putBoolean("ice_dark",b).apply();}
    static void alerts(Context c,boolean b){prefs(c).edit().putBoolean("alerts",b).apply();}
    static Set<String> favorites(Context c){return new HashSet<>(prefs(c).getStringSet("teams",Collections.emptySet()));}
    static String key(String league,String teamId){return (league==null?"":league)+":"+(teamId==null?"":teamId);}
    static boolean isFavorite(Context c,String teamId,String league) {
        for (String key : favorites(c)) {
            if (key.equals(teamId) || key.equals(key(league,teamId))) return true;
            if (key.endsWith(":" + teamId) && !teamLogo(c,key).isEmpty()) return true;
        }
        return false;
    }

    static Set<String> matchFavorites(Context c) {
        Set<String> teams = favorites(c);
        Set<String> keys = new HashSet<>(teams);
        for (String key : teams)
            if (!teamLogo(c,key).isEmpty()) keys.add(key.substring(key.indexOf(':')+1));
        return keys;
    }
    static String teamName(Context c,String id){return prefs(c).getString("team_"+id,id);}
    static String teamLeague(Context c,String id){return prefs(c).getString("team_league_"+id,"");}
    static Set<String> favoriteLeagues(Context c){return new HashSet<>(prefs(c).getStringSet("favorite_leagues",Collections.emptySet()));}
    static boolean isLeagueFavorite(Context c,String id){return favoriteLeagues(c).contains(id);}
    static synchronized void toggleLeague(Context c,String id) {
        if (!FotMob.supports(id)) return;
        Set<String> favorites = favoriteLeagues(c);
        SharedPreferences.Editor edit = prefs(c).edit();
        if (favorites.add(id)) {
            Set<String> enabled = enabledLeagues(c);
            if (enabled.add(id)) edit.putStringSet("enabled_leagues",enabled);
        } else favorites.remove(id);
        edit.putStringSet("favorite_leagues",favorites).apply();
    }

    static synchronized void enablePreviouslyFollowedLeagues(Context c) {
        SharedPreferences preferences = prefs(c);
        if (preferences.getBoolean("followed_leagues_enabled",false)) return;
        Set<String> followed = favoriteLeagues(c);
        followed.removeIf(id -> !FotMob.supports(id));
        Set<String> enabled = enabledLeagues(c);
        SharedPreferences.Editor edit = preferences.edit().putBoolean("followed_leagues_enabled",true);
        if (enabled.addAll(followed)) edit.putStringSet("enabled_leagues",enabled);
        edit.apply();
    }
    static Set<String> enabledLeagues(Context c){
        if(prefs(c).contains("enabled_leagues"))return new HashSet<>(prefs(c).getStringSet("enabled_leagues",Collections.emptySet()));
        Set<String> defaults=new LinkedHashSet<>();
        for(int i=0;i<14;i++)defaults.add(League.ALL.get(i).id);
        defaults.add(FotMob.CUP);
        return defaults;
    }
    static void enableEgyptOnUpgrade(Context c) {
        SharedPreferences preferences = prefs(c);
        if (preferences.getBoolean("egypt_fotmob_migrated",false)) return;
        SharedPreferences.Editor edit = preferences.edit().putBoolean("egypt_fotmob_migrated",true);
        if (preferences.contains("enabled_leagues")) {
            Set<String> leagues = enabledLeagues(c);
            leagues.add(FotMob.PREMIER);
            leagues.add(FotMob.CUP);
            edit.putStringSet("enabled_leagues",leagues);
        }
        edit.apply();
    }
    static void enabledLeagues(Context c,Set<String> list){prefs(c).edit().putStringSet("enabled_leagues",new HashSet<>(list)).apply();}
    static boolean condensed(Context c){return prefs(c).getBoolean("compact",false);}
    static void condensed(Context c,boolean compact){prefs(c).edit().putBoolean("compact",compact).apply();}
    static boolean bookmarked(Context c,Match m){return prefs(c).getStringSet("bookmarked_matches",Collections.emptySet()).contains(m.matchKey());}
    static void bookmark(Context c,Match m){Set<String> keys=new HashSet<>(prefs(c).getStringSet("bookmarked_matches",Collections.emptySet()));if(!keys.add(m.matchKey()))keys.remove(m.matchKey());prefs(c).edit().putStringSet("bookmarked_matches",keys).apply();}
    static String teamLogo(Context c,String key) {
        String logo = prefs(c).getString("team_logo_"+key,"");
        return logo.startsWith("https://images.fotmob.com/") ? logo : "";
    }

    static synchronized void reconcileFotMobTeams(Context c, String league, List<Standing> clubs) {
        SharedPreferences saved = prefs(c);
        Set<String> teams = favorites(c);
        SharedPreferences.Editor edit = saved.edit();
        boolean changed = false;
        for (String previous : new HashSet<>(teams)) {
            String storedLeague = teamLeague(c,previous);
            if (!league.equals(storedLeague) && !previous.startsWith(league + ":")) continue;
            if (!teamLogo(c,previous).isEmpty()) continue;
            String storedName = clubKey(teamName(c,previous));
            if (storedName.isEmpty()) continue;
            Standing found = null;
            for (Standing club : clubs) {
                if (!storedName.equals(clubKey(club.name))) continue;
                if (found != null) { found = null; break; }
                found = club;
            }
            if (found == null) continue;
            String current = key(league,found.id);
            teams.remove(previous);
            teams.add(current);
            edit.putString("team_"+current,found.name)
                .putString("team_league_"+current,league)
                .putString("team_logo_"+current,found.logo);
            changed = true;
        }
        if (changed) edit.putStringSet("teams",teams).apply();
    }

    private static String clubKey(String name) {
        String key = java.text.Normalizer.normalize(name,java.text.Normalizer.Form.NFD)
            .replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT)
            .replaceAll("\\b(fc|sc|cf|afc)\\b","")
            .replaceAll("[^a-z0-9]","");
        switch (key) {
            case "manunited": case "manutd": return "manchesterunited";
            case "mancity": return "manchestercity";
            case "tottenham": case "spurs": return "tottenhamhotspur";
            case "psg": return "parissaintgermain";
            default: return key;
        }
    }
    static long followedAt(Context c,String key) { return prefs(c).getLong("followed_at_"+key,0); }
    static synchronized void unfollow(Context c,String key) {
        Set<String> teams=favorites(c);
        teams.remove(key);
        prefs(c).edit().putStringSet("teams",teams).apply();
        ScoreAlertJob.schedule(c);
    }
    static synchronized void follow(Context c,String teamId,String name,String league,String logo){
       if(teamId==null||teamId.isEmpty())return;
       String savedKey=key(league,teamId);
       Set<String> teams=favorites(c);
       boolean removed = teams.removeIf(item -> item.equals(savedKey) || item.equals(teamId)
           || (item.endsWith(":" + teamId) && !teamLogo(c,item).isEmpty()));
       if (!removed) teams.add(savedKey);
       SharedPreferences.Editor edit=prefs(c).edit().putStringSet("teams",teams)
          .putString("team_"+savedKey,name==null?teamId:name)
          .putString("team_league_"+savedKey,league==null?"":league);
       if (!removed) edit.putLong("followed_at_"+savedKey,System.currentTimeMillis());
       if (logo!=null && !logo.isEmpty()) edit.putString("team_logo_"+savedKey,logo);
       edit.apply();
       ScoreAlertJob.schedule(c);
    }
}
