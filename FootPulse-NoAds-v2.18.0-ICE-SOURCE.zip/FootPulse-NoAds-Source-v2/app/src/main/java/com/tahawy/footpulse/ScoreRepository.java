package com.tahawy.footpulse;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

/** Fetches and caches public FotMob pages. */
final class ScoreRepository {
    static final ZoneId CAIRO = ZoneId.of("Africa/Cairo");
    private static final long STALE_SCORES = 24 * 3600_000L;

    private interface BodyParser<T> {
        T parse(String body) throws Exception;
    }

    private static <T> T fetch(Context c, String url, String accept, long ttl, long stale, boolean force,
                               BodyParser<T> parser) throws Exception {
        return fetch(c, url, accept, ttl, stale, force, parser, value -> {});
    }

    private static <T> T fetch(Context c, String url, String accept, long ttl, long stale, boolean force,
                               BodyParser<T> parser, java.util.function.LongConsumer timestamp) throws Exception {
        File dir = new File(c.getFilesDir(), "cache");
        if (!dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory()) {
            throw new IOException("Unable to create cache directory");
        }
        File cached = new File(dir, UUID.nameUUIDFromBytes(url.getBytes(StandardCharsets.UTF_8)).toString() + ".json");
        long age = cached.isFile() ? Math.max(0, System.currentTimeMillis() - cached.lastModified()) : Long.MAX_VALUE;
        if (!force && age < ttl) {
            try {
                T value = parser.parse(read(cached));
                timestamp.accept(cached.lastModified());
                return value;
            } catch (Exception ignored) {}
        }
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(6500);
            conn.setReadTimeout(7500);
            conn.setRequestProperty("Accept", accept);
            conn.setRequestProperty("User-Agent", "FootPulse/2.12 Android");
            String body;
            try {
                int status = conn.getResponseCode();
                if (status != 200) throw new IOException("HTTP " + status);
                try (InputStream in = conn.getInputStream()) { body = read(in); }
            } finally {
                conn.disconnect();
            }
            T value = parser.parse(body);
            saveCache(dir, cached, body);
            timestamp.accept(System.currentTimeMillis());
            return value;
        } catch (Exception failure) {
            if (age < stale) {
                T value = parser.parse(read(cached));
                timestamp.accept(cached.lastModified());
                return value;
            }
            throw failure;
        }
    }

    private static void saveCache(File dir, File cached, String body) {
        File temporary = null;
        try {
            temporary = File.createTempFile("response-", ".tmp", dir);
            try (FileOutputStream out = new FileOutputStream(temporary)) {
                out.write(body.getBytes(StandardCharsets.UTF_8));
            }
            temporary.renameTo(cached);
        } catch (IOException ignored) {
            // A valid online result remains usable if the cache cannot be written.
        } finally {
            if (temporary != null) temporary.delete();
        }
    }
    private static String read(File f) throws IOException {try(InputStream in=new FileInputStream(f)){return read(in);}}
    private static String read(InputStream in) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>5_000_000)throw new IOException("Response too big");}
        return out.toString("UTF-8");
    }
    static List<Match> matches(Context c, LocalDate day,boolean force){
        return matches(c,day,force,Collections.emptySet());
    }

    static List<Match> matches(Context c,LocalDate day,boolean force,Set<String> extraLeagues) {
        ExecutorService pool=Executors.newFixedThreadPool(5);
        List<Future<List<Match>>> pending=new ArrayList<>();
        Set<String> enabled = new HashSet<>(Settings.enabledLeagues(c));
        enabled.addAll(extraLeagues);
        for (League league : League.ALL) {
            if (enabled.contains(league.id)) pending.add(pool.submit(() -> matchesForLeague(c, league.id, day, force)));
        }
        List<Match> all=new ArrayList<>();
        for(Future<List<Match>> f:pending){try{all.addAll(f.get(18,TimeUnit.SECONDS));}catch(Exception ignored){f.cancel(true);}}
        pool.shutdownNow();
        all.sort(Comparator.comparing(m->m.isoDate==null?"":m.isoDate));
        return all;
    }
    /** Live/upcoming matches on the first day (from {@code from} on) that has any, across enabled leagues. */
    static List<Match> nextOpenDay(Context c, LocalDate from, boolean force) {
        ExecutorService pool = Executors.newFixedThreadPool(5);
        List<Future<List<Match>>> pending = new ArrayList<>();
        Set<String> enabled = Settings.enabledLeagues(c);
        for (League league : League.ALL) {
            if (enabled.contains(league.id)) pending.add(pool.submit(() -> fixtures(c,league.id,null,force)));
        }
        ZoneId zone = CAIRO;
        List<Match> open = new ArrayList<>();
        LocalDate best = null;
        for (Future<List<Match>> f : pending) {
            try {
                for (Match m : f.get(18,TimeUnit.SECONDS)) {
                    if (!Upcoming.open(m)) continue;
                    LocalDate d = Upcoming.day(m,zone);
                    if (d == null || d.isBefore(from)) continue;
                    open.add(m);
                    if (best == null || d.isBefore(best)) best = d;
                }
            } catch (Exception ignored) { f.cancel(true); }
        }
        pool.shutdownNow();
        List<Match> result = new ArrayList<>();
        for (Match m : open) if (best != null && best.equals(Upcoming.day(m,zone))) result.add(m);
        result.sort(Comparator.comparing(m -> m.isoDate == null ? "" : m.isoDate));
        return result;
    }

    static List<Match> matchesForLeague(Context c, String id, LocalDate day, boolean force) {
        return fixtures(c,id,day,force);
    }

    private static JSONObject leaguePage(Context c, String id, LocalDate day, boolean force) throws Exception {
        String url = FotMob.fixturesUrl(id);
        if (url.isEmpty()) throw new IOException("Competition not listed");
        JSONObject latest = fetch(c,url,"text/html",90_000,STALE_SCORES,force,
            body -> FotMob.leaguePage(body,id));
        Settings.reconcileFotMobTeams(c,id,FotMob.standings(latest));
        String season = FotMob.historicalSeason(latest,day,CAIRO);
        if (season.isEmpty()) return latest;
        String archive = url + "?season=" + URLEncoder.encode(season,"UTF-8");
        return fetch(c,archive,"text/html",7*24*3600_000L,30*24*3600_000L,force,body -> {
            JSONObject page = FotMob.leaguePage(body,id);
            if (!season.equals(page.getJSONObject("details").optString("selectedSeason")))
                throw new IOException("FotMob returned a different season");
            return page;
        });
    }

    static JSONObject competitionStats(Context c,String id,String season) {
        try {
            String url = FotMob.statsUrl(id);
            if (url.isEmpty()) return new JSONObject();
            if (!season.isEmpty()) url += "?season=" + URLEncoder.encode(season,"UTF-8");
            return fetch(c,url,"text/html",600_000,STALE_SCORES,false,body -> {
                JSONObject page = FotMob.leaguePage(body,id);
                if (!season.isEmpty() && !season.equals(page.getJSONObject("details").optString("selectedSeason")))
                    throw new IOException("FotMob returned a different season");
                return page;
            });
        } catch (Exception ignored) {
            return new JSONObject();
        }
    }

    static List<LeagueStats.Rank> statRanking(Context c,LeagueStats card) {
        if (!card.url.matches("https://data\\.fotmob\\.com/stats/[0-9]+/season/[0-9]+/[A-Za-z0-9_-]+\\.json"))
            return Collections.emptyList();
        try {
            return fetch(c,card.url,"application/json",600_000,STALE_SCORES,false,
                body -> LeagueStats.full(new JSONObject(body),card));
        } catch (Exception ignored) {
            return Collections.emptyList();
        }
    }

    private static final ExecutorService TV_SOURCES = Executors.newFixedThreadPool(3);
    private static final Object FOTMOB_TV_LOCK = new Object();
    private static final Object FILGOAL_TV_LOCK = new Object();
    private static final Object YALLAKORA_TV_LOCK = new Object();

    static Map<String,List<String>> tvChannels(Context context,String id,String home,String away,String iso) {
        Instant kickoff;
        try { kickoff = kickoff(iso); }
        catch (RuntimeException ignored) { return Collections.emptyMap(); }
        Map<String,Future<List<String>>> requests = new LinkedHashMap<>();
        requests.put(TvSchedule.FOTMOB,TV_SOURCES.submit(() -> tvPage(context,FOTMOB_TV_LOCK,TvSchedule.GUIDE,
            body -> TvSchedule.fotMob(body,id,kickoff))));
        requests.put(TvSchedule.FILGOAL,TV_SOURCES.submit(() -> tvPage(context,FILGOAL_TV_LOCK,TvSchedule.filGoalUrl(kickoff),
            body -> TvSchedule.filGoal(body,home,away,kickoff))));
        requests.put(TvSchedule.YALLAKORA,TV_SOURCES.submit(() -> tvPage(context,YALLAKORA_TV_LOCK,TvSchedule.yallaUrl(kickoff),
            body -> TvSchedule.yalla(body,home,away,kickoff))));
        Map<String,List<String>> result = new LinkedHashMap<>();
        for (Map.Entry<String,Future<List<String>>> request : requests.entrySet()) {
            try {
                List<String> names = request.getValue().get(18,TimeUnit.SECONDS);
                if (!names.isEmpty()) result.put(request.getKey(),names);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                return result;
            } catch (ExecutionException | TimeoutException ignored) {
                request.getValue().cancel(true);
            }
        }
        return result;
    }

    private static List<String> tvPage(Context context,Object lock,String url,BodyParser<List<String>> parser) throws Exception {
        synchronized (lock) {
            return fetch(context,url,"text/html",300_000,1800_000,false,parser);
        }
    }

    static List<Match> calendarFixtures(Context context,String league,java.time.YearMonth month) {
        try {
            return FotMob.matches(leaguePage(context,league,month.atDay(1),false),league,null,CAIRO);
        } catch (Exception ignored) {
            return Collections.emptyList();
        }
    }

    static List<Match> fixtures(Context c, String id, LocalDate day, boolean force) {
        try {
            return FotMob.matches(leaguePage(c,id,day,force),id,day,CAIRO);
        } catch (Exception ignored) {
            return Collections.emptyList();
        }
    }

    static final class Summary {
        final JSONObject data;
        final long updatedAt;
        Summary(JSONObject data, long updatedAt) {
            this.data = data;
            this.updatedAt = updatedAt;
        }
    }

    static Summary summary(Context c, String league, String event) {
        String url = FotMob.matchUrl(event);
        if (url.isEmpty()) return new Summary(new JSONObject(),0);
        long[] updated = {0};
        try {
            String response = fetch(c,url,"text/html",25_000,STALE_SCORES,false,body -> {
                if (FotMob.redirectUrl(body,event).isEmpty()) FotMob.summary(body,league,event);
                return body;
            },time -> updated[0] = time);
            String redirect = FotMob.redirectUrl(response,event);
            if (redirect.isEmpty()) return new Summary(FotMob.summary(response,league,event),updated[0]);
            JSONObject parsed = fetch(c,redirect,"text/html",25_000,STALE_SCORES,false,
                body -> FotMob.summary(body,league,event),time -> updated[0] = time);
            return new Summary(parsed,updated[0]);
        } catch (Exception ignored) {
            return new Summary(new JSONObject(),0);
        }
    }

    static List<Standing> standings(Context c, String league, boolean force) {
        return standings(c,league,null,force);
    }

    static List<Standing> standings(Context c, String league, LocalDate day, boolean force) {
        try { return FotMob.standings(leaguePage(c,league,day,force)); }
        catch (Exception ignored) { return Collections.emptyList(); }
    }

    private static final ExecutorService CLUB_DIRECTORY = Executors.newFixedThreadPool(5);

    static List<Club> searchClubs(Context c, String input) {
        String query = Club.query(input);
        if (query.isEmpty()) return Collections.emptyList();
        Map<String,Club> result = new LinkedHashMap<>();
        try {
            String url = FotMob.HOST + "/api/search/suggest?term=" + URLEncoder.encode(query,"UTF-8");
            for (Club club : fetch(c,url,"application/json",3600_000,STALE_SCORES,false,FotMob::clubs))
                result.putIfAbsent(club.id,club);
        } catch (Exception ignored) { }
        if (result.isEmpty() || result.values().stream().anyMatch(club -> club.league.isEmpty())) {
            List<Future<List<Club>>> pending = new ArrayList<>();
            for (League league : League.ALL) {
                if (!FotMob.supports(league.id) || !league.id.matches("[a-z]{3}\\.[12]")) continue;
                pending.add(CLUB_DIRECTORY.submit(() -> {
                    List<Club> matches = new ArrayList<>();
                    String url = FotMob.fixturesUrl(league.id);
                    JSONObject page = fetch(c,url,"text/html",3600_000,STALE_SCORES,false,
                        body -> FotMob.leaguePage(body,league.id));
                    for (Standing team : FotMob.standings(page)) {
                        Club club = new Club(team.id,team.name,league.id);
                        if (club.matches(query)) matches.add(club);
                    }
                    return matches;
                }));
            }
            long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(16);
            for (Future<List<Club>> request : pending) {
                try {
                    for (Club club : request.get(Math.max(0,deadline - System.nanoTime()),TimeUnit.NANOSECONDS)) {
                        Club old = result.get(club.id);
                        if (old == null || old.league.isEmpty()) result.put(club.id,club);
                    }
                } catch (InterruptedException interrupted) {
                    for (Future<?> item : pending) item.cancel(true);
                    Thread.currentThread().interrupt();
                    break;
                } catch (ExecutionException | TimeoutException ignored) {
                    request.cancel(true);
                }
            }
        }
        return new ArrayList<>(result.values());
    }

    static List<Match> teamSchedule(Context c, String league, String teamId) {
        List<Match> result = new ArrayList<>();
        if (teamId == null || teamId.isEmpty()) return result;
        for (Match match : fixtures(c,league,null,false)) {
            if (teamId.equals(match.homeId) || teamId.equals(match.awayId)) result.add(match);
        }
        return result;
    }

    static Instant kickoff(String timestamp) {
        return OffsetDateTime.parse(timestamp, DateTimeFormatter.ISO_OFFSET_DATE_TIME).toInstant();
    }

    static String localTime(String utc){
        try{return kickoff(utc).atZone(CAIRO).format(DateTimeFormatter.ofPattern("HH:mm"));}
        catch(Exception e){return "--:--";}
    }
}
