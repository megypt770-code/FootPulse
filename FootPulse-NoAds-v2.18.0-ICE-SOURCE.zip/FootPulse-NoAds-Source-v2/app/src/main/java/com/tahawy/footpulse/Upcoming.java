package com.tahawy.footpulse;

import android.content.Context;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/** Chooses what a football fan most likely wants to see first: live, then the next match, then old results. */
final class Upcoming {
    private static final long GRACE_MS = 3 * 3600_000L;

    private Upcoming() {}

    static Instant start(Match m) {
        try { return ScoreRepository.kickoff(m.isoDate); }
        catch (Exception ignored) { return Instant.MAX; }
    }

    /** Live now, or not started yet. A "not started" match whose kickoff passed hours ago is stale (postponed/unknown). */
    static boolean open(Match m) {
        if (m.isLive()) return true;
        if (m.finished()) return false;
        Instant s = start(m);
        return s != Instant.MAX && s.toEpochMilli() >= System.currentTimeMillis() - GRACE_MS;
    }

    static LocalDate day(Match m, ZoneId zone) {
        Instant s = start(m);
        return s == Instant.MAX ? null : s.atZone(zone).toLocalDate();
    }

    /** Live first, then upcoming (followed teams, pinned leagues, Champions League, then soonest), then results (latest first). */
    static List<Match> rank(Context c, List<Match> source) {
        Set<String> followed = Settings.favorites(c);
        Set<String> pinned = Settings.favoriteLeagues(c);
        List<Match> live = new ArrayList<>(), next = new ArrayList<>(), done = new ArrayList<>();
        for (Match m : source) {
            if (m.isLive()) live.add(m);
            else if (open(m)) next.add(m);
            else done.add(m);
        }
        Comparator<Match> fan = Comparator
            .comparingInt((Match m) -> m.concerns(followed) ? 0 : 1)
            .thenComparingInt(m -> pinned.contains(m.leagueId) ? 0 : League.CHAMPIONS.equals(m.leagueId) ? 1 : 2)
            .thenComparing(Upcoming::start);
        live.sort(fan);
        next.sort(fan);
        done.sort(Comparator.comparing(Upcoming::start).reversed());
        List<Match> out = new ArrayList<>(live);
        out.addAll(next);
        out.addAll(done);
        return out;
    }

    /** First day (today or later) that still has a live or upcoming match. */
    static LocalDate nextMatchDay(List<Match> schedule, LocalDate from, ZoneId zone) {
        LocalDate best = null;
        for (Match m : schedule) {
            if (!open(m)) continue;
            LocalDate d = day(m, zone);
            if (d == null || d.isBefore(from)) continue;
            if (best == null || d.isBefore(best)) best = d;
        }
        return best;
    }

    /** Nearest matchday, preferring the next one over a past one. */
    static LocalDate nearest(List<Match> schedule, LocalDate around, ZoneId zone) {
        LocalDate later = null, any = null;
        long distance = Long.MAX_VALUE;
        for (Match m : schedule) {
            LocalDate d = day(m, zone);
            if (d == null) continue;
            if (!d.isBefore(around) && (later == null || d.isBefore(later))) later = d;
            long offset = Math.abs(d.toEpochDay() - around.toEpochDay());
            if (offset < distance) { distance = offset; any = d; }
        }
        return later != null ? later : any;
    }
}
