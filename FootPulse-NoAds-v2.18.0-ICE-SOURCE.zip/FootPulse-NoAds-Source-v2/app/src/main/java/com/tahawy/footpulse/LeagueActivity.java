package com.tahawy.footpulse;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.time.*;
import java.time.format.*;
import java.util.*;

public final class LeagueActivity extends Activity {
    private League league;
    private int tab=1;
    private boolean autoDay=true;
    private JSONObject seasonPage = new JSONObject();
    private String requestedSeason = "";
    private List<String> availableSeasons = Collections.emptyList();
    private LocalDate day=LocalDate.now(ScoreRepository.CAIRO);
    private List<Standing> table=new ArrayList<>();
    private List<Match> games=new ArrayList<>();
    private LocalDate nearestDay;
    private LinearLayout root,area;
    private boolean busy=true;
    private int serial=0;
    @Override public void onCreate(Bundle saved){super.onCreate(saved);
        league=League.byId(getIntent().getStringExtra("league"));
        if (FotMob.CUP.equals(league.id)) tab = 1;
        if ("uefa.champions.qual".equals(league.id)) tab = 2;
        render();refresh(true);
    }
    private void render(){
        U.systemBar(this);root=U.col(this);root.setBackground(U.backdrop(this));setContentView(root);
        U.headingBar(this,root,league.name(this),this::finish);
        ScrollView scroll=U.scroll(this);area=U.col(this);U.pad(area,14,7,14,24);scroll.addView(area);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout cover=U.card(this);U.pad(cover,14,17,14,16);
        ImageView badge = U.logo(this,FotMob.leagueLogo(league.id),53);
        LinearLayout.LayoutParams position = U.lp(this,53,53);
        position.gravity = Gravity.CENTER_HORIZONTAL;
        cover.addView(badge,position);
        TextView heading=U.txt(this,league.name(this),22,true,U.text(this));heading.setGravity(Gravity.CENTER);cover.addView(heading);U.space(cover,10);
        TextView follow = U.leagueFollow(this,league.id,null);
        LinearLayout actions = U.row(this);
        actions.setGravity(Gravity.CENTER);
        String season = seasonPage.optJSONObject("details") == null ? requestedSeason
            : seasonPage.optJSONObject("details").optString("selectedSeason",requestedSeason);
        if (!season.isEmpty()) {
            TextView select = U.chip(this, season + "  ▾",false);
            select.setTextDirection(View.TEXT_DIRECTION_LTR);
            select.setContentDescription(Settings.t(this,"الموسم ","Season ") + season);
            select.setOnClickListener(v -> chooseSeason());
            actions.addView(select);
            View gap = new View(this);
            actions.addView(gap,U.lp(this,8,1));
        }
        actions.addView(follow);
        cover.addView(actions);
        area.addView(cover);U.space(area,14);
        HorizontalScrollView navigation = new HorizontalScrollView(this);
        navigation.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs=U.row(this);
        String[] names={Settings.t(this,"الترتيب","Table"),Settings.t(this,"المباريات","Fixtures"),
            Settings.t(this,"إحصائيات اللاعبين","Player stats"),Settings.t(this,"إحصائيات الفرق","Team stats")};
        int[] order = {1,2,3,0};
        for (int index : order) {
            TextView button = U.chip(this,names[index],tab==index);
            button.setTextSize(14);
            LinearLayout.LayoutParams lp = U.lp(this,-2,-2);
            lp.setMarginEnd(U.dp(this,6));
            tabs.addView(button,lp);
            button.setOnClickListener(v -> { tab=index; render(); });
            if (index == tab) navigation.post(() -> navigation.smoothScrollTo(button.getLeft()-U.dp(this,10),0));
        }
        navigation.addView(tabs);
        area.addView(navigation);U.space(area,14);
        if(tab==1)fixtureDateBar();
        if(busy){ProgressBar progress=new ProgressBar(this);area.addView(progress);return;}
        switch(tab){
            case 0:showStandings();break;
            case 1:showFixtures();break;
            case 2:case 3:showStats(tab==2);break;
        }
    }

    private void chooseSeason() {
        if (availableSeasons.isEmpty()) return;
        String[] seasons = availableSeasons.toArray(new String[0]);
        U.dialog(this).setTitle(Settings.t(this,"اختر الموسم","Choose season"))
            .setItems(seasons,(dialog,index) -> {
                requestedSeason = seasons[index];
                day = LocalDate.now(ScoreRepository.CAIRO);
                refresh(false,true);
            }).show();
    }

    private void showStats(boolean players) {
        List<LeagueStats> stats = LeagueStats.read(seasonPage,players);
        if (stats.isEmpty()) {
            empty(Settings.t(this,"إحصائيات هذا الموسم غير متاحة من FotMob.","FotMob statistics are unavailable for this season."));
            return;
        }
        for (LeagueStats group : stats) {
            LinearLayout card = U.card(this);
            U.pad(card,15,11,15,9);
            LinearLayout title = U.row(this);
            TextView heading = U.txt(this,group.heading(Settings.ar(this)),18,true,U.text(this));
            U.pad(heading,0,7,0,7);
            title.addView(heading,U.weight(this,1));
            if (!group.url.isEmpty()) {
                title.addView(U.txt(this,Settings.ar(this)?"‹":"›",25,true,U.accent(this)));
                card.setOnClickListener(v -> showRanking(group));
            }
            card.addView(title);
            for (LeagueStats.Rank rank : group.leaders) card.addView(statRow(group,rank,false));
            area.addView(card);
            U.space(area,11);
        }
    }

    private View statRow(LeagueStats group,LeagueStats.Rank rank,boolean showPosition) {
        LinearLayout row = U.row(this);
        U.pad(row,0,8,0,8);
        if (showPosition) row.addView(U.txt(this,String.valueOf(rank.rank),13,true,U.sub(this)),U.lp(this,30,-2));
        String image = group.players ? FotMob.playerPhoto(rank.playerId) : FotMob.teamLogo(rank.teamId);
        ImageView badge = group.players ? U.portrait(this,image,38) : U.logo(this,image,38);
        row.addView(badge);
        LinearLayout labels = U.col(this);
        U.pad(labels,9,0,9,0);
        TextView name = U.txt(this,rank.name,16,true,U.text(this));
        labels.addView(name);
        if (group.players && !rank.club.isEmpty()) labels.addView(U.txt(this,rank.club,13,false,U.sub(this)));
        row.addView(labels,U.weight(this,1));
        TextView value = U.txt(this,rank.value,16,true,rank.rank==1?U.accent(this):U.text(this));
        value.setTextDirection(View.TEXT_DIRECTION_LTR);
        value.setGravity(Gravity.CENTER);
        value.setMinWidth(U.dp(this,36));
        U.pad(value,7,2,7,2);
        if (rank.rank==1) value.setBackground(U.shape(U.accentSurface(this),13,this));
        row.addView(value);
        return row;
    }

    private void showRanking(LeagueStats group) {
        LinearLayout panel = U.col(this);
        U.pad(panel,16,4,16,8);
        ProgressBar progress = new ProgressBar(this);
        panel.addView(progress,U.lp(this,-1,42));
        AlertDialog dialog = U.dialog(this).setTitle(group.heading(Settings.ar(this)))
            .setView(panel).setPositiveButton(Settings.t(this,"إغلاق","Close"),null).show();
        new Thread(() -> {
            List<LeagueStats.Rank> result = ScoreRepository.statRanking(getApplicationContext(),group);
            runOnUiThread(() -> {
                if (isDestroyed() || !dialog.isShowing()) return;
                panel.removeAllViews();
                if (result.isEmpty()) panel.addView(U.txt(this,Settings.t(this,
                    "تعذّر تحميل القائمة الكاملة. المعروض هو المراكز المتاحة.","Full ranking unavailable. Showing the available leaders."),
                    14,false,U.sub(this)));
                List<LeagueStats.Rank> entries = result.isEmpty()?group.leaders:result;
                ListView list = new ListView(this);
                list.setAdapter(new BaseAdapter() {
                    @Override public int getCount() { return entries.size(); }
                    @Override public LeagueStats.Rank getItem(int index) { return entries.get(index); }
                    @Override public long getItemId(int index) { return index; }
                    @Override public boolean isEnabled(int index) { return false; }
                    @Override public View getView(int index,View recycled,android.view.ViewGroup parent) {
                        return statRow(group,getItem(index),true);
                    }
                });
                panel.addView(list,U.lp(this,-1,Math.min(420,entries.size()*66)));
            });
        },"league-ranking").start();
    }

    private void fixtureDateBar(){
        LinearLayout bar=U.row(this);U.pad(bar,0,4,0,13);
        TextView prev=U.chip(this,"‹",false);bar.addView(prev,U.lp(this,43,43));prev.setTextSize(27);
        prev.setOnClickListener(v->{day=day.minusDays(1);render();refresh(false);});
        TextView date=U.txt(this,day.format(DateTimeFormatter.ofPattern("EEE dd MMM",Settings.ar(this)?new Locale("ar"):Locale.ENGLISH)),15,true,U.text(this));date.setGravity(Gravity.CENTER);
        bar.addView(date,new LinearLayout.LayoutParams(0,-2,1));date.setOnClickListener(v->new DatePickerDialog(this,(picker,year,month,dayOfMonth)->{
            day=LocalDate.of(year,month+1,dayOfMonth);render();refresh(false);
        },day.getYear(),day.getMonthValue()-1,day.getDayOfMonth()).show());
        TextView next=U.chip(this,"›",false);bar.addView(next,U.lp(this,43,43));next.setTextSize(27);
        next.setOnClickListener(v->{day=day.plusDays(1);render();refresh(false);});
        area.addView(bar);
    }
    private void showStandings(){
        if(table.isEmpty()){empty(Settings.t(this,"لم تصل بيانات ترتيب هذه البطولة.","No standings returned for this competition."));return;}
        LinearLayout card=U.card(this);U.pad(card,8);
        LinearLayout header=U.row(this);U.pad(header,6,9,6,9);
        TextView club=U.txt(this,Settings.t(this,"الفريق","Club"),11,true,U.sub(this));header.addView(club,new LinearLayout.LayoutParams(0,-2,1));
        for(String name:new String[]{Settings.t(this,"ل","P"),Settings.t(this,"ف","W"),Settings.t(this,"ت","D"),Settings.t(this,"ن","Pts")}){
            TextView x=U.txt(this,name,11,true,U.sub(this));x.setGravity(Gravity.CENTER);header.addView(x,U.lp(this,33,-2));
        }
        card.addView(header);U.line(card);
        for(int i=0;i<table.size();i++){
            Standing team=table.get(i);LinearLayout row=U.row(this);U.pad(row,6,10,6,10);
            TextView rank=U.txt(this,String.valueOf(i+1),12,true,i<4?U.accent(this):U.sub(this));row.addView(rank,U.lp(this,22,-2));
            ImageView badge=U.logo(this,team.logo,23);row.addView(badge);
            TextView name=U.txt(this," "+team.name,12,true,U.text(this));name.setSingleLine();name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            for(String value:new String[]{team.played,team.won,team.drawn,team.points}){
                TextView cell=U.txt(this,value,12,true,U.text(this));cell.setGravity(Gravity.CENTER);row.addView(cell,U.lp(this,33,-2));
            }
            card.addView(row);U.line(card);row.setOnClickListener(v->U.openTeam(this,team.id,team.name,team.logo,league.id));
        }
        area.addView(card);
    }
    private void showFixtures(){
        if (games.isEmpty()) {
            empty(Settings.t(this,"لا توجد مباريات مُتاحة في هذا اليوم.","No fixtures available on this date."));
            if (nearestDay != null && !nearestDay.equals(day)) {
                boolean later = nearestDay.isAfter(day);
                TextView nearby = U.chip(this,(later ? Settings.t(this,"المباريات القادمة","Next matchday")
                    : Settings.t(this,"آخر مباريات","Latest matchday"))
                    + " · " + nearestDay.format(DateTimeFormatter.ofPattern("dd/MM")),true);
                nearby.setOnClickListener(v -> { day = nearestDay; refresh(false); });
                U.space(area,8);
                area.addView(nearby);
            }
            return;
        }
        for(Match m:games){
            LinearLayout card=U.card(this);U.pad(card,11,13,11,13);LinearLayout line=U.row(this);line.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            ImageView homeBadge=U.logo(this,m.homeLogo,22);line.addView(homeBadge);
            TextView home=U.txt(this," "+m.home,12,true,U.text(this));home.setGravity(Gravity.CENTER);line.addView(home,new LinearLayout.LayoutParams(0,-2,1));
            String value=m.homeScore==null||m.homeScore.isEmpty()?ScoreRepository.localTime(m.isoDate):m.homeScore+" - "+m.awayScore;
            TextView score=U.txt(this,value,14,true,m.isLive()?U.red():U.accent(this));score.setGravity(Gravity.CENTER);line.addView(score,U.lp(this,78,-2));
            TextView away=U.txt(this,m.away+" ",12,true,U.text(this));away.setGravity(Gravity.CENTER);line.addView(away,new LinearLayout.LayoutParams(0,-2,1));
            line.addView(U.logo(this,m.awayLogo,22));card.addView(line);card.setOnClickListener(view->U.openMatch(this,m));area.addView(card);U.space(area,9);
        }
    }
    private void empty(String message) {
        LinearLayout card = U.card(this);
        U.pad(card,15);
        card.addView(U.txt(this,message,14,false,U.sub(this)));
        area.addView(card);
    }

    private void refresh(boolean everything){ refresh(everything,false); }
    private void refresh(boolean everything,boolean seasonChanged){
        busy=true;int ticket=++serial;if(root!=null)render();
        LocalDate date=day;
        boolean jumpToNext=autoDay;
        autoDay=false;
        String season=requestedSeason;
        JSONObject cachedPage=seasonPage;
        new Thread(()->{
            Context context = getApplicationContext();
            JSONObject page = everything || seasonChanged || cachedPage.length()==0
                ? ScoreRepository.competitionStats(context,league.id,season) : cachedPage;
            ZoneId zone = ScoreRepository.CAIRO;
            List<Match> schedule = page.length()>0 ? FotMob.matches(page,league.id,null,zone)
                : season.isEmpty() ? ScoreRepository.fixtures(context,league.id,null,false) : Collections.emptyList();
            LocalDate nearby = Upcoming.nearest(schedule,date,zone);
            LocalDate chosen = seasonChanged && nearby!=null ? nearby : date;
            if (jumpToNext && !seasonChanged && season.isEmpty()) {
                LocalDate next = Upcoming.nextMatchDay(schedule,LocalDate.now(ScoreRepository.CAIRO),zone);
                if (next != null) chosen = next;
            }
            final LocalDate selectedDay = chosen;
            List<Standing> standings = season.isEmpty()
                ? ScoreRepository.standings(context,league.id,selectedDay,false) : FotMob.standings(page);
            List<Match> fixtures = season.isEmpty()
                ? ScoreRepository.matchesForLeague(context,league.id,selectedDay,false)
                : FotMob.matches(page,league.id,selectedDay,zone);
            LocalDate closest = nearby;
            runOnUiThread(() -> {
                if (ticket != serial || isDestroyed()) return;
                seasonPage = page;
                List<String> seasons = LeagueStats.seasons(page);
                if (!seasons.isEmpty()) availableSeasons = seasons;
                day = selectedDay;
                table = standings;
                games = fixtures;
                nearestDay = closest;
                busy = false;
                render();
            });
        },"league-info").start();
    }
}
