package com.tahawy.footpulse;

import java.text.Normalizer;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

final class TvSchedule {
    static final String FOTMOB = "FotMob";
    static final String FILGOAL = "FilGoal";
    static final String YALLAKORA = "Yallakora";
    static final String GUIDE = FotMob.HOST + "/tv-guide/me";

    private static final ZoneId FILGOAL_ZONE = ZoneOffset.ofHours(2);
    private static final ZoneId CAIRO = ZoneId.of("Africa/Cairo");
    private static final DateTimeFormatter YK_DATE = DateTimeFormatter.ofPattern("M/d/uuuu",Locale.ROOT);
    private static final DateTimeFormatter FG_DATE = DateTimeFormatter.ofPattern("dd-MM-uuuu",Locale.ROOT);
    private static final Pattern YK_DAY = Pattern.compile("(?is)<button\\b[^>]*class=\"[^\"]*\\bdayTabLinks\\s+active\\b[^\"]*\"[^>]*date=\"([^\"]+)\"");
    private static final Pattern YK_ROW = Pattern.compile("(?is)<div\\s+liveScoreMatchId=\"\\d+\"[^>]*>(.*?)(?=<div\\s+liveScoreMatchId=|</section>)");
    private static final Pattern YK_TEAM = Pattern.compile("(?is)<div class=\"teams team[AB]\"[^>]*>.*?<p>(.*?)</p>\\s*</div>");
    private static final Pattern YK_TIME = Pattern.compile("(?is)<span class=\"time\"[^>]*>\\s*(\\d{1,2}:\\d{2})");
    private static final Pattern YK_CHANNEL = Pattern.compile("(?is)<div class=\"channel(?: [^\"]*)?\"[^>]*>(.*?)</div>");

    private static final Pattern FG_DAY = Pattern.compile("data-current-date=\"(\\d{4}-\\d{2}-\\d{2})\"");
    private static final Pattern FG_ROW = Pattern.compile("(?is)<div class=\"cin_cntnr\"[^>]*>(.*?<div class=\"match-aux\"[^>]*>.*?</div>)");
    private static final Pattern FG_TEAM = Pattern.compile("(?is)<a\\s+href=\"/teams/[^\"]+\"[^>]*>\\s*(?:<img[^>]*>\\s*)?<strong>(.*?)</strong>");
    private static final Pattern FG_TIME = Pattern.compile("#fb_calendar\"[^<]*></use></svg>\\s*(\\d{2}-\\d{2}-\\d{4})\\s*-\\s*(\\d{1,2}:\\d{2})");
    private static final Pattern FG_CHANNEL = Pattern.compile("(?is)#fb_screen\"[^<]*></use></svg>(.*?)</span>");

    private static final Map<String,String> TEAM_ALIASES = new HashMap<>();
    static {
        TEAM_ALIASES.put(key("الأهلي"),"al ahly");
        TEAM_ALIASES.put(key("الزمالك"),"zamalek");
        TEAM_ALIASES.put(key("بيراميدز"),"pyramids");
        TEAM_ALIASES.put(key("المقاولون العرب"),"arab contractors");
        TEAM_ALIASES.put(key("المصرية للاتصالات"),"telecom egypt");
        TEAM_ALIASES.put(key("وادي دجلة"),"wadi degla");
        TEAM_ALIASES.put(key("كهرباء الإسماعيلية"),"kahraba ismailia");
        TEAM_ALIASES.put(key("الإسماعيلي"),"ismaily");
        TEAM_ALIASES.put(key("المصري"),"al masry");
        TEAM_ALIASES.put(key("الاتحاد السكندري"),"al ittihad alexandria");
        TEAM_ALIASES.put(key("سموحة"),"smouha");
        TEAM_ALIASES.put(key("إنبي"),"enppi");
        TEAM_ALIASES.put(key("البنك الأهلي"),"national bank of egypt");
        TEAM_ALIASES.put(key("طلائع الجيش"),"talaea el gaish");
        TEAM_ALIASES.put(key("سيراميكا كليوباترا"),"ceramica cleopatra");
        TEAM_ALIASES.put(key("حرس الحدود"),"haras el hodoud");
        TEAM_ALIASES.put(key("مودرن سبورت"),"modern sport");
        TEAM_ALIASES.put(key("الجونة"),"el gouna");
        TEAM_ALIASES.put(key("بتروجيت"),"petrojet");
        TEAM_ALIASES.put(key("غزل المحلة"),"ghazl el mahalla");
        TEAM_ALIASES.put(key("فاركو"),"pharco");
        TEAM_ALIASES.put(key("زد"),"zed");
        TEAM_ALIASES.put(key("سمنود الرياضي"),"samanoud");
        TEAM_ALIASES.put(key("ريال مدريد"),"real madrid");
        TEAM_ALIASES.put(key("برشلونة"),"barcelona");
        TEAM_ALIASES.put(key("أتلتيكو مدريد"),"atletico madrid");
        TEAM_ALIASES.put(key("رايو فاييكانو"),"rayo vallecano");
        TEAM_ALIASES.put(key("أتلتيك بلباو"),"athletic bilbao");
        TEAM_ALIASES.put(key("مانشستر يونايتد"),"manchester united");
        TEAM_ALIASES.put(key("مانشستر سيتي"),"manchester city");
        TEAM_ALIASES.put(key("ليفربول"),"liverpool");
        TEAM_ALIASES.put(key("أرسنال"),"arsenal");
        TEAM_ALIASES.put(key("تشيلسي"),"chelsea");
        TEAM_ALIASES.put(key("أستون فيلا"),"aston villa");
        TEAM_ALIASES.put(key("نيوكاسل"),"newcastle united");
        TEAM_ALIASES.put(key("ليدز"),"leeds united");
        TEAM_ALIASES.put(key("توتنهام"),"tottenham hotspur");
        TEAM_ALIASES.put(key("برينتفورد"),"brentford");
        TEAM_ALIASES.put(key("بورنموث"),"bournemouth");
        TEAM_ALIASES.put(key("فولهام"),"fulham");
        TEAM_ALIASES.put(key("باريس سان جيرمان"),"paris saint germain");
        TEAM_ALIASES.put(key("بايرن ميونيخ"),"bayern munich");
        TEAM_ALIASES.put(key("إنتر"),"inter");
        TEAM_ALIASES.put(key("إنتر ميلان"),"inter");
        TEAM_ALIASES.put(key("ميلان"),"milan");
        TEAM_ALIASES.put(key("يوفنتوس"),"juventus");
        TEAM_ALIASES.put(key("النصر"),"al nassr");
        TEAM_ALIASES.put(key("الهلال"),"al hilal");
        TEAM_ALIASES.put(key("اتحاد جدة"),"al ittihad");
        TEAM_ALIASES.put(key("أهلي جدة"),"al ahli");
        TEAM_ALIASES.put(key("مصر"),"egypt");
        TEAM_ALIASES.put(key("ر.سانتاندير"),"racing santander");
        TEAM_ALIASES.put(key("راسينج سانتاندير"),"racing santander");
        TEAM_ALIASES.put(key("م. السويس بتروجت"),"petrojet");
        TEAM_ALIASES.put(key("ديبورتيفو لاكورونيا"),"deportivo a coruna");
        TEAM_ALIASES.put(key("إشبيلية"),"sevilla");
        TEAM_ALIASES.put(key("أوساسونا"),"osasuna");
        TEAM_ALIASES.put(key("بنفيكا"),"benfica");
        TEAM_ALIASES.put(key("سندرلاند"),"sunderland");
        TEAM_ALIASES.put(key("برايتون"),"brighton");
        TEAM_ALIASES.put(key("كريستال بالاس"),"crystal palace");
        TEAM_ALIASES.put(key("إبسويتش تاون"),"ipswich town");
        TEAM_ALIASES.put(key("إلتشي"),"elche");
        TEAM_ALIASES.put(key("ريال بيتيس"),"real betis");
        TEAM_ALIASES.put(key("ريال سوسيداد"),"real sociedad");
        TEAM_ALIASES.put(key("رايو فايكانو"),"rayo vallecano");
        TEAM_ALIASES.put(key("سيلتا فيجو"),"celta vigo");
        TEAM_ALIASES.put(key("ليفانتي"),"levante");
        TEAM_ALIASES.put(key("فياريال"),"villarreal");
        TEAM_ALIASES.put(key("خيتافي"),"getafe");
        TEAM_ALIASES.put(key("فيورنتينا"),"fiorentina");
        TEAM_ALIASES.put(key("أودينيزي"),"udinese");
        TEAM_ALIASES.put(key("كومو"),"como");
        TEAM_ALIASES.put(key("بارما"),"parma");
        TEAM_ALIASES.put(key("تورينو"),"torino");
        TEAM_ALIASES.put(key("روما"),"roma");
    }

    static String filGoalUrl(Instant kickoff) {
        return "https://www.filgoal.com/matches?date=" + kickoff.atZone(FILGOAL_ZONE).toLocalDate();
    }

    static String yallaUrl(Instant kickoff) {
        return "https://www.yallakora.com/matches-center?date=" + cairoDay(kickoff).format(YK_DATE).replace("/","%2F");
    }

    static List<String> fotMob(String page,String id,Instant kickoff) throws Exception {
        if (id == null || id.isEmpty()) return Collections.emptyList();
        JSONObject days = FotMob.pageData(page).getJSONObject("fallback").getJSONObject("tvguide-groups:me");
        Set<String> names = new LinkedHashSet<>();
        java.util.Iterator<String> dateKeys = days.keys();
        while (dateKeys.hasNext()) {
            JSONArray leagues = days.optJSONArray(dateKeys.next());
            if (leagues == null) continue;
            for (int i=0;i<leagues.length();i++) {
                JSONObject league = leagues.optJSONObject(i);
                JSONArray matches = league == null ? null : league.optJSONArray("matches");
                if (matches == null) continue;
                for (int k=0;k<matches.length();k++) {
                    JSONObject fixture = matches.optJSONObject(k);
                    if (fixture == null || !id.equals(fixture.optString("id"))) continue;
                    try {
                        if (!near(kickoff,Instant.parse(fixture.optString("utcTime")))) continue;
                    } catch (java.time.DateTimeException ignored) { continue; }
                    JSONArray channels = fixture.optJSONArray("channels");
                    if (channels == null) continue;
                    for (int n=0;n<channels.length();n++) {
                        JSONObject channel = channels.optJSONObject(n);
                        if (channel != null) add(names,channel.optString("name"));
                    }
                }
            }
        }
        return new ArrayList<>(names);
    }

    static List<String> filGoal(String page,String home,String away,Instant kickoff) {
        LocalDate day = kickoff.atZone(FILGOAL_ZONE).toLocalDate();
        Matcher shown = FG_DAY.matcher(page);
        if (!shown.find() || !day.toString().equals(shown.group(1))) return Collections.emptyList();
        return channels(page,home,away,kickoff,FG_ROW,FG_TEAM,FG_TIME,FG_CHANNEL,true);
    }

    static List<String> yalla(String page,String home,String away,Instant kickoff) {
        Matcher shown = YK_DAY.matcher(page);
        if (!shown.find() || !cairoDay(kickoff).format(YK_DATE).equals(shown.group(1))) return Collections.emptyList();
        return channels(page,home,away,kickoff,YK_ROW,YK_TEAM,YK_TIME,YK_CHANNEL,false);
    }

    private static List<String> channels(String page,String home,String away,Instant kickoff,
            Pattern rowPattern,Pattern teamPattern,Pattern timePattern,Pattern channelPattern,boolean dated) {
        String first = teamKey(home), second = teamKey(away);
        if (first.isEmpty() || second.isEmpty() || first.equals(second)) return Collections.emptyList();
        Matcher rows = rowPattern.matcher(page);
        Set<String> names = new LinkedHashSet<>();
        int matched = 0;
        ZoneId zone = dated ? FILGOAL_ZONE : CAIRO;
        LocalDate day = kickoff.atZone(zone).toLocalDate();
        while (rows.find()) {
            String row = rows.group(1);
            Matcher team = teamPattern.matcher(row);
            if (!team.find() || !first.equals(teamKey(team.group(1)))) continue;
            if (!team.find() || !second.equals(teamKey(team.group(1)))) continue;
            Matcher time = timePattern.matcher(row);
            if (!time.find()) continue;
            if (dated && !day.format(FG_DATE).equals(time.group(1))) continue;
            try {
                LocalTime local = LocalTime.parse(time.group(dated ? 2 : 1),DateTimeFormatter.ofPattern("H:mm",Locale.ROOT));
                if (!near(kickoff,day.atTime(local).atZone(zone).toInstant())) continue;
            } catch (java.time.DateTimeException ignored) { continue; }
            if (++matched > 1) return Collections.emptyList();
            Matcher channel = channelPattern.matcher(row);
            while (channel.find()) add(names,clean(channel.group(1)));
        }
        return new ArrayList<>(names);
    }

    static String channelKey(String channel) {
        String normalized = key(channel).replace("بي ان سبورت","bein sports")
            .replace("بى ان سبورت","bein sports").replace("اون سبورت","on sport");
        return normalized.replaceAll("\\bhd\\b","").replaceAll("[^\\p{L}\\p{N}]","");
    }

    private static void add(Set<String> names,String value) {
        if (!value.trim().isEmpty() && value.length() < 90 && !channelKey(value).isEmpty()
            && !value.matches("[-—]+") && !value.equals("غير معلن")) names.add(value.trim());
    }

    private static boolean near(Instant first,Instant second) {
        return Duration.between(first,second).abs().compareTo(Duration.ofMinutes(30)) <= 0;
    }

    private static LocalDate cairoDay(Instant kickoff) { return kickoff.atZone(CAIRO).toLocalDate(); }

    private static String teamKey(String value) {
        String clean = clean(value);
        String raw = key(clean);
        String normalized = TEAM_ALIASES.getOrDefault(raw,raw)
            .replaceAll("\\b(?:afc|fc|sc|cf|club)\\b","").replaceAll(" +"," ").trim();
        switch (normalized) {
            case "al mokawloon al arab": case "al mokawloon": case "el mokawloon": case "el mokawloon al arab": return "arab contractors";
            case "we": return "telecom egypt";
            case "petrojet suez": return "petrojet";
            case "ghazl al mahalla": return "ghazl el mahalla";
            case "brighton hove albion": return "brighton";
            case "deportivo la coruna": return "deportivo a coruna";
            case "el masry": return "al masry";
            case "el ahly": return "al ahly";
            case "el ismaili": case "ismaily": case "ismaili": return "ismaily";
            case "tala ea el gaish": case "el gaish": return "talaea el gaish";
            case "kahraba ismailia": case "kahraba al ismailia": return "kahraba ismailia";
            case "el gounah": return "el gouna";
            case "national bank": case "national bank egypt": return "national bank of egypt";
            case "inter milan": return "inter";
            case "athletic": return "athletic bilbao";
            default: return normalized;
        }
    }

    private static String key(String value) {
        return Normalizer.normalize(value.toLowerCase(Locale.ROOT),Normalizer.Form.NFD)
            .replaceAll("\\p{M}","").replace("ى","ي").replace("ـ","")
            .replaceAll("[^\\p{L}\\p{N}]+"," ").trim();
    }

    private static String clean(String value) {
        if (value == null) return "";
        return value.replaceAll("<[^>]+>","").replace("&amp;","&").replace("&nbsp;"," ")
            .replace("&#039;","'").replace("&#39;","'").replace("&apos;","'").replace("&quot;","\"").trim();
    }
}
