package com.tahawy.footpulse;

import android.Manifest;
import android.app.*;
import android.app.job.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import java.time.LocalDate;
import java.util.*;

/** Optional best-effort score change checks (Android may delay jobs during battery saver / Doze). */
public class ScoreAlertJob extends JobService {
    private static final int JOB_ID=730121;
    private static final String CHANNEL="footpulse_goals";
    static void schedule(Context c){
        JobScheduler jobs=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if(jobs==null)return;
        jobs.cancel(JOB_ID);
        if(!Settings.alerts(c)||Settings.favorites(c).isEmpty())return;
        JobInfo job=new JobInfo.Builder(JOB_ID,new ComponentName(c,ScoreAlertJob.class))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(15*60*1000L)
            .build();
        jobs.schedule(job);
    }
    @Override public boolean onStartJob(JobParameters params){
        new Thread(()->{try{checkScores();}finally{jobFinished(params,false);}},"footpulse-notifications").start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters params){return true;}
    private void checkScores(){
        Set<String> followed=Settings.favorites(this);
        Set<String> leagues=new HashSet<>();
        for(String id:followed){String league=Settings.teamLeague(this,id);if(!league.isEmpty())leagues.add(league);}
        if(followed.isEmpty()||leagues.isEmpty())return;
        int leagueCount=0;
        for(String league:leagues){
            if(leagueCount++>=8)break;
            List<Match> matches=ScoreRepository.matchesForLeague(this,league,LocalDate.now(ScoreRepository.CAIRO),true);
            for(Match m:matches){
                if(!m.concerns(followed)||m.homeScore==null||m.homeScore.isEmpty()||m.awayScore==null||m.awayScore.isEmpty())continue;
                String key="last_"+m.matchKey();String score=m.homeScore+":"+m.awayScore;
                String prior=Settings.prefs(this).getString(key,null);
                Settings.prefs(this).edit().putString(key,score).apply();
                if(prior!=null&&!prior.equals(score) && m.isLive() && !LiveMatchAlerts.watching(m.matchKey()))notifyChange(m);
            }
        }
    }
    private void notifyChange(Match match){
        if(!Settings.alerts(this))return;
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationManager manager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if(manager==null)return;
        NotificationChannel ch=new NotificationChannel(CHANNEL,Settings.t(this,"تحديثات النتائج","Score updates"),NotificationManager.IMPORTANCE_DEFAULT);
        manager.createNotificationChannel(ch);
        Intent intent=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification notification=new Notification.Builder(this,CHANNEL)
            .setSmallIcon(R.drawable.ic_app)
            .setContentTitle(match.home+"  "+match.homeScore+" - "+match.awayScore+"  "+match.away)
            .setContentText(Settings.t(this,"تغيرت النتيجة • ","Score changed • ")+League.byId(match.leagueId).name(this))
            .setContentIntent(pi).setAutoCancel(true).build();
        manager.notify(match.matchKey().hashCode(),notification);
    }
}
