package com.tahawy.footpulse;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.view.*;
import android.widget.*;

/** Self-contained native UI, zero UI SDK dependencies. */
final class U {
    static int bg(Context c){return Settings.dark(c)?0xFF071A37:0xFFE7F3FF;}
    static int surface(Context c){return Settings.dark(c)?0xFF153C70:0xFFF7FBFF;}
    static int elevated(Context c){return Settings.dark(c)?0xFF1C4D86:0xFFD6E9FA;}
    static int text(Context c){return Settings.dark(c)?0xFFF2F9FF:0xFF102D4C;}
    static int sub(Context c){return Settings.dark(c)?0xFFBCD6F1:0xFF46617D;}
    static int accent(Context c){return Settings.dark(c)?0xFF8DDFFF:0xFF0764AA;}
    static int chrome(Context c){return Settings.dark(c)?0xFF102E5F:0xFFD9ECFF;}
    static int section(Context c){return Settings.dark(c)?0xFF153768:0xFFDCEFFF;}
    static int accentSurface(Context c){return Settings.dark(c)?0xFF1A5691:0xFFCCE9FF;}
    static int selectedInk(){return 0xFF062746;}
    static int border(Context c){return Settings.dark(c)?0xFF3B75AC:0xFFA3CAE9;}
    static int dialogTheme(Context c) {
        return Settings.dark(c) ? R.style.FootPulseDarkDialog : R.style.FootPulseDialog;
    }
    static AlertDialog.Builder dialog(Context c){return new AlertDialog.Builder(c,dialogTheme(c));}

    static Drawable backdrop(Context c) {
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{chrome(c),bg(c)});
        LayerDrawable layers = new LayerDrawable(new Drawable[]{base,new IceArtwork(false)});
        layers.setLayerHeight(1,dp(c,112));
        layers.setLayerGravity(1,Gravity.TOP | Gravity.FILL_HORIZONTAL);
        return layers;
    }

    static Drawable stadium(Context c) {
        if (!Settings.dark(c)) return glass(c,15);
        return new IceArtwork(true);
    }

    static GradientDrawable glass(Context c,int radius) {
        GradientDrawable panel = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{surface(c),Settings.dark(c) ? 0xFF0E2A52 : 0xFFE3F1FF});
        panel.setCornerRadius(dp(c,radius));
        panel.setStroke(dp(c,1),border(c));
        return panel;
    }

    static GradientDrawable matchdayHeading(Context c) {
        GradientDrawable panel = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            Settings.dark(c) ? new int[]{0xFF205B88,0xFF163660} : new int[]{0xFFB9EBFF,0xFFE9F5FF});
        float radius = dp(c,14);
        panel.setCornerRadii(new float[]{radius,radius,radius,radius,0,0,0,0});
        panel.setStroke(dp(c,1),border(c));
        return panel;
    }

    static GradientDrawable outlined(Context c,int fill,int edge,int radius) {
        GradientDrawable panel = shape(fill,radius,c);
        panel.setStroke(dp(c,1),edge);
        return panel;
    }

    static GradientDrawable selected(Context c) {
        GradientDrawable pill = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xFF91EDFF,0xFF5CBFFB});
        pill.setCornerRadius(dp(c,11));
        return pill;
    }

    static TextView scorePlate(Context c,String value,int size) {
        TextView score = txt(c,value,size,true,accent(c));
        score.setGravity(Gravity.CENTER);
        score.setSingleLine();
        score.setTextDirection(View.TEXT_DIRECTION_LTR);
        score.setBackground(outlined(c,Settings.dark(c)?0xDE0C2D5C:0xFFF1F9FF,accent(c),10));
        pad(score,5,1,5,1);
        return score;
    }

    static GradientDrawable icePanel(Context c,int radius,boolean bright) {
        GradientDrawable panel = new GradientDrawable(GradientDrawable.Orientation.TL_BR,bright
            ? new int[]{0xFF288DCF,0xFF114584,0xFF1869AF}
            : new int[]{0xFF1F65A5,0xFF113869});
        panel.setCornerRadius(dp(c,radius));
        panel.setStroke(dp(c,1),bright ? 0xFF84E5FF : 0xFF548FCB);
        return panel;
    }

    static GradientDrawable iceAction(Context c,int radius) {
        GradientDrawable panel = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0xFF087CC6,0xFF00509A,0xFF075EAA});
        panel.setCornerRadius(dp(c,radius));
        panel.setStroke(dp(c,1),0xFF80DEFF);
        return panel;
    }

    static Drawable homeBackdrop(Context c) {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,Settings.dark(c)
            ? new int[]{0xFF125FB4,0xFF0A3671,0xFF071A37,0xFF071A37}
            : new int[]{0xFFCFEAFF,0xFFE6F4FF,0xFFF1F8FF});
    }

    static LinearLayout navigation(Activity activity,int selected,java.util.function.IntConsumer choose) {
        LinearLayout bar = col(activity);
        pad(bar,7,3,7,5);
        LinearLayout tabs = row(activity);
        pad(tabs,4,3,4,3);
        GradientDrawable dock = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xFFF0F8FF,0xFFCDE9FF});
        dock.setCornerRadius(dp(activity,25));
        dock.setStroke(dp(activity,1),0xFFA5D9FF);
        tabs.setBackground(dock);
        int[] icons={R.drawable.ui_ball,R.drawable.ui_cup,R.drawable.ui_heart,R.drawable.ui_dots};
        String[] ar={"المباريات","الدوريات","المتابعة","المزيد"};
        String[] en={"Matches","Leagues","Following","More"};
        int[] destinations={0,2,3,4};
        for (int i=0;i<icons.length;i++) {
            final int target = destinations[i];
            boolean current = target == selected;
            int color = current ? Color.WHITE : 0xFF143B66;
            LinearLayout tab = col(activity);
            tab.setGravity(Gravity.CENTER);
            tab.setSelected(current);
            if (current) tab.setBackground(iceAction(activity,19));
            tab.addView(icon(activity,icons[i],22,color));
            space(tab,4);
            TextView label=txt(activity,Settings.t(activity,ar[i],en[i]),11,current,color);
            label.setSingleLine();
            tab.addView(label);
            tab.setContentDescription(label.getText());
            tab.setOnClickListener(v -> choose.accept(target));
            tabs.addView(tab,new LinearLayout.LayoutParams(0,dp(activity,54),1));
        }
        bar.addView(tabs,lp(activity,-1,-2));
        return bar;
    }

    static ImageView icon(Context c,int resource,int size,int color){
        ImageView image=new ImageView(c);
        image.setImageResource(resource);
        image.setColorFilter(color);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setLayoutParams(lp(c,size,size));
        return image;
    }
    static int selection(){return 0xFF9CDFFF;}
    static int iceLine(){return 0xFF55BBFF;}
    static int red(){return Color.rgb(206,47,55);}
    static int dp(Context c,float a){return (int)(a*c.getResources().getDisplayMetrics().density+0.5f);}
    static GradientDrawable shape(int color,int radius,Context c){GradientDrawable b=new GradientDrawable();b.setColor(color);b.setCornerRadius(dp(c,radius));return b;}
    static LinearLayout col(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;}
    static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    static TextView txt(Context c,String s,int size,boolean bold,int color){
        TextView v=new TextView(c);v.setText(s);v.setTextColor(color);v.setTextSize(size);
        v.setGravity(Gravity.CENTER_VERTICAL);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setIncludeFontPadding(false);return v;
    }
    static void pad(View v,int all){int p=dp(v.getContext(),all);v.setPadding(p,p,p,p);}
    static void pad(View v,int left,int top,int right,int bottom){Context c=v.getContext();v.setPadding(dp(c,left),dp(c,top),dp(c,right),dp(c,bottom));}
    static LinearLayout.LayoutParams lp(Context c,int width,int height){return new LinearLayout.LayoutParams(width<0?width:dp(c,width),height<0?height:dp(c,height));}
    static LinearLayout.LayoutParams weight(Context c,float w){return new LinearLayout.LayoutParams(0,-2,w);}
    static TextView chip(Context c,String s,boolean active){
        TextView t=txt(c,s,13,active,active?selectedInk():text(c));
        t.setGravity(Gravity.CENTER);pad(t,14,9,14,9);
        t.setBackground(active?selected(c):glass(c,21));return t;
    }
    static void space(LinearLayout p,int h){View v=new View(p.getContext());p.addView(v,lp(p.getContext(),1,h));}
    static void line(LinearLayout parent){View v=new View(parent.getContext());v.setBackgroundColor(border(parent.getContext()));parent.addView(v,new LinearLayout.LayoutParams(-1,dp(parent.getContext(),1)));}
    static ScrollView scroll(Context c){ScrollView s=new ScrollView(c);s.setFillViewport(false);s.setVerticalScrollBarEnabled(false);return s;}
    static TextView heading(Context c,String s){TextView t=txt(c,s,20,true,text(c));pad(t,4,8,4,10);return t;}
    static LinearLayout card(Context c){LinearLayout l=col(c);l.setBackground(glass(c,21));return l;}
    static ImageView logo(Context c,String url,int size){
        ImageView v=new ImageView(c);v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setImageResource(com.tahawy.footpulse.R.drawable.ic_app);
        LinearLayout.LayoutParams p=lp(c,size,size);v.setLayoutParams(p);LogoLoader.into(v,url);return v;
    }
    static ImageView portrait(Context c,String url,int size){
        ImageView view = logo(c,url,size);
        view.setBackground(shape(elevated(c),size/2,c));
        view.setClipToOutline(true);
        view.setScaleType(ImageView.ScaleType.CENTER_CROP);
        return view;
    }
    static TextView leagueFollow(Context c,String id,Runnable onChanged) {
        TextView button = chip(c,"",false);
        Runnable update = () -> {
            boolean following = Settings.isLeagueFavorite(c,id);
            button.setText(following ? Settings.t(c,"★ تتابع البطولة","★ Following league")
                : Settings.t(c,"☆ متابعة البطولة","☆ Follow league"));
            button.setSelected(following);
            button.setTextColor(following ? selectedInk() : text(c));
            button.setBackground(following ? selected(c) : glass(c,18));
        };
        update.run();
        button.setOnClickListener(v -> {
            Settings.toggleLeague(c,id);
            update.run();
            if (onChanged != null) onChanged.run();
        });
        return button;
    }

    static void openMatch(Activity c,Match m){c.startActivity(matchIntent(c,m));}
    static android.content.Intent matchIntent(Context c,Match m){
        android.content.Intent i=new android.content.Intent(c,MatchActivity.class);
        i.putExtra("id",m.id);i.putExtra("league",m.leagueId);i.putExtra("home",m.home);i.putExtra("away",m.away);
        i.putExtra("homeId",m.homeId);i.putExtra("awayId",m.awayId);i.putExtra("homeLogo",m.homeLogo);i.putExtra("awayLogo",m.awayLogo);
        i.putExtra("homeScore",m.homeScore);i.putExtra("awayScore",m.awayScore);i.putExtra("state",m.state);
        i.putExtra("competitionName",m.competitionName);i.putExtra("status",m.status);i.putExtra("iso",m.isoDate);i.putExtra("venue",m.venue);
        return i;
    }
    static void openTeam(Activity c,String id,String name,String logo,String league){
        android.content.Intent i=new android.content.Intent(c,TeamActivity.class);
        i.putExtra("teamId",id);i.putExtra("teamName",name);i.putExtra("logo",logo);i.putExtra("league",league);
        c.startActivity(i);
    }
    static TextView iconButton(Context c,String glyph,Runnable click){
        TextView t=txt(c,glyph,23,false,text(c));t.setGravity(Gravity.CENTER);
        t.setBackground(shape(elevated(c),22,c));
        if(click!=null)t.setOnClickListener(v->click.run());return t;
    }
    static TextView smallPill(Context c,String value,boolean accent){
        TextView t=txt(c,value,11,true,accent?accent(c):sub(c));
        pad(t,8,4,8,4);t.setGravity(Gravity.CENTER);
        if(accent)t.setBackground(shape(accentSurface(c),14,c));return t;
    }
    static void headingBar(Activity c,LinearLayout root,String title,Runnable back){
        LinearLayout bar=row(c);
        pad(bar,16,9,16,10);
        FrameLayout button=roundAction(c,R.drawable.ui_back,Settings.t(c,"رجوع","Back"),back);
        if (Settings.ar(c)) button.setScaleX(-1);
        bar.addView(button,lp(c,44,44));
        TextView caption=txt(c,title,19,true,text(c));
        caption.setGravity(Gravity.CENTER);
        bar.addView(caption,new LinearLayout.LayoutParams(0,dp(c,46),1));
        bar.addView(new View(c),lp(c,44,44));
        root.addView(bar);
    }

    static FrameLayout roundAction(Context c,int resource,String description,Runnable click) {
        FrameLayout button = new FrameLayout(c);
        button.setBackground(glass(c,24));
        button.addView(icon(c,resource,20,text(c)),
            new FrameLayout.LayoutParams(dp(c,20),dp(c,20),Gravity.CENTER));
        button.setContentDescription(description);
        button.setOnClickListener(v -> click.run());
        return button;
    }

    static int liveInk(Context c) {
        return Settings.dark(c) ? 0xFFFFB2AB : 0xFF9A2632;
    }

    static void systemBar(Activity a){
        a.getWindow().setStatusBarColor(chrome(a));a.getWindow().setNavigationBarColor(bg(a));
        int flags=0;if(!Settings.dark(a))flags=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        a.getWindow().getDecorView().setSystemUiVisibility(flags);
        a.getWindow().getDecorView().setLayoutDirection(Settings.ar(a)?View.LAYOUT_DIRECTION_RTL:View.LAYOUT_DIRECTION_LTR);
    }
}
