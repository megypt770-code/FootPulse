package com.tahawy.footpulse;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

final class LineupPortraits extends LinearLayout {
    LineupPortraits(Context context,PitchLineup lineup) {
        super(context);
        setOrientation(VERTICAL);
        setBackground(U.glass(context,20));
        U.pad(this,5,10,5,10);
        for (List<PitchLineup.Player> players : lineup.lines) {
            LinearLayout row = U.row(context);
            row.setGravity(Gravity.TOP);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            for (PitchLineup.Player player : players) row.addView(cell(context,player),U.weight(context,1));
            addView(row);
        }
    }

    private LinearLayout cell(Context context,PitchLineup.Player player) {
        LinearLayout box = U.col(context);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        U.pad(box,2,6,2,7);
        FrameLayout avatar = new FrameLayout(context);
        int size = U.dp(context,43);
        avatar.addView(U.portrait(context,player.photo,43),new FrameLayout.LayoutParams(size,size,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL));
        if (player.rating.matches("[0-9]+(?:\\.[0-9]+)?")) {
            double rating = Double.parseDouble(player.rating);
            int color = rating >= 8.5 ? 0xFF73CEFF : rating >= 7 ? 0xFF91E696 : rating >= 6 ? 0xFFFFCD83 : 0xFFFFAD83;
            TextView badge = U.txt(context,player.rating + (player.star ? " ★" : ""),12,true,0xFF0C193D);
            badge.setBackground(U.shape(color,10,context));
            badge.setContentDescription(Settings.t(context,"التقييم ","Rating ") + player.rating);
            U.pad(badge,5,0,5,0);
            avatar.addView(badge,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT));
        }
        if (!player.subOut.isEmpty()) {
            TextView substitution = U.txt(context,"↓"+player.subOut+"′",10,true,0xFF641E25);
            substitution.setBackground(U.shape(0xFFFFC7C9,10,context));
            substitution.setContentDescription(Settings.t(context,"خرج في الدقيقة ","Substituted in minute ") + player.subOut);
            U.pad(substitution,3,0,3,0);
            avatar.addView(substitution,new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.LEFT));
        }
        box.addView(avatar,U.lp(context,57,54));
        TextView label = U.txt(context,(player.captain?"© ":"")+(player.number.isEmpty()?"":player.number+" ")+player.name,13,true,U.text(context));
        label.setGravity(Gravity.CENTER);
        label.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        label.setMaxLines(2);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        box.addView(label,U.lp(context,-1,-2));
        LinearLayout badges = U.row(context);
        badges.setGravity(Gravity.CENTER);
        if (player.events.contains("goal")) marker(badges,"⚽",Settings.t(context,"هدف","Goal"),U.accentSurface(context),U.text(context));
        if (player.events.contains("ownGoal")) marker(badges,"⚽",Settings.t(context,"هدف عكسي","Own goal"),0xFFFFC7C9,0xFF641E25);
        if (player.events.contains("assist")) marker(badges,"↗",Settings.t(context,"تمريرة حاسمة","Assist"),U.accentSurface(context),U.text(context));
        if (player.events.contains("redCard") || player.events.contains("secondYellow"))
            marker(badges,"▮",Settings.t(context,"بطاقة حمراء","Red card"),0xFFFFC7C9,0xFF641E25);
        else if (player.events.contains("yellowCard"))
            marker(badges,"▮",Settings.t(context,"بطاقة صفراء","Yellow card"),0xFFFFE295,0xFF6A4500);
        if (badges.getChildCount()>0) box.addView(badges);
        return box;
    }
    private void marker(LinearLayout row,String icon,String description,int background,int ink) {
        Context context = row.getContext();
        TextView view = U.txt(context,icon,10,true,ink);
        view.setGravity(Gravity.CENTER);
        view.setBackground(U.shape(background,9,context));
        view.setContentDescription(description);
        row.addView(view,U.lp(context,16,16));
    }
}

