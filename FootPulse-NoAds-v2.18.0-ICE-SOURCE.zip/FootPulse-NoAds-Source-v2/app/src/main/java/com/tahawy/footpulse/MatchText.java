package com.tahawy.footpulse;

import android.content.Context;
import java.util.Locale;

final class MatchText {
    static String key(String value) {
        return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");
    }

    static String event(Context c,String kind) {
        switch (key(kind)) {
            case "goal": return Settings.t(c,"هدف","Goal");
            case "owngoal": return Settings.t(c,"هدف عكسي","Own goal");
            case "yellow": case "yellowcard": return Settings.t(c,"إنذار","Yellow card");
            case "red": case "redcard": return Settings.t(c,"طرد","Red card");
            case "yellowred": case "yellowredcard": case "secondyellow": case "secondyellowcard":
                return Settings.t(c,"طرد بإنذار ثانٍ","Second yellow card");
            case "sub": case "substitution": return Settings.t(c,"تبديل","Substitution");
            case "penaltymissed": case "missedpenalty": return Settings.t(c,"ركلة جزاء ضائعة","Missed penalty");
            case "var": return Settings.t(c,"مراجعة الفيديو","VAR");
            case "halftime": return Settings.t(c,"بين الشوطين","Half-time");
            case "fulltime": return Settings.t(c,"نهاية المباراة","Full-time");
            default: return Settings.t(c,"حدث في المباراة","Match event");
        }
    }

    static int card(String kind) {
        switch (key(kind)) {
            case "yellow": case "yellowcard": return 1;
            case "red": case "redcard": return 2;
            case "yellowred": case "yellowredcard": case "secondyellow": case "secondyellowcard": return 3;
            default: return 0;
        }
    }

    static String stat(Context c,String key,String label) {
        if (!Settings.ar(c)) return label;
        switch (key(label)) {
            case "ballpossession": case "ballpossesion": case "possession": return "الاستحواذ";
            case "totalshots": case "shots": return "التسديدات";
            case "shotsontarget": case "ontarget": return "التسديدات على المرمى";
            case "shotsofftarget": case "offtarget": return "التسديدات خارج المرمى";
            case "expectedgoals": case "expectedgoalsxg": case "xg": return "الأهداف المتوقعة";
            case "expectedgoalsontarget": case "expectedgoalsontargetxgot": return "الأهداف المتوقعة للتسديدات على المرمى";
            case "goalprobability": case "goalprobabilityxg": return "احتمال تسجيل هدف";
            case "bigchances": return "الفرص المحققة";
            case "bigchancesmissed": return "الفرص المحققة الضائعة";
            case "accuratepasses": return "التمريرات الدقيقة";
            case "passes": case "totalpasses": return "التمريرات";
            case "corners": case "cornerkicks": return "الركنيات";
            case "fouls": case "foulscommitted": return "الأخطاء";
            case "offsides": return "التسلل";
            case "yellowcards": case "yellowcard": return "الإنذارات";
            case "redcards": case "redcard": return "حالات الطرد";
            case "crosses": case "totalcrosses": return "العرضيات";
            case "accuratecrosses": return "العرضيات الدقيقة";
            case "saves": case "goalkeepersaves": case "keepersaves": return "تصديات الحارس";
            case "goalkicks": return "ركلات المرمى";
            case "throwins": return "رميات التماس";
            case "tackles": return "الافتكاكات";
            case "interceptions": return "قطع الكرات";
            case "clearances": return "إبعاد الكرات";
            case "blocks": case "blockedshots": return "التسديدات المحجوبة";
            case "hitwoodwork": return "العارضة والقائم";
            case "shotsinsidebox": return "التسديدات داخل المنطقة";
            case "shotsoutsidebox": return "التسديدات خارج المنطقة";
            case "longballs": case "accuratelongballs": return "الكرات الطويلة";
            case "dribbles": case "successfuldribbles": return "المراوغات الناجحة";
            case "duelswon": return "الالتحامات الناجحة";
            case "aerialduelswon": return "الالتحامات الهوائية الناجحة";
            case "groundduelswon": return "الالتحامات الأرضية الناجحة";
            case "touchesinoppositionbox": return "اللمسات داخل منطقة الخصم";
            case "recoveries": return "استعادة الكرة";
            case "dispossessed": return "فقدان الكرة";
            default: return "possessionPct".equals(key) ? "الاستحواذ" : "";
        }
    }

    static String status(Context c,Match match) {
        String status = match.status == null ? "" : match.status;
        if (!Settings.ar(c)) return status;
        if (status.matches("[0-9+:'′ .-]+")) return status;
        switch (key(status)) {
            case "ht": case "halftime": return "بين الشوطين";
            case "ft": case "fulltime": return "انتهت";
            case "aet": return "بعد الوقت الإضافي";
            case "pen": return "بعد ركلات الترجيح";
            case "cancelled": return "أُلغيت";
            case "postponed": return "تأجلت";
            default: return match.isLive() ? "مباشر" : match.finished() ? "انتهت" : "قادمة";
        }
    }
}
