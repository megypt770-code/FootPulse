package com.tahawy.footpulse;

import android.content.Context;

final class ScoresStyle {
    final boolean dark;
    final int ink, muted, accent;

    ScoresStyle(Context context) {
        dark = Settings.dark(context);
        ink = U.text(context);
        muted = U.sub(context);
        accent = U.iceLine();
    }
}
