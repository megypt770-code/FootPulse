package com.tahawy.footpulse;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** Layout of an announced formation. Coordinates are illustrative tactical slots. */
final class PitchLineup {
    final String formation, rating;
    final int kit;
    final List<List<Player>> lines = new ArrayList<>();

    static final class Player {
        final String name, number, photo, rating, subOut;
        final boolean captain, star;
        final Set<String> events = new HashSet<>();
        final int depth, side, place;
        Player(String name, JSONObject entry, int depth, int side, int place) {
            this.name = name;
            number = entry.optString("jersey");
            photo = FotMob.playerPhoto(entry.optString("playerId"));
            rating = entry.optString("rating");
            subOut = entry.optString("subOut");
            captain = entry.optBoolean("captain");
            star = entry.optBoolean("playerOfTheMatch");
            JSONArray moments = entry.optJSONArray("events");
            if (moments != null) for (int i=0;i<moments.length();i++) {
                JSONObject event = moments.optJSONObject(i);
                if (event != null) events.add(event.optString("type"));
            }
            this.depth = depth;
            this.side = side;
            this.place = place;
        }
    }

    private PitchLineup(String formation, String rating, int kit) {
        this.formation = formation;
        this.rating = rating;
        this.kit = kit;
    }

    static PitchLineup read(JSONObject data, String side, int defaultColor) {
        JSONArray rosters = data.optJSONArray("rosters");
        if (rosters == null) return null;
        for (int i = 0; i < rosters.length(); i++) {
            JSONObject roster = rosters.optJSONObject(i);
            if (roster != null && side.equals(roster.optString("homeAway"))) return parse(roster, defaultColor);
        }
        return null;
    }

    private static PitchLineup parse(JSONObject roster, int defaultColor) {
        String formation = roster.optString("formation", "");
        if (!formation.matches("[1-5](?:-[1-5]){1,4}")) return null;
        String[] sizes = ("1-" + formation).split("-");
        int total = 0;
        for (String size : sizes) total += Integer.parseInt(size);
        JSONArray entries = roster.optJSONArray("roster");
        if (entries == null || total != 11) return null;

        List<Player> players = new ArrayList<>();
        Set<Integer> positions = new HashSet<>();
        for (int i = 0; i < entries.length(); i++) {
            JSONObject entry = entries.optJSONObject(i);
            if (entry == null || !entry.optBoolean("starter")) continue;
            JSONObject athlete = entry.optJSONObject("athlete");
            JSONObject position = entry.optJSONObject("position");
            if (athlete == null) return null;
            int place = entry.optInt("formationPlace", 0);
            String name = athlete.optString("shortName", athlete.optString("displayName", ""));
            String role = position == null ? "" : position.optString("abbreviation", "");
            int depth = depth(role);
            int side = lateral(role);
            JSONObject layout = entry.optJSONObject("fotmobLayout");
            if (layout != null) {
                double x = layout.optDouble("x", -1);
                double y = layout.optDouble("y", -1);
                if (!(x >= 0 && x <= 1 && y >= 0 && y <= 1)) return null;
                depth = entry.optBoolean("goalkeeper") ? 0 : 1 + (int)Math.round(y * 10000);
                side = -(int)Math.round(x * 10000);
            }
            if (name.isEmpty() || depth < 0 || place < 1 || place > 11 || !positions.add(place)) return null;
            players.add(new Player(name,entry,depth,side,place));
        }
        if (players.size() != 11 || players.stream().filter(p -> p.depth == 0).count() != 1) return null;

        JSONObject uniform = roster.optJSONObject("uniform");
        String color = uniform == null ? "" : uniform.optString("color");
        int kit = color.matches("[0-9a-fA-F]{6}") ? 0xff000000 | Integer.parseInt(color, 16) : defaultColor;
        PitchLineup lineup = new PitchLineup(formation,roster.optString("rating"),kit);
        players.sort(Comparator.comparingInt((Player p) -> p.depth).thenComparingInt(p -> p.place));
        int from = 0;
        for (String size : sizes) {
            int to = from + Integer.parseInt(size);
            List<Player> row = new ArrayList<>(players.subList(from, to));
            row.sort(Comparator.comparingInt((Player p) -> p.side).thenComparingInt(p -> p.place));
            lineup.lines.add(row);
            from = to;
        }
        return lineup;
    }

    private static int depth(String role) {
        if ("G".equals(role)) return 0;
        if (role.endsWith("B") || role.startsWith("CD") || "D".equals(role)) return 1;
        if (role.startsWith("DM")) return 2;
        if (role.startsWith("CM") || role.endsWith("M") && !role.startsWith("AM")) return 3;
        if (role.startsWith("AM")) return 4;
        if (role.startsWith("CF") || "LF".equals(role) || "RF".equals(role)) return 5;
        if ("F".equals(role) || "ST".equals(role)) return 6;
        return -1;
    }

    private static int lateral(String role) {
        if (role.startsWith("L") || role.endsWith("-L")) return -1;
        if (role.startsWith("R") || role.endsWith("-R")) return 1;
        return 0;
    }
}
