package com.tahawy.footpulse;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Club identity, featured fixture and chronological team schedule. */
public final class TeamActivity extends Activity {
    private static final int ICE_WHITE = 0xFFD5EDFF;
    private String id, name, logo, league;
    private List<Match> schedule = new ArrayList<>();
    private boolean loading = true;
    private LinearLayout content;
    private int selected;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        id = extra("teamId");
        name = extra("teamName");
        logo = extra("logo");
        league = extra("league");
        if (state != null) selected = state.getInt("selected");
        draw();
        new Thread(() -> {
            List<Match> data = ScoreRepository.teamSchedule(getApplicationContext(),league,id);
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                schedule = data;
                loading = false;
                draw();
            });
        },"team-schedule").start();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putInt("selected",selected);
    }

    private String extra(String key) {
        String value = getIntent().getStringExtra(key);
        return value == null ? "" : value;
    }

    private void draw() {
        U.systemBar(this);
        LinearLayout root = U.col(this);
        root.setLayoutDirection(Settings.ar(this) ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        root.setBackground(U.backdrop(this));
        setContentView(root);
        U.headingBar(this,root,t("صفحة الفريق","Team profile"),this::finish);
        ScrollView scroll = U.scroll(this);
        content = U.col(this);
        U.pad(content,12,5,12,24);
        scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        content.addView(identity());
        U.space(content,13);

        LinearLayout tabs = U.row(this);
        String[] labels = {t("المباريات","Fixtures"),t("عن الفريق","About")};
        for (int i = 0; i < labels.length; i++) {
            int target = i;
            TextView tab = U.chip(this,labels[i],selected == i);
            tab.setTextSize(15);
            tab.setSelected(selected == i);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,U.dp(this,44),1);
            params.setMarginEnd(i == 0 ? U.dp(this,6) : 0);
            tabs.addView(tab,params);
            tab.setOnClickListener(v -> { selected = target; draw(); });
        }
        content.addView(tabs);
        U.space(content,15);

        if (selected == 1) {
            LinearLayout card = U.card(this);
            U.pad(card,18);
            card.addView(U.heading(this,t("الفريق","Club")));
            card.addView(U.txt(this,League.byId(league).name(this),15,false,U.text(this)));
            U.space(card,10);
            card.addView(U.txt(this,t("يمكن متابعة الفريق محليًا للحصول على مبارياته في تبويب المتابعة، بدون حساب.",
                "Follow this club locally to keep fixtures in the Following tab. No account needed."),13,false,U.sub(this)));
            content.addView(card);
            return;
        }
        if (loading) {
            ProgressBar progress = new ProgressBar(this);
            LinearLayout.LayoutParams params = U.lp(this,34,34);
            params.gravity = Gravity.CENTER_HORIZONTAL;
            content.addView(progress,params);
            return;
        }
        if (schedule.isEmpty()) {
            empty(t("جدول مباريات الفريق غير متوفر حاليًا من مصدر البيانات.",
                "Team fixtures aren't available from the data provider right now."));
            return;
        }

        List<Match> upcoming = new ArrayList<>(), live = new ArrayList<>(), past = new ArrayList<>();
        for (Match match : schedule) {
            if (match.isLive()) live.add(match);
            else if (Upcoming.open(match)) upcoming.add(match);
            else past.add(match);
        }
        upcoming.sort(Comparator.comparing(Upcoming::start));
        past.sort(Comparator.comparing(Upcoming::start).reversed());
        for (Match match : live) fixture(match,true);
        if (upcoming.isEmpty() && live.isEmpty()) {
            empty(t("لا توجد مباراة قادمة معلنة حاليًا.","No upcoming match announced yet."));
            U.space(content,8);
        }
        if (!upcoming.isEmpty()) {
            fixture(upcoming.get(0),true);
            if (upcoming.size() > 1) {
                content.addView(U.heading(this,t("المباريات القادمة","Upcoming fixtures")));
                for (int i = 1; i < upcoming.size(); i++) fixture(upcoming.get(i),false);
            }
        }
        if (!past.isEmpty()) {
            content.addView(U.heading(this,t("نتائج سابقة","Recent results")));
            for (Match match : past) fixture(match,false);
        }
    }

    private LinearLayout identity() {
        LinearLayout cover = U.row(this);
        cover.setBackground(U.glass(this,22));
        U.pad(cover,14,18,14,18);
        cover.addView(U.logo(this,logo,61));
        LinearLayout details = U.col(this);
        U.pad(details,10,0,10,0);
        TextView heading = U.txt(this,Club.name(this,name),24,true,U.text(this));
        heading.setMaxLines(2);
        heading.setEllipsize(TextUtils.TruncateAt.END);
        details.addView(heading);
        U.space(details,5);
        details.addView(U.txt(this,League.byId(league).name(this),13,false,U.sub(this)));
        cover.addView(details,U.weight(this,1));

        boolean following = Settings.isFavorite(this,id,league);
        TextView follow = U.chip(this,following ? t("✓ متابَع","✓ Following") : t("+ متابعة","+ Follow"),following);
        follow.setBackground(following ? U.selected(this) : U.outlined(this,U.accentSurface(this),U.accent(this),22));
        U.pad(follow,10,0,10,0);
        cover.addView(follow,U.lp(this,-2,44));
        follow.setOnClickListener(v -> { Settings.follow(this,id,name,league,logo); draw(); });
        return cover;
    }

    private void fixture(Match match,boolean featured) {
        LinearLayout card = U.card(this);
        if (featured) card.setBackground(new IceArtwork(true));
        U.pad(card,10,featured ? 15 : 10,10,featured ? 17 : 10);
        card.setGravity(Gravity.CENTER_HORIZONTAL);

        int primary = featured ? Color.WHITE : U.text(this);
        int secondary = featured ? ICE_WHITE : U.sub(this);
        if (featured) {
            TextView badge = centered(match.isLive() ? t("مباشر الآن","Live now") : t("المباراة القادمة","Next match"),
                14,true,U.selectedInk());
            badge.setBackground(U.selected(this));
            U.pad(badge,12,5,12,5);
            card.addView(badge,U.lp(this,-2,-2));
            U.space(card,9);
        }

        LocalDate day = Upcoming.day(match,ScoreRepository.CAIRO);
        if (day != null) {
            Locale locale = Settings.ar(this) ? new Locale("ar","EG") : Locale.ENGLISH;
            card.addView(centered(day.format(DateTimeFormatter.ofPattern("d MMMM",locale)),featured ? 16 : 13,true,secondary));
            U.space(card,featured ? 10 : 6);
        }

        LinearLayout pairing = U.row(this);
        pairing.addView(team(match.home,match.homeLogo,featured,true,primary),U.weight(this,1));
        LinearLayout clock = U.col(this);
        clock.setGravity(Gravity.CENTER);
        boolean hasScore = match.homeScore != null && !match.homeScore.isEmpty()
            && match.awayScore != null && !match.awayScore.isEmpty();
        String result = hasScore
            ? (Settings.ar(this) ? match.awayScore + " - " + match.homeScore : match.homeScore + " - " + match.awayScore)
            : (match.finished() || match.isLive() ? "—" : ScoreRepository.localTime(match.isoDate));
        TextView value = centered(result,featured ? 31 : 17,true,featured ? primary : U.accent(this));
        value.setTextDirection(View.TEXT_DIRECTION_LTR);
        value.setAutoSizeTextTypeUniformWithConfiguration(12,featured ? 31 : 17,1,android.util.TypedValue.COMPLEX_UNIT_SP);
        clock.addView(value,U.lp(this,-1,featured ? 40 : 27));
        if (featured) {
            String caption = match.isLive() ? MatchText.status(this,match) : t("توقيت القاهرة","Cairo time");
            clock.addView(centered(caption,11,false,secondary),U.lp(this,-1,-2));
        }
        pairing.addView(clock,U.lp(this,featured ? 107 : 64,-2));
        pairing.addView(team(match.away,match.awayLogo,featured,false,primary),U.weight(this,1));
        card.addView(pairing,U.lp(this,-1,-2));

        if (Upcoming.open(match)) {
            TextView channels = centered("",11,true,secondary);
            channels.setMaxLines(2);
            channels.setVisibility(View.GONE);
            U.pad(channels,0,8,0,0);
            card.addView(channels);
            TvInfo.load(this,match,text -> {
                channels.setText(text);
                channels.setVisibility(View.VISIBLE);
            });
        }
        card.setOnClickListener(v -> U.openMatch(this,match));
        content.addView(card);
        U.space(content,9);
    }

    private LinearLayout team(String label,String crest,boolean featured,boolean home,int ink) {
        LinearLayout group = featured ? U.col(this) : U.row(this);
        group.setGravity(Gravity.CENTER);
        if (featured || !home) group.addView(U.logo(this,crest,featured ? 61 : 28));
        TextView title = centered(Club.name(this,label),featured ? 15 : 12,true,ink);
        title.setMaxLines(2);
        if (featured) {
            U.space(group,6);
            group.addView(title,U.lp(this,-1,-2));
        } else {
            U.pad(title,4,0,4,0);
            group.addView(title,U.weight(this,1));
            if (home) group.addView(U.logo(this,crest,28));
        }
        return group;
    }

    private TextView centered(String label,int size,boolean bold,int ink) {
        TextView view = U.txt(this,label,size,bold,ink);
        view.setGravity(Gravity.CENTER);
        view.setMaxLines(1);
        view.setEllipsize(TextUtils.TruncateAt.END);
        return view;
    }

    private void empty(String message) {
        LinearLayout card = U.card(this);
        U.pad(card,18,22,18,22);
        TextView label = centered(message,14,false,U.sub(this));
        label.setMaxLines(3);
        card.addView(label);
        content.addView(card);
    }

    private String t(String ar,String en) { return Settings.t(this,ar,en); }
}
