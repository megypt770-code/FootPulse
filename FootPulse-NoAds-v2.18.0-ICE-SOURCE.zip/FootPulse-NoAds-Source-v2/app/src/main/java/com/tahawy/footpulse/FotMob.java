package com.tahawy.footpulse;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Normalizes FotMob public match and competition pages. */
final class FotMob {
    static final String HOST = "https://www.fotmob.com";
    static final String PREMIER = "egy.1";
    static final String CUP = "egy.cup";
    private static final Pattern PAGE_DATA = Pattern.compile(
        "<script\\b[^>]*\\bid=\"__NEXT_DATA__\"[^>]*>(.*?)</script>", Pattern.DOTALL);
    private static final Pattern SCORE = Pattern.compile("(\\d+)\\s*[-–:]\\s*(\\d+)");
    private static final Pattern MATCH_PATH = Pattern.compile("/matches/[a-z0-9-]+/[a-z0-9]+(?:#([0-9]+))?");

    private static final Map<String,Competition> COMPETITIONS;
    static {
        Map<String,Competition> leagues = new LinkedHashMap<>();
        leagues.put("eng.1",new Competition(47,"premier-league"));
        leagues.put("esp.1",new Competition(87,"laliga"));
        leagues.put("uefa.champions.qual",new Competition(10611,"champions-league-qualification"));
        leagues.put("uefa.champions",new Competition(42,"champions-league"));
        leagues.put("ita.1",new Competition(55,"serie-a"));
        leagues.put("ger.1",new Competition(54,"bundesliga"));
        leagues.put("fra.1",new Competition(53,"ligue-1"));
        leagues.put("uefa.europa",new Competition(73,"europa-league"));
        leagues.put("ned.1",new Competition(57,"eredivisie"));
        leagues.put("por.1",new Competition(61,"liga-portugal"));
        leagues.put("usa.1",new Competition(130,"mls"));
        leagues.put("fifa.world",new Competition(77,"world-cup"));
        leagues.put("eng.2",new Competition(48,"championship"));
        leagues.put("egy.1",new Competition(519,"premier-league"));
        leagues.put("ksa.1",new Competition(536,"saudi-pro-league"));
        leagues.put("uefa.conference",new Competition(10216,"conference-league"));
        leagues.put("eng.fa",new Competition(132,"fa-cup"));
        leagues.put("eng.league_cup",new Competition(133,"efl-cup"));
        leagues.put("sco.1",new Competition(64,"premiership"));
        leagues.put("tur.1",new Competition(71,"super-lig"));
        leagues.put("bel.1",new Competition(40,"first-division-a"));
        leagues.put("arg.1",new Competition(112,"liga-profesional"));
        leagues.put("bra.1",new Competition(268,"serie-a"));
        leagues.put("mex.1",new Competition(230,"liga-mx"));
        leagues.put("jpn.1",new Competition(223,"j-league"));
        leagues.put("aus.1",new Competition(113,"a-league-men"));
        leagues.put("uefa.nations",new Competition(9806,"uefa-nations-league"));
        leagues.put(League.EURO,new Competition(50,"euro"));
        leagues.put("fifa.worldq.uefa",new Competition(10195,"world-cup-qualification-uefa"));
        leagues.put("fifa.worldq.conmebol",new Competition(10199,"world-cup-qualification-conmebol"));
        leagues.put("egy.cup",new Competition(9941,"egypt-cup"));
        COMPETITIONS = Collections.unmodifiableMap(leagues);
    }

    private static final class Competition {
        final int id;
        final String slug;
        Competition(int id, String slug) { this.id = id; this.slug = slug; }
    }

    static boolean supports(String league) { return COMPETITIONS.containsKey(league); }
    static boolean isEgyptian(String league) { return PREMIER.equals(league) || CUP.equals(league); }

    static int leagueId(String league) {
        Competition entry = COMPETITIONS.get(league);
        return entry == null ? 0 : entry.id;
    }

    static String leagueCode(int id, String fallback) {
        for (Map.Entry<String,Competition> entry : COMPETITIONS.entrySet()) {
            if (entry.getValue().id == id) return entry.getKey();
        }
        return fallback;
    }

    static String fixturesUrl(String league) {
        Competition entry = COMPETITIONS.get(league);
        return entry == null ? "" : HOST + "/leagues/" + entry.id + "/matches/" + entry.slug;
    }

    static String leagueLogo(String league) {
        int id = leagueId(league);
        return id == 0 ? "" : "https://images.fotmob.com/image_resources/logo/leaguelogo/" + id + ".png";
    }

    static String statsUrl(String league) {
        return fixturesUrl(league).replace("/matches/","/stats/");
    }

    static String playerPhoto(String id) {
        return id != null && id.matches("[1-9][0-9]*")
            ? "https://images.fotmob.com/image_resources/playerimages/" + id + ".png" : "";
    }

    static String matchUrl(String id) {
        return id != null && id.matches("[0-9]{1,14}") ? HOST + "/match/" + id : "";
    }

    static String redirectUrl(String body, String id) {
        Matcher match = MATCH_PATH.matcher(body.trim());
        if (!match.matches() || !id.equals(match.group(1))) return "";
        return HOST + body.trim().split("#",2)[0];
    }

    static JSONObject leaguePage(String body, String league) throws JSONException, IOException {
        JSONObject data = pageData(body);
        JSONObject details = data.optJSONObject("details");
        JSONObject fixtures = data.optJSONObject("fixtures");
        if (details == null || details.optInt("id") != leagueId(league) ||
                fixtures == null || fixtures.optJSONArray("allMatches") == null)
            throw new IOException("Unexpected FotMob competition page");
        return data;
    }

    static List<Match> matches(JSONObject page, String league, LocalDate day, ZoneId zone) {
        List<Match> result = new ArrayList<>();
        JSONObject fixtures = page.optJSONObject("fixtures");
        JSONArray games = fixtures == null ? null : fixtures.optJSONArray("allMatches");
        if (games == null) return result;
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < games.length(); i++) {
            JSONObject fixture = games.optJSONObject(i);
            if (fixture == null) continue;
            Match match = match(fixture,league);
            if (match == null || !seen.add(match.id)) continue;
            if (day != null && !ScoreRepository.kickoff(match.isoDate).atZone(zone).toLocalDate().equals(day)) continue;
            result.add(match);
        }
        result.sort(java.util.Comparator.comparing(match -> match.isoDate));
        return result;
    }

    private static Match match(JSONObject fixture, String league) {
        JSONObject home = fixture.optJSONObject("home");
        JSONObject away = fixture.optJSONObject("away");
        JSONObject status = fixture.optJSONObject("status");
        if (home == null || away == null || status == null) return null;
        Match result = new Match();
        result.id = fixture.optString("id");
        if (result.id.isEmpty()) {
            String path = fixture.optString("matchUrl",fixture.optString("pageUrl"));
            Matcher link = MATCH_PATH.matcher(path);
            if (link.matches() && link.group(1) != null) result.id = link.group(1);
        }
        result.leagueId = league;
        result.leagueLogo = leagueLogo(league);
        result.home = home.optString("name");
        result.away = away.optString("name");
        result.homeId = home.optString("id");
        result.awayId = away.optString("id");
        if (result.id.isEmpty() || result.home.isEmpty() || result.away.isEmpty()) return null;
        try {
            result.isoDate = ScoreRepository.kickoff(status.optString("utcTime")).toString();
        } catch (DateTimeParseException ignored) {
            return null;
        }
        result.homeLogo = teamLogo(result.homeId);
        result.awayLogo = teamLogo(result.awayId);
        result.state = state(status);
        result.status = label(status);
        result.homeScore = "";
        result.awayScore = "";
        Matcher score = SCORE.matcher(status.optString("scoreStr"));
        if (!"pre".equals(result.state) && score.find()) {
            result.homeScore = score.group(1);
            result.awayScore = score.group(2);
        }
        return result;
    }

    static List<Standing> standings(JSONObject page) {
        List<Standing> result = new ArrayList<>();
        JSONArray tables = page.optJSONArray("table");
        if (tables == null) return result;
        for (int t = 0; t < tables.length(); t++) {
            JSONObject wrapped = tables.optJSONObject(t);
            JSONObject group = wrapped == null ? null : wrapped.optJSONObject("data");
            JSONObject table = group == null ? null : group.optJSONObject("table");
            JSONArray rows = table == null ? null : table.optJSONArray("all");
            if (rows == null) continue;
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null || row.optString("id").isEmpty()) continue;
                Standing entry = new Standing();
                entry.id = row.optString("id");
                entry.name = row.optString("name");
                entry.logo = teamLogo(entry.id);
                entry.played = row.optString("played","-");
                entry.won = row.optString("wins","-");
                entry.drawn = row.optString("draws","-");
                entry.lost = row.optString("losses","-");
                entry.points = row.optString("pts","-");
                entry.difference = row.optString("goalConDiff","-");
                result.add(entry);
            }
        }
        return result;
    }

    static JSONObject summary(String body, String league, String id) throws IOException, JSONException {
        JSONObject data = pageData(body);
        JSONObject general = data.optJSONObject("general");
        JSONObject header = data.optJSONObject("header");
        JSONObject status = header == null ? null : header.optJSONObject("status");
        JSONArray teams = header == null ? null : header.optJSONArray("teams");
        if (general == null || !id.equals(general.optString("matchId"))
                || status == null || teams == null || teams.length() != 2) throw new IOException("Unexpected match page");
        int competition = leagueId(league);
        int parent = general.optInt("parentLeagueId",general.optInt("leagueId"));
        int actual = general.optInt("leagueId");
        if (competition != 0 && competition != parent && competition != actual)
            throw new IOException("Unexpected FotMob competition");

        JSONArray competitors = new JSONArray();
        String phase = state(status);
        for (int i = 0; i < 2; i++) {
            JSONObject team = teams.getJSONObject(i);
            JSONObject row = new JSONObject().put("homeAway",i == 0 ? "home" : "away");
            if (!"pre".equals(phase) && !team.isNull("score")) row.put("score",team.optString("score"));
            competitors.put(row);
        }
        JSONObject type = new JSONObject().put("state",phase).put("shortDetail",label(status));
        JSONObject contest = new JSONObject().put("status",new JSONObject().put("type",type))
            .put("competitors",competitors);
        JSONObject result = new JSONObject().put("header",
            new JSONObject().put("competitions",new JSONArray().put(contest)));
        JSONObject content = data.optJSONObject("content");
        JSONObject facts = content == null ? null : content.optJSONObject("matchFacts");
        JSONObject info = facts == null ? null : facts.optJSONObject("infoBox");
        JSONObject stadium = info == null ? null : info.optJSONObject("Stadium");
        if (stadium != null) result.put("stadium",stadium);
        JSONObject eventFeed = facts == null ? null : facts.optJSONObject("events");
        JSONArray rawEvents = eventFeed == null ? null : eventFeed.optJSONArray("events");
        if (rawEvents != null) result.put("keyEvents",events(rawEvents));
        if (content != null) {
            JSONObject lineup = content.optJSONObject("lineup");
            if (lineup != null) result.put("rosters",lineups(lineup,general.optJSONObject("teamColors")));
            JSONObject statistics = content.optJSONObject("stats");
            if (statistics != null) addStats(result,statistics);
            JSONObject headToHead = content.optJSONObject("h2h");
            if (headToHead != null) {
                JSONArray matches = headToHead.optJSONArray("matches");
                if (matches != null) result.put("fotmobHistory",matches);
            }
        }
        return result;
    }

    static List<Match> history(JSONObject summary, Match selected) {
        List<Match> result = new ArrayList<>();
        JSONArray entries = summary.optJSONArray("fotmobHistory");
        if (entries == null) return result;
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < entries.length(); i++) {
            JSONObject entry = entries.optJSONObject(i);
            if (entry == null) continue;
            JSONObject competition = entry.optJSONObject("league");
            String id = competition == null ? selected.leagueId : leagueCode(competition.optInt("id"),"");
            if (id == null || id.isEmpty()) id = "fotmob." + (competition == null ? 0 : competition.optInt("id"));
            Match previous = match(entry,id);
            if (previous == null || !previous.finished() || Objects.equals(selected.id,previous.id) || !seen.add(previous.id)) continue;
            boolean homeFirst = Objects.equals(selected.homeId,previous.homeId) && Objects.equals(selected.awayId,previous.awayId);
            boolean awayFirst = Objects.equals(selected.homeId,previous.awayId) && Objects.equals(selected.awayId,previous.homeId);
            if (!homeFirst && !awayFirst) continue;
            if (selected.isoDate != null && !selected.isoDate.isEmpty()) {
                try {
                    if (!ScoreRepository.kickoff(previous.isoDate).isBefore(ScoreRepository.kickoff(selected.isoDate))) continue;
                } catch (DateTimeParseException ignored) {}
            }
            if (competition != null) previous.competitionName = competition.optString("name");
            result.add(previous);
        }
        result.sort(java.util.Comparator.comparing((Match m) -> m.isoDate).reversed());
        return result;
    }

    static int[] historyCounts(List<Match> matches,Match selected) {
        int[] counts = new int[3];
        for (Match match : matches) {
            if (!match.finished()) continue;
            try {
                int home = Integer.parseInt(match.homeScore), away = Integer.parseInt(match.awayScore);
                if (home == away) counts[1]++;
                else {
                    String winner = home > away ? match.homeId : match.awayId;
                    if (Objects.equals(winner,selected.homeId)) counts[0]++;
                    else if (Objects.equals(winner,selected.awayId)) counts[2]++;
                }
            } catch (NumberFormatException ignored) {}
        }
        return counts;
    }

    static String historicalSeason(JSONObject page, LocalDate day, ZoneId zone) {
        JSONObject details = page.optJSONObject("details");
        String selected = details == null ? "" : details.optString("selectedSeason");
        JSONArray seasons = page.optJSONArray("allAvailableSeasons");
        if (seasons == null || selected.isEmpty() || day == null) return "";
        List<Match> fixtures = matches(page,"",null,zone);
        if (fixtures.isEmpty()) return "";
        LocalDate first = ScoreRepository.kickoff(fixtures.get(0).isoDate).atZone(zone).toLocalDate();
        if (!day.isBefore(first)) return "";
        // Most split-year schedules use a July season boundary. Calendar-year and
        // tournament seasons use the year named by FotMob.
        int year = day.getYear();
        String exact = String.valueOf(year);
        int startYear = day.getMonthValue() < 7 ? year - 1 : year;
        String split = startYear + "/" + (startYear + 1);
        for (int i = 0; i < seasons.length(); i++) {
            String season = seasons.optString(i);
            if ((season.equals(split) || season.equals(exact)) && !season.equals(selected)) return season;
        }
        return "";
    }

    private static JSONArray lineups(JSONObject lineups, JSONObject colors) throws JSONException {
        JSONArray result = new JSONArray();
        JSONObject light = colors == null ? null : colors.optJSONObject("lightMode");
        for (String side : new String[]{"home","away"}) {
            JSONObject team = lineups.optJSONObject(side + "Team");
            if (team == null) continue;
            JSONObject group = new JSONObject().put("homeAway",side)
                .put("formation",team.optString("formation"))
                .put("team",new JSONObject().put("displayName",team.optString("name")));
            if (!team.isNull("rating")) group.put("rating",team.optString("rating"));
            if (light != null) group.put("uniform",
                new JSONObject().put("color",light.optString(side).replace("#","")));
            JSONArray players = new JSONArray();
            addPlayers(players,team.optJSONArray("starters"),true);
            addPlayers(players,team.optJSONArray("subs"),false);
            group.put("roster",players);
            result.put(group);
        }
        return result;
    }

    private static void addPlayers(JSONArray target, JSONArray source, boolean starter) throws JSONException {
        if (source == null) return;
        for (int i = 0; i < source.length(); i++) {
            JSONObject player = source.optJSONObject(i);
            if (player == null || player.optString("name").isEmpty()) continue;
            JSONObject row = new JSONObject().put("starter",starter).put("jersey",player.optString("shirtNumber"))
                .put("formationPlace",i + 1)
                .put("athlete",new JSONObject().put("displayName",player.optString("name"))
                    .put("shortName",player.optString("lastName",player.optString("name"))));
            JSONObject performance = player.optJSONObject("performance");
            row.put("playerId",player.optString("id"));
            row.put("captain",player.optBoolean("isCaptain"));
            if (performance != null) {
                if (!performance.isNull("rating")) row.put("rating",performance.optString("rating"));
                row.put("playerOfTheMatch",performance.optBoolean("playerOfTheMatch"));
                JSONArray moments = performance.optJSONArray("events");
                if (moments != null) row.put("events",moments);
                JSONArray substitutions = performance.optJSONArray("substitutionEvents");
                if (substitutions != null) for (int j=0;j<substitutions.length();j++) {
                    JSONObject change = substitutions.optJSONObject(j);
                    if (change != null && "subOut".equals(change.optString("type")) && change.optInt("time")>0) {
                        row.put("subOut",change.optString("time"));
                        break;
                    }
                }
            }
            JSONObject layout = player.optJSONObject("verticalLayout");
            if (layout != null) {
                row.put("fotmobLayout",layout);
                row.put("goalkeeper",player.optInt("positionId") == 11);
            }
            target.put(row);
        }
    }

    private static void addStats(JSONObject result, JSONObject statistics) throws JSONException {
        JSONObject periods = statistics.optJSONObject("Periods");
        JSONObject all = periods == null ? null : periods.optJSONObject("All");
        JSONArray groups = all == null ? null : all.optJSONArray("stats");
        if (groups == null) return;
        JSONArray home = new JSONArray();
        JSONArray away = new JSONArray();
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < groups.length(); i++) {
            JSONObject group = groups.optJSONObject(i);
            JSONArray entries = group == null ? null : group.optJSONArray("stats");
            if (entries == null) continue;
            for (int j = 0; j < entries.length(); j++) {
                JSONObject entry = entries.optJSONObject(j);
                if (entry == null) continue;
                JSONArray values = entry.optJSONArray("stats");
                String key = entry.optString("key");
                if (values == null || values.length() != 2 || values.isNull(0) || values.isNull(1)
                        || key.isEmpty() || !seen.add(key)) continue;
                boolean possession = "BallPossesion".equalsIgnoreCase(key) || "BallPossession".equalsIgnoreCase(key);
                String name = possession ? "possessionPct" : key;
                String label = entry.optString("title",name);
                home.put(new JSONObject().put("name",name).put("label",label)
                    .put("displayValue",values.optString(0) + (possession ? "%" : "")));
                away.put(new JSONObject().put("name",name)
                    .put("displayValue",values.optString(1) + (possession ? "%" : "")));
            }
        }
        if (home.length() > 0) result.put("boxscore",new JSONObject().put("teams",new JSONArray()
            .put(new JSONObject().put("statistics",home)).put(new JSONObject().put("statistics",away))));
    }

    private static JSONArray events(JSONArray source) throws JSONException {
        JSONArray output = new JSONArray();
        for (int i = 0; i < source.length(); i++) {
            JSONObject event = source.optJSONObject(i);
            if (event == null) continue;
            String player = event.optString("nameStr",event.optString("fullName",""));
            JSONObject athlete = event.optJSONObject("player");
            if (player.isEmpty() && athlete != null) player = athlete.optString("name");
            String type = event.optString("type");
            if (type.isEmpty()) continue;
            String card = event.optString("card");
            String kind = "Card".equalsIgnoreCase(type) && !card.isEmpty() ? card : type;
            if ("Goal".equalsIgnoreCase(type) && event.optBoolean("ownGoal")) kind = "OwnGoal";
            String text = player.isEmpty() ? type : player + " · " + type;
            String minute = event.optString("timeStr","");
            String extra = event.optString("overloadTime","");
            if (!extra.isEmpty() && !event.isNull("overloadTime") && !minute.contains("+")) minute += "+" + extra;
            if (!minute.isEmpty() && !minute.endsWith("'")) minute += "′";
            JSONArray swap = event.optJSONArray("swap");
            String incoming = swapName(swap,0);
            String outgoing = swapName(swap,1);
            output.put(new JSONObject().put("shortText",text).put("kind",kind)
                .put("player",player).put("incoming",incoming).put("outgoing",outgoing)
                .put("eventId",event.optString("eventId",event.optString("id")))
                .put("isHome",event.optBoolean("isHome"))
                .put("clock",new JSONObject().put("displayValue",minute)));
        }
        return output;
    }

    private static String swapName(JSONArray swap, int index) {
        JSONObject player = swap == null ? null : swap.optJSONObject(index);
        if (player == null) return "";
        return player.optString("name",player.optString("nameStr"));
    }

    static JSONObject pageData(String html) throws IOException, JSONException {
        Matcher match = PAGE_DATA.matcher(html);
        if (!match.find()) throw new IOException("FotMob page data not present");
        return new JSONObject(match.group(1)).getJSONObject("props").getJSONObject("pageProps");
    }

    static List<Club> clubs(String body) throws JSONException {
        JSONArray teams = new JSONObject(body).getJSONArray("teams");
        List<Club> result = new ArrayList<>();
        for (int i = 0; i < teams.length(); i++) {
            JSONObject team = teams.optJSONObject(i);
            if (team == null) continue;
            String id = team.optString("id");
            String name = team.optString("name");
            if (!id.matches("[0-9]+") || name.isEmpty()) continue;
            result.add(new Club(id,name,leagueCode(team.optInt("leagueId"),"")));
        }
        return result;
    }

    static String teamLogo(String id) {
        return id.matches("[0-9]+") ? "https://images.fotmob.com/image_resources/logo/teamlogo/" + id + "_small.png" : "";
    }

    private static String state(JSONObject status) {
        if (status.optBoolean("finished") || status.optBoolean("cancelled") || status.optBoolean("awarded")) return "post";
        return status.optBoolean("started") ? "in" : "pre";
    }

    private static String label(JSONObject status) {
        JSONObject live = status.optJSONObject("liveTime");
        if (live != null && !live.optString("short").isEmpty()) return live.optString("short");
        JSONObject reason = status.optJSONObject("reason");
        if (reason != null && !reason.optString("short").isEmpty()) return reason.optString("short");
        if (status.optBoolean("cancelled")) return "Cancelled";
        return status.optBoolean("finished") ? "FT" : "";
    }
}
