package com.tahawy.footpulse;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DecimalStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Consumer;

final class MatchCalendar {
    private static final int LIMIT = 3;
    private static final String PREF = "calendar_leagues";
    private final Activity activity;
    private final Consumer<LocalDate> openDay;
    private final Runnable onLeagueChanged;
    private final Dialog dialog;
    private final ExecutorService workers = Executors.newFixedThreadPool(2);
    private final Set<String> leagues;
    private final Map<LocalDate,List<Match>> dayCache = new HashMap<>();
    private final Map<YearMonth,Map<String,Set<LocalDate>>> monthCache = new HashMap<>();
    private final Locale locale;
    private final DecimalStyle digits;
    private LocalDate selected;
    private YearMonth month;
    private LinearLayout grid, fixtures;
    private TextView filter, monthLabel;
    private int dayRequest, monthRequest;
    private Future<?> dayJob, monthJob;

    MatchCalendar(Activity activity,LocalDate initial,List<Match> available,Consumer<LocalDate> openDay,Runnable onLeagueChanged) {
        this.activity = activity;
        this.openDay = openDay;
        this.onLeagueChanged = onLeagueChanged;
        selected = initial;
        month = YearMonth.from(initial);
        leagues = new LinkedHashSet<>(Settings.prefs(activity).getStringSet(PREF,Collections.emptySet()));
        if (available != null && !available.isEmpty() && Settings.enabledLeagues(activity).containsAll(leagues))
            dayCache.put(initial,new ArrayList<>(available));
        dialog = new Dialog(activity,U.dialogTheme(activity));
        locale = Settings.ar(activity) ? new Locale("ar","EG") : Locale.ENGLISH;
        digits = DecimalStyle.of(locale);
    }

    void show() {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout sheet = U.col(activity);
        sheet.setLayoutDirection(Settings.ar(activity) ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        sheet.setBackground(U.glass(activity,24));
        sheet.setClipToOutline(true);

        LinearLayout head = U.col(activity);
        head.setGravity(Gravity.CENTER_HORIZONTAL);
        head.setBackground(U.selected(activity));
        U.pad(head,12,7,12,4);
        View grip = new View(activity);
        grip.setBackground(U.shape(0x80FFFFFF,3,activity));
        head.addView(grip,U.lp(activity,35,4));
        LinearLayout titleBar = U.row(activity);
        titleBar.addView(U.icon(activity,R.drawable.ui_calendar,25,U.selectedInk()));
        TextView title = U.txt(activity,t("تقويم المباريات","Match calendar"),20,true,U.selectedInk());
        title.setGravity(Gravity.CENTER);
        titleBar.addView(title,U.weight(activity,1));
        TextView close = U.txt(activity,"×",27,true,U.selectedInk());
        close.setGravity(Gravity.CENTER);
        close.setContentDescription(t("إغلاق","Close"));
        close.setOnClickListener(v -> dialog.dismiss());
        titleBar.addView(close,U.lp(activity,44,44));
        head.addView(titleBar,U.lp(activity,-1,-2));
        sheet.addView(head,U.lp(activity,-1,-2));

        ScrollView scroll = U.scroll(activity);
        LinearLayout content = U.col(activity);
        U.pad(content,12,8,12,14);
        scroll.addView(content);
        sheet.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        filter = U.chip(activity,"",false);
        filter.setOnClickListener(v -> pickLeagues());
        content.addView(filter,U.lp(activity,-1,42));
        U.space(content,7);

        LinearLayout controls = U.row(activity);
        boolean ar = Settings.ar(activity);
        controls.addView(monthArrow(ar ? "›" : "‹",-1),U.lp(activity,44,42));
        monthLabel = U.txt(activity,"",17,true,U.text(activity));
        monthLabel.setGravity(Gravity.CENTER);
        controls.addView(monthLabel,U.weight(activity,1));
        controls.addView(monthArrow(ar ? "‹" : "›",1),U.lp(activity,44,42));
        content.addView(controls,U.lp(activity,-1,-2));
        grid = U.col(activity);
        content.addView(grid,U.lp(activity,-1,-2));
        U.space(content,10);
        fixtures = U.col(activity);
        content.addView(fixtures,U.lp(activity,-1,-2));
        dialog.setContentView(sheet);
        dialog.setOnDismissListener(d -> workers.shutdownNow());
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            View root = activity.findViewById(android.R.id.content);
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,Math.max(U.dp(activity,220),(int)(root.getHeight()*.92)));
        }
        renderGrid();
        showFixtures();
        loadMonth();
    }

    private TextView monthArrow(String symbol,int direction) {
        TextView button = U.chip(activity,symbol,false);
        U.pad(button,0);
        button.setTextSize(25);
        button.setContentDescription(direction < 0 ? t("الشهر السابق","Previous month") : t("الشهر التالي","Next month"));
        button.setOnClickListener(v -> {
            month = month.plusMonths(direction);
            selected = month.atDay(Math.min(selected.getDayOfMonth(),month.lengthOfMonth()));
            renderGrid();
            showFixtures();
            loadMonth();
        });
        return button;
    }

    private void pickLeagues() {
        List<League> options = League.ALL;
        Set<String> draft = new LinkedHashSet<>(leagues);
        String[] labels = new String[options.size()];
        boolean[] checked = new boolean[options.size()];
        for (int i=0;i<options.size();i++) {
            labels[i] = options.get(i).name(activity);
            checked[i] = draft.contains(options.get(i).id);
        }
        U.dialog(activity).setTitle(t("بطولات التقويم · اختر حتى ٣","Calendar leagues · Choose up to 3"))
            .setMultiChoiceItems(labels,checked,(choice,which,enabled) -> {
                String id = options.get(which).id;
                if (!enabled) draft.remove(id);
                else if (draft.size() < LIMIT) draft.add(id);
                else {
                    ((AlertDialog)choice).getListView().setItemChecked(which,false);
                    checked[which] = false;
                    Toast.makeText(activity,t("الحد الأقصى ٣ بطولات","Choose at most 3 leagues"),Toast.LENGTH_SHORT).show();
                }
            })
            .setPositiveButton(t("حفظ","Save"),(choice,which) -> {
                if (!leagues.equals(draft)) dayCache.clear();
                leagues.clear();
                leagues.addAll(draft);
                Settings.prefs(activity).edit().putStringSet(PREF,new LinkedHashSet<>(leagues)).apply();
                renderGrid();
                showFixtures();
                loadMonth();
            })
            .setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void renderGrid() {
        filter.setText(t("بطولات التقويم","Calendar leagues") + "  ·  " + numeral(leagues.size()) + "/" + numeral(LIMIT));
        monthLabel.setText(month.format(DateTimeFormatter.ofPattern("MMMM uuuu",locale).withDecimalStyle(digits)));
        grid.removeAllViews();
        String[] days = Settings.ar(activity)
            ? new String[]{"السبت","الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة"}
            : new String[]{"Sat","Sun","Mon","Tue","Wed","Thu","Fri"};
        LinearLayout labels = U.row(activity);
        labels.setBackground(U.shape(U.section(activity),9,activity));
        for (String day : days) {
            TextView caption = U.txt(activity,day,11,true,U.sub(activity));
            caption.setGravity(Gravity.CENTER);
            labels.addView(caption,new LinearLayout.LayoutParams(0,U.dp(activity,29),1));
        }
        grid.addView(labels);
        int offset = (month.atDay(1).getDayOfWeek().getValue()+1)%7;
        for (int i=0;i<offset+month.lengthOfMonth();i+=7) {
            LinearLayout week = U.row(activity);
            for (int column=0;column<7;column++) {
                int day = i+column-offset+1;
                View tile = day < 1 || day > month.lengthOfMonth() ? new View(activity) : dateTile(month.atDay(day));
                week.addView(tile,new LinearLayout.LayoutParams(0,U.dp(activity,44),1));
            }
            grid.addView(week);
        }
    }

    private View dateTile(LocalDate date) {
        boolean active = date.equals(selected);
        LinearLayout tile = U.col(activity);
        tile.setGravity(Gravity.CENTER);
        if (active) tile.setBackground(U.selected(activity));
        tile.setSelected(active);
        TextView day = U.txt(activity,numeral(date.getDayOfMonth()),16,active,active?U.selectedInk():U.text(activity));
        day.setGravity(Gravity.CENTER);
        tile.addView(day,U.lp(activity,-1,23));
        LinearLayout marks = U.row(activity);
        marks.setGravity(Gravity.CENTER);
        List<String> announced = new ArrayList<>();
        Map<String,Set<LocalDate>> byLeague = monthCache.getOrDefault(month,Collections.emptyMap());
        for (String id : leagues) {
            if (!byLeague.getOrDefault(id,Collections.emptySet()).contains(date)) continue;
            android.widget.ImageView crest = U.logo(activity,FotMob.leagueLogo(id),12);
            crest.setBackground(U.shape(0xFFE2F4FF,6,activity));
            U.pad(crest,1);
            marks.addView(crest);
            announced.add(League.byId(id).name(activity));
        }
        tile.addView(marks,U.lp(activity,-1,14));
        tile.setContentDescription(date.format(DateTimeFormatter.ofPattern("EEEE d MMMM",locale).withDecimalStyle(digits))
            + (announced.isEmpty() ? "" : " · " + String.join("، ",announced)));
        tile.setOnClickListener(v -> {
            selected = date;
            renderGrid();
            showFixtures();
        });
        return tile;
    }

    private void loadMonth() {
        int request = ++monthRequest;
        if (monthJob != null) monthJob.cancel(false);
        YearMonth requested = month;
        Map<String,Set<LocalDate>> current = monthCache.getOrDefault(requested,Collections.emptyMap());
        Set<String> pending = new LinkedHashSet<>(leagues);
        pending.removeAll(current.keySet());
        if (pending.isEmpty()) return;
        monthJob = workers.submit(() -> {
            Map<String,Set<LocalDate>> found = new HashMap<>();
            for (String id : pending) {
                if (Thread.currentThread().isInterrupted()) return;
                Set<LocalDate> dates = new LinkedHashSet<>();
                for (Match match : ScoreRepository.calendarFixtures(activity.getApplicationContext(),id,requested)) {
                    LocalDate date = Upcoming.day(match,ScoreRepository.CAIRO);
                    if (date != null && YearMonth.from(date).equals(requested)) dates.add(date);
                }
                found.put(id,dates);
            }
            activity.runOnUiThread(() -> {
                if (!dialog.isShowing() || request != monthRequest) return;
                monthCache.computeIfAbsent(requested,key -> new HashMap<>()).putAll(found);
                renderGrid();
            });
        });
    }

    private void showFixtures() {
        int request = ++dayRequest;
        if (dayJob != null) dayJob.cancel(false);
        LocalDate date = selected;
        List<Match> cached = dayCache.get(date);
        renderFixtures(cached);
        if (cached != null) return;
        Set<String> requestedLeagues = new LinkedHashSet<>(leagues);
        dayJob = workers.submit(() -> {
            List<Match> matches = ScoreRepository.matches(activity.getApplicationContext(),date,false,requestedLeagues);
            activity.runOnUiThread(() -> {
                if (!dialog.isShowing() || request != dayRequest) return;
                if (!matches.isEmpty()) dayCache.put(date,matches);
                renderFixtures(matches);
            });
        });
    }

    private void renderFixtures(List<Match> source) {
        fixtures.removeAllViews();
        LinearLayout heading = U.row(activity);
        U.pad(heading,9,0,5,0);
        heading.setBackground(U.selected(activity));
        TextView title = U.txt(activity,t("مباريات ","Matches · ")+selected.format(
            DateTimeFormatter.ofPattern("EEEE d MMMM",locale).withDecimalStyle(digits)),14,true,U.selectedInk());
        heading.addView(title,U.weight(activity,1));
        TextView all = U.txt(activity,t("عرض الكل","See all"),12,true,U.selectedInk());
        all.setGravity(Gravity.CENTER);
        heading.addView(all,U.lp(activity,70,42));
        all.setOnClickListener(v -> { dialog.dismiss(); openDay.accept(selected); });
        fixtures.addView(heading,U.lp(activity,-1,-2));
        U.space(fixtures,7);
        if (source == null) {
            ProgressBar loading = new ProgressBar(activity);
            fixtures.addView(loading,U.lp(activity,28,28));
            return;
        }
        if (source.isEmpty()) {
            TextView empty = U.txt(activity,t("لا توجد مباريات متاحة في هذا اليوم","No matches available on this day"),14,false,U.sub(activity));
            empty.setGravity(Gravity.CENTER);
            fixtures.addView(empty,U.lp(activity,-1,51));
            return;
        }
        Set<String> followed = Settings.matchFavorites(activity);
        Set<String> pinned = Settings.favoriteLeagues(activity);
        List<Match> ranked = new ArrayList<>(source);
        ranked.sort(Comparator.comparing((Match m) -> !m.concerns(followed))
            .thenComparing(m -> !m.isLive())
            .thenComparing(m -> !leagues.contains(m.leagueId))
            .thenComparing(m -> !pinned.contains(m.leagueId))
            .thenComparing(Upcoming::start));
        ScoresCards cards = new ScoresCards(activity,new ScoresStyle(activity));
        for (int i=0;i<Math.min(LIMIT,ranked.size());i++) {
            Match match = ranked.get(i);
            LinearLayout card = U.card(activity);
            card.addView(cards.fixture(match,true,false,true),U.lp(activity,-1,-2));
            card.addView(U.leagueFollow(activity,match.leagueId,() -> {
                onLeagueChanged.run();
                renderFixtures(source);
            }),U.lp(activity,-1,44));
            fixtures.addView(card,U.lp(activity,-1,-2));
            U.space(fixtures,5);
        }
    }

    private String numeral(int value) {
        if (digits.getZeroDigit() == '0') return Integer.toString(value);
        String ascii = Integer.toString(value);
        StringBuilder result = new StringBuilder();
        for (int i=0;i<ascii.length();i++) result.append((char)(digits.getZeroDigit()+ascii.charAt(i)-'0'));
        return result.toString();
    }
    private String t(String ar,String en) { return Settings.t(activity,ar,en); }
}
