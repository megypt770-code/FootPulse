package com.tahawy.footpulse;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Snapshot widget: displays the last scores fetched in the app, no background tracking or SDK. */
public final class ScoreWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context context,AppWidgetManager manager,int[] ids){render(context,manager,ids);}
    static void publish(Context context,List<Match> matches){
        List<Match> preferred=new ArrayList<>(matches);
        preferred.sort((a,b)->Boolean.compare(b.isLive(),a.isLive()));
        StringBuilder builder=new StringBuilder();
        int count=0;
        for(Match game:preferred){
            String score=game.homeScore!=null&&!game.homeScore.isEmpty()&&game.awayScore!=null&&!game.awayScore.isEmpty()
                ?game.homeScore+" - "+game.awayScore:ScoreRepository.localTime(game.isoDate);
            builder.append(game.home).append("  ").append(score).append("  ").append(game.away).append('\n');
            if(++count==3)break;
        }
        if(count==0)builder.append(Settings.t(context,"لا توجد مباريات معروضة اليوم","No fixtures today"));
        Settings.prefs(context).edit().putString("widget_scores",builder.toString().trim())
            .putString("widget_time",LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))).apply();
        AppWidgetManager manager=AppWidgetManager.getInstance(context);
        ComponentName receiver=new ComponentName(context,ScoreWidget.class);
        int[] widgets=manager.getAppWidgetIds(receiver);
        render(context,manager,widgets);
    }
    private static void render(Context context,AppWidgetManager manager,int[] ids){
        for(int widgetId:ids){
            RemoteViews view=new RemoteViews(context.getPackageName(),R.layout.widget_scores);
            view.setTextViewText(R.id.widget_scores,Settings.prefs(context).getString("widget_scores",Settings.t(context,"افتح التطبيق لعرض نتائج المباريات","Open the app for match scores")));
            String updated=Settings.prefs(context).getString("widget_time","");
            view.setTextViewText(R.id.widget_updated,updated.isEmpty()?Settings.t(context,"اضغط للفتح","Tap to open"):Settings.t(context,"آخر تحديث ","Last opened ")+updated);
            Intent launch=new Intent(context,MainActivity.class);
            PendingIntent click=PendingIntent.getActivity(context,0,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            view.setOnClickPendingIntent(R.id.widget_root,click);
            manager.updateAppWidget(widgetId,view);
        }
    }
}
