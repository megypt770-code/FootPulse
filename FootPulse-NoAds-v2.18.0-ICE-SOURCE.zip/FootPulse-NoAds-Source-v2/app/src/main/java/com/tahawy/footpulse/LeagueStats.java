package com.tahawy.footpulse;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

final class LeagueStats {
    final String title, key, url, format;
    final boolean players;
    final List<Rank> leaders = new ArrayList<>();

    static final class Rank {
        final String name, club, playerId, teamId, value;
        final int rank;
        Rank(String name,String club,String playerId,String teamId,String value,int rank) {
            this.name=name; this.club=club; this.playerId=playerId; this.teamId=teamId;
            this.value=value; this.rank=rank;
        }
    }

    private LeagueStats(String title,String key,String url,String format,boolean players) {
        this.title=title; this.key=key; this.url=url; this.format=format; this.players=players;
    }

    static List<String> seasons(JSONObject page) {
        List<String> result = new ArrayList<>();
        JSONArray source = page.optJSONArray("allAvailableSeasons");
        if (source != null) for (int i=0;i<source.length();i++) {
            String season = source.optString(i);
            if (!season.isEmpty() && !result.contains(season)) result.add(season);
        }
        return result;
    }

    static List<LeagueStats> read(JSONObject page,boolean players) {
        List<LeagueStats> result = new ArrayList<>();
        JSONObject stats = page.optJSONObject("stats");
        JSONArray groups = stats == null ? null : stats.optJSONArray(players ? "players" : "teams");
        if (groups == null) return result;
        for (int i=0;i<groups.length();i++) {
            JSONObject group = groups.optJSONObject(i);
            if (group == null) continue;
            JSONObject leader = group.optJSONObject("participant");
            JSONObject stat = leader == null ? null : leader.optJSONObject("stat");
            LeagueStats card = new LeagueStats(group.optString("header"),stat == null ? "" : stat.optString("name"),
                group.optString("fetchAllUrl"),stat == null ? "" : stat.optString("format"),players);
            JSONArray top = group.optJSONArray("topThree");
            if (top != null) for (int j=0;j<top.length();j++) {
                JSONObject row = top.optJSONObject(j);
                if (row == null || row.optString("name").isEmpty()) continue;
                card.leaders.add(new Rank(row.optString("name"),row.optString("teamName"),row.optString("id"),
                    row.optString("teamId"),display(row.opt("value"),card.format),row.optInt("rank",j+1)));
            }
            if (!card.leaders.isEmpty()) result.add(card);
        }
        return result;
    }

    private static String display(Object value,String format) {
        if (!(value instanceof Number)) return value == null || value == JSONObject.NULL ? "—" : value.toString();
        double numeric = ((Number)value).doubleValue();
        DecimalFormat number = new DecimalFormat("#,##0.##",DecimalFormatSymbols.getInstance(Locale.ROOT));
        switch (format) {
            case "percent": case "percentage": return number.format(numeric) + "%";
            case "meter": return number.format(numeric / 1000) + " km";
            case "currency": return "€" + number.format(numeric / 1_000_000) + "M";
            default: return number.format(numeric);
        }
    }

    static List<Rank> full(JSONObject data,LeagueStats card) {
        List<Rank> result = new ArrayList<>();
        JSONArray lists = data.optJSONArray("TopLists");
        if (lists == null || lists.length() == 0) return result;
        JSONObject selected = null;
        for (int i=0;i<lists.length();i++) {
            JSONObject list = lists.optJSONObject(i);
            if (list != null && (lists.length() == 1 || card.key.equals(list.optString("StatName")))) {
                selected = list;
                break;
            }
        }
        JSONArray rows = selected == null ? null : selected.optJSONArray("StatList");
        if (rows == null) return result;
        for (int i=0;i<rows.length();i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null || row.optString("ParticipantName").isEmpty()) continue;
            result.add(new Rank(row.optString("ParticipantName"),row.optString("TeamName"),
                row.optString("ParticipantId",row.optString("ParticiantId")),row.optString("TeamId"),
                display(row.opt("StatValue"),card.format),row.optInt("Rank",i+1)));
        }
        return result;
    }

    String heading(boolean arabic) {
        if (!arabic) return title;
        switch (title) {
            case "Top scorer": return "الهدّافون";
            case "Assists": return "التمريرات الحاسمة";
            case "Goals + Assists": return "الأهداف + التمريرات الحاسمة";
            case "FotMob rating": return "تقييم FotMob";
            case "Minutes played": return "الدقائق الملعوبة";
            case "Goals per 90": return "الأهداف لكل ٩٠ دقيقة";
            case "Expected goals (xG)": return "الأهداف المتوقعة (xG)";
            case "Expected goals (xG) per 90": return "الأهداف المتوقعة لكل ٩٠ دقيقة";
            case "Expected assist (xA)": return "التمريرات الحاسمة المتوقعة (xA)";
            case "Shots on target per 90": return "التسديدات على المرمى لكل ٩٠ دقيقة";
            case "Shots per 90": return "التسديدات لكل ٩٠ دقيقة";
            case "Big chances created": return "الفرص الكبيرة المصنوعة";
            case "Chances created": return "الفرص المصنوعة";
            case "Clean sheets": return "الشباك النظيفة";
            case "Yellow cards": return "البطاقات الصفراء";
            case "Red cards": return "البطاقات الحمراء";
            case "Goals scored": return "الأهداف المسجّلة";
            case "Goals conceded": return "الأهداف المستقبَلة";
            case "Ball possession": return "الاستحواذ";
            case "Accurate crosses per match": return "العرضيات الدقيقة لكل مباراة";
            case "Accurate long balls per 90": return "الكرات الطويلة الدقيقة لكل ٩٠ دقيقة";
            case "Accurate long balls per match": return "الكرات الطويلة الدقيقة لكل مباراة";
            case "Accurate passes per 90": return "التمريرات الدقيقة لكل ٩٠ دقيقة";
            case "Accurate passes per match": return "التمريرات الدقيقة لكل مباراة";
            case "Attendance": return "الحضور الجماهيري";
            case "Average possession": return "متوسط الاستحواذ";
            case "Big chances": return "الفرص الكبيرة";
            case "Big chances missed": return "الفرص الكبيرة المهدرة";
            case "Blocks per 90": return "التصدّيات الدفاعية لكل ٩٠ دقيقة";
            case "Clearances per 90": return "التشتيت لكل ٩٠ دقيقة";
            case "Clearances per match": return "التشتيت لكل مباراة";
            case "Corners": return "الركنيات";
            case "Defensive actions per 90": return "التدخلات الدفاعية لكل ٩٠ دقيقة";
            case "Distance per 90": return "المسافة المقطوعة لكل ٩٠ دقيقة";
            case "Distance per match": return "المسافة المقطوعة لكل مباراة";
            case "Expected assist (xA) per 90": return "التمريرات الحاسمة المتوقعة لكل ٩٠ دقيقة";
            case "Expected goals": return "الأهداف المتوقعة";
            case "Expected goals on target (xGOT)": return "الأهداف المتوقعة من التسديدات على المرمى (xGOT)";
            case "Fouls committed per 90": return "الأخطاء المرتكبة لكل ٩٠ دقيقة";
            case "Fouls per match": return "الأخطاء لكل مباراة";
            case "Goals conceded per 90": return "الأهداف المستقبَلة لكل ٩٠ دقيقة";
            case "Goals conceded per match": return "الأهداف المستقبَلة لكل مباراة";
            case "Goals per match": return "الأهداف لكل مباراة";
            case "Goals prevented": return "الأهداف التي منعها الحارس";
            case "High claims per 90": return "التقاط الكرات العالية لكل ٩٠ دقيقة";
            case "Interceptions per 90": return "قطع التمريرات لكل ٩٠ دقيقة";
            case "Interceptions per match": return "قطع التمريرات لكل مباراة";
            case "Line-breaking passes per 90": return "التمريرات الكاسرة للخطوط لكل ٩٠ دقيقة";
            case "Penalties awarded": return "ركلات الجزاء المحتسبة";
            case "Penalties conceded": return "ركلات الجزاء المحتسبة ضد الفريق";
            case "Penalties won": return "ركلات الجزاء المكتسبة";
            case "Penalty saves": return "ركلات الجزاء التي تصدّى لها الحارس";
            case "Possession won final 3rd per 90": return "استعادة الكرة في الثلث الأخير لكل ٩٠ دقيقة";
            case "Possession won final 3rd per match": return "استعادة الكرة في الثلث الأخير لكل مباراة";
            case "Recoveries per 90": return "استعادة الكرة لكل ٩٠ دقيقة";
            case "Save percentage": return "نسبة تصدّيات الحارس";
            case "Saves per 90": return "تصدّيات الحارس لكل ٩٠ دقيقة";
            case "Saves per match": return "تصدّيات الحارس لكل مباراة";
            case "Set piece goals": return "الأهداف من الكرات الثابتة";
            case "Set piece goals conceded": return "الأهداف المستقبَلة من الكرات الثابتة";
            case "Shots on target per match": return "التسديدات على المرمى لكل مباراة";
            case "Sprints per 90": return "الانطلاقات السريعة لكل ٩٠ دقيقة";
            case "Squad value": return "القيمة السوقية للفريق";
            case "Successful dribbles per 90": return "المراوغات الناجحة لكل ٩٠ دقيقة";
            case "Sweeper actions per 90": return "تدخلات الحارس خارج المرمى لكل ٩٠ دقيقة";
            case "Tackles per 90": return "الافتكاكات لكل ٩٠ دقيقة";
            case "Tackles per match": return "الافتكاكات لكل مباراة";
            case "Top speed": return "أعلى سرعة";
            case "Total distance": return "إجمالي المسافة المقطوعة";
            case "Total sprints": return "إجمالي الانطلاقات السريعة";
            case "Touches in opposition box": return "اللمسات في منطقة جزاء الخصم";
            case "xG + xA per 90": return "الأهداف والصناعة المتوقعة لكل ٩٠ دقيقة";
            case "xG conceded": return "الأهداف المتوقعة المستقبَلة";
            case "xG difference": return "فارق الأهداف المتوقعة";
            default: return title;
        }
    }
}
