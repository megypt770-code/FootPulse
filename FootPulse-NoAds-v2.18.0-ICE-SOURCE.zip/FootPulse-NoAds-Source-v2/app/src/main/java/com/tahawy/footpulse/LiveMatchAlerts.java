package com.tahawy.footpulse;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class LiveMatchAlerts extends Service {
    private static final int RUNNING_ID = 730122;
    private static final String ONGOING = "footpulse_live_tracking";
    private static final String EVENTS = "footpulse_live_events";
    private static final Set<String> ACTIVE = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final Map<String, Watch> watches = new LinkedHashMap<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newFixedThreadPool(3);
    private NotificationManager notifications;

    static boolean watching(String key) { return ACTIVE.contains(key); }

    static boolean canWatch(Match match) {
        if (match.finished() || match.id == null || match.id.isEmpty()) return false;
        if (match.isLive()) return true;
        try {
            return !ScoreRepository.kickoff(match.isoDate).isAfter(Instant.now().plusSeconds(1800));
        } catch (RuntimeException ignored) { return false; }
    }

    static void start(Context context,Match match) {
        Intent start = U.matchIntent(context,match).setClass(context,LiveMatchAlerts.class);
        context.startForegroundService(start);
    }

    static void stop(Context context,Match match) {
        context.startService(new Intent(context,LiveMatchAlerts.class)
            .setAction("stop").putExtra("key",match.matchKey()));
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        notifications = getSystemService(NotificationManager.class);
        notifications.createNotificationChannel(new NotificationChannel(ONGOING,
            Settings.t(this,"متابعة مباراة مباشرة","Live match tracking"),NotificationManager.IMPORTANCE_LOW));
        notifications.createNotificationChannel(new NotificationChannel(EVENTS,
            Settings.t(this,"الأهداف والكروت","Goals and cards"),NotificationManager.IMPORTANCE_HIGH));
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if (intent == null || "stop-all".equals(intent.getAction())) {
            clearWatches();
            stopSelf();
            return START_NOT_STICKY;
        }
        if ("stop".equals(intent.getAction())) {
            remove(intent.getStringExtra("key"));
            return START_NOT_STICKY;
        }
        String id = intent.getStringExtra("id"), league = intent.getStringExtra("league");
        if (id == null || league == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String key = league + ":" + id;
        boolean added = !watches.containsKey(key);
        if (added) {
            Watch watch = new Watch(key,id,league,new Intent(intent).setClass(this,MatchActivity.class));
            watches.put(key,watch);
            ACTIVE.add(key);
        }
        startForeground(RUNNING_ID,ongoing());
        if (added) poll(watches.get(key));
        return START_NOT_STICKY;
    }

    private Notification ongoing() {
        PendingIntent stop = PendingIntent.getService(this,0,new Intent(this,LiveMatchAlerts.class)
            .setAction("stop-all"),PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = matchLink(watches.values().iterator().next());
        return new Notification.Builder(this,ONGOING).setSmallIcon(R.drawable.ic_app)
            .setContentTitle(Settings.t(this,"فوت بلس · متابعة مباشرة","FootPulse · Live tracking"))
            .setContentText(Settings.t(this,"جارٍ متابعة أحداث المباراة","Watching for match events"))
            .setContentIntent(open).setOngoing(true)
            .addAction(new Notification.Action.Builder(null,Settings.t(this,"إيقاف","Stop"),stop).build()).build();
    }

    private void poll(Watch watch) {
        if (watches.get(watch.key) != watch) return;
        network.execute(() -> {
            ScoreRepository.Summary summary = ScoreRepository.summary(getApplicationContext(),watch.league,watch.id);
            handler.post(() -> update(watch,summary));
        });
    }

    private void update(Watch watch,ScoreRepository.Summary summary) {
        if (watches.get(watch.key) != watch) return;
        if (summary.updatedAt > watch.lastUpdate && summary.updatedAt >= System.currentTimeMillis() - 90_000L) {
            watch.lastUpdate = summary.updatedAt;
            Match state = new Match();
            MatchActivity.applyScore(summary.data,state);
            JSONArray events = summary.data.optJSONArray("keyEvents");
            if (events != null) {
                for (int i = 0; i < events.length(); i++) {
                    JSONObject event = events.optJSONObject(i);
                    if (event == null) continue;
                    String kind = event.optString("kind");
                    if (MatchText.card(kind) == 0 && !MatchText.key(kind).endsWith("goal")) continue;
                    JSONObject clock = event.optJSONObject("clock");
                    String minute = clock == null ? "" : clock.optString("displayValue");
                    String player = event.optString("player");
                    String eventId = event.optString("eventId");
                    String key = eventId.isEmpty() ? kind + "|" + minute + "|" + player + "|" +
                        event.optBoolean("isHome") : eventId;
                    if (watch.seen.add(key) && watch.baseline) publish(watch,kind,player,minute,key,state);
                }
                watch.baseline = true;
            } else if ("pre".equals(state.state)) {
                watch.baseline = true;
            }
            if (state.finished()) {
                remove(watch.key);
                return;
            }
        }
        if (System.currentTimeMillis() - watch.startedAt > 4 * 3600_000L) {
            remove(watch.key);
            return;
        }
        handler.postDelayed(() -> poll(watch),25_000L);
    }

    private void publish(Watch watch,String kind,String player,String minute,String key,Match state) {
        String title = MatchText.event(this,kind) + (minute.isEmpty() ? "" : " · " + minute);
        String home = Club.name(this,watch.open.getStringExtra("home"));
        String away = Club.name(this,watch.open.getStringExtra("away"));
        String score = state.homeScore == null || state.awayScore == null ? " – " :
            " " + state.homeScore + "–" + state.awayScore + " ";
        String body = home + score + away;
        if (!player.isEmpty()) body = player + " · " + body;
        notifications.notify((watch.key + "|" + key).hashCode(),new Notification.Builder(this,EVENTS)
            .setSmallIcon(R.drawable.ic_app).setContentTitle(title).setContentText(body)
            .setStyle(new Notification.BigTextStyle().bigText(body))
            .setContentIntent(matchLink(watch)).setAutoCancel(true).build());
    }

    private PendingIntent matchLink(Watch watch) {
        return PendingIntent.getActivity(this,watch.key.hashCode(),watch.open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void remove(String key) {
        watches.remove(key);
        if (key != null) ACTIVE.remove(key);
        if (watches.isEmpty()) stopSelf();
        else notifications.notify(RUNNING_ID,ongoing());
    }

    private void clearWatches() {
        for (Watch watch : new ArrayList<>(watches.values())) ACTIVE.remove(watch.key);
        watches.clear();
    }

    @Override public void onDestroy() {
        clearWatches();
        handler.removeCallbacksAndMessages(null);
        network.shutdownNow();
        super.onDestroy();
    }

    private static final class Watch {
        final String key,id,league;
        final Intent open;
        final Set<String> seen = new HashSet<>();
        final long startedAt = System.currentTimeMillis();
        boolean baseline;
        long lastUpdate;

        Watch(String key,String id,String league,Intent open) {
            this.key = key;
            this.id = id;
            this.league = league;
            this.open = open;
        }
    }
}
