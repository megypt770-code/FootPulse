package com.tahawy.footpulse;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Resolution-independent artwork behind the native match controls. */
final class IceArtwork extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final boolean stadium;

    IceArtwork(boolean stadium) { this.stadium = stadium; }

    @Override public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        canvas.save();
        canvas.translate(b.left,b.top);
        canvas.scale(b.width()/400f,b.height()/160f);
        if (stadium) {
            Path frame = new Path();
            frame.addRoundRect(0,0,400,160,15,15,Path.Direction.CW);
            canvas.clipPath(frame);
            drawStadium(canvas);
        } else drawRibbon(canvas);
        canvas.restore();
    }

    private void drawRibbon(Canvas c) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(.68f);
        for (int i=0;i<23;i++) {
            Path wave = new Path();
            wave.moveTo(-25,-30 + i*2.15f);
            wave.cubicTo(103,-57 + i*2.6f,147,148 - i*3.4f,311,78-i*.9f);
            paint.setShader(new LinearGradient(0,0,320,0,new int[]{0x153BB8FF,0x7256D5FF,0x0056D5FF},null,Shader.TileMode.CLAMP));
            c.drawPath(wave,paint);
        }
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawStadium(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0,0,0,160,new int[]{0xFF124683,0xFF09295F,0xFF103D77},null,Shader.TileMode.CLAMP));
        c.drawRoundRect(0,0,400,160,15,15,paint);
        paint.setShader(null);
        for (int side=0;side<2;side++) {
            float x = side == 0 ? 6 : 394;
            paint.setShader(new RadialGradient(x,12,104,new int[]{0xAA7EE6FF,0x3D248BFF,0x002172F3},null,Shader.TileMode.CLAMP));
            c.drawCircle(x,12,104,paint);
        }
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(.55f);
        for (int row=0;row<10;row++) {
            Path stand = new Path();
            stand.moveTo(0,49 + row*5f);
            stand.quadTo(200,116 + row*4f,400,49 + row*5f);
            paint.setColor(row % 3 == 0 ? 0x4A55BAFF : 0x242786D6);
            c.drawPath(stand,paint);
        }
        paint.setStyle(Paint.Style.FILL);
        for (int side=0;side<2;side++) for (int lamp=0;lamp<8;lamp++) {
            float x = side == 0 ? 6+lamp*4 : 394-lamp*4;
            float y = 12+lamp*1.15f;
            paint.setColor(0x6084E3FF);
            c.drawCircle(x,y,3.2f,paint);
            paint.setColor(0xFFDCF8FF);
            c.drawCircle(x,y,1.25f,paint);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(.8f);
        paint.setColor(0xFF458DDD);
        c.drawRoundRect(.6f,.6f,399.4f,159.4f,15,15,paint);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override public void setAlpha(int alpha) {}
    @Override public void setColorFilter(ColorFilter filter) {}
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
