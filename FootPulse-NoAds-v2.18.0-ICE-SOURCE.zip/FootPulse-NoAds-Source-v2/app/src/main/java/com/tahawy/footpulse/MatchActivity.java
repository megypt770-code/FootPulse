package com.tahawy.footpulse;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

/** Original native match centre, inspired by common sports-app navigation patterns. */
public final class MatchActivity extends Activity {
    private final Match m=new Match();
    private LinearLayout root,content;
    private JSONObject data=new JSONObject();
    private int section;
    private boolean tacticalPitch = true;
    private boolean awayLineup;
    private ScrollView scroll;
    private final int[] sectionScroll = new int[6];
    private boolean foreground, refreshing;
    private long updatedAt;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = this::load;
    private boolean loading=true,tableLoading=false;
    private boolean historyHome, historyLeague;
    private List<Standing> standings=new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) {
            section = state.getInt("section",0);
            tacticalPitch = state.getBoolean("tacticalPitch",true);
            awayLineup = state.getBoolean("awayLineup",false);
            historyHome = state.getBoolean("historyHome",false);
            historyLeague = state.getBoolean("historyLeague",false);
            int[] previous = state.getIntArray("sectionScroll");
            if (previous != null && previous.length == sectionScroll.length)
                System.arraycopy(previous,0,sectionScroll,0,previous.length);
        }
        readExtras();
        render();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        rememberSectionScroll();
        state.putIntArray("sectionScroll",sectionScroll);
        state.putInt("section", section);
        state.putBoolean("tacticalPitch",tacticalPitch);
        state.putBoolean("awayLineup",awayLineup);
        state.putBoolean("historyHome",historyHome);
        state.putBoolean("historyLeague",historyLeague);
    }

    @Override protected void onResume() {
        super.onResume();
        foreground = true;
        load();
    }

    @Override protected void onPause() {
        foreground = false;
        handler.removeCallbacks(refresh);
        super.onPause();
    }

    private void readExtras(){
        Intent i=getIntent();m.id=i.getStringExtra("id");m.leagueId=i.getStringExtra("league");
        m.home=i.getStringExtra("home");m.away=i.getStringExtra("away");
        m.homeId=i.getStringExtra("homeId");m.awayId=i.getStringExtra("awayId");
        m.homeLogo=i.getStringExtra("homeLogo");m.awayLogo=i.getStringExtra("awayLogo");
        m.homeScore=i.getStringExtra("homeScore");m.awayScore=i.getStringExtra("awayScore");
        m.isoDate=i.getStringExtra("iso");m.state=i.getStringExtra("state");m.status=i.getStringExtra("status");m.venue=i.getStringExtra("venue");
        m.competitionName=i.getStringExtra("competitionName");
        if(m.leagueId==null)m.leagueId="eng.1";
    }
    private void rememberSectionScroll() {
        if (scroll != null && scroll.getChildAt(0).getHeight() > scroll.getHeight())
            sectionScroll[section] = scroll.getScrollY();
    }
    private void render() {
        rememberSectionScroll();
        int y = sectionScroll[section];
        U.systemBar(this);
        root = U.col(this);
        root.setBackground(U.backdrop(this));
        setContentView(root);
        addBrandHeader();
        addScoreHeader();
        addVenueCard();
        LinearLayout details = U.col(this);
        addTabs(details);
        scroll = U.scroll(this);
        content = U.col(this);
        U.pad(content,12,7,12,24);
        scroll.addView(content);
        scroll.setFillViewport(true);
        details.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout.LayoutParams panel = new LinearLayout.LayoutParams(-1,0,1);
        panel.setMargins(U.dp(this,6),U.dp(this,5),U.dp(this,6),0);
        root.addView(details,panel);
        root.addView(U.navigation(this,0,target -> {
            Intent intent = new Intent(this,MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            intent.putExtra("openTab",target);
            startActivity(intent);
            finish();
        }));
        if (loading) {
            ProgressBar progress = new ProgressBar(this);
            LinearLayout.LayoutParams params = U.lp(this, 34, 34);
            params.gravity = Gravity.CENTER_HORIZONTAL;
            content.addView(progress, params);
            return;
        }
        switch(section) {
            case 0: overview(); break;
            case 1: timeline(); break;
            case 2: statistics(); break;
            case 3: lineups(); break;
            case 4: headToHead(); break;
            default: table();
        }
        ScrollView current = scroll;
        if (y > 0) current.post(() -> current.scrollTo(0,y));
    }

    private void addBrandHeader() {
        LinearLayout bar = U.row(this);
        U.pad(bar,15,7,15,9);
        View back = U.roundAction(this,R.drawable.ui_back,Settings.t(this,"رجوع","Back"),this::finish);
        if (Settings.ar(this)) back.setScaleX(-1);
        bar.addView(back,U.lp(this,44,44));
        TextView title = U.txt(this,Settings.t(this,"تفاصيل المباراة","Match Details"),19,true,U.text(this));
        title.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        title.setSingleLine();
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bar.addView(title,U.weight(this,1));
        if (!m.finished()) {
            boolean watching = LiveMatchAlerts.watching(m.matchKey());
            View bell = U.roundAction(this,R.drawable.ui_bell,
                watching ? Settings.t(this,"إيقاف تنبيهات المباراة","Stop match alerts")
                    : Settings.t(this,"تنبيهات المباراة","Match alerts"),this::toggleLiveAlerts);
            if (watching) {
                bell.setBackground(U.selected(this));
                ((ImageView)((FrameLayout)bell).getChildAt(0)).setColorFilter(U.selectedInk());
            }
            bar.addView(bell,U.lp(this,42,44));
        }
        View options = U.roundAction(this,R.drawable.ui_dots,Settings.t(this,"خيارات المباراة","Match options"),this::matchOptions);
        bar.addView(options,U.lp(this,44,44));
        root.addView(bar);
    }

    private void toggleLiveAlerts() {
        if (LiveMatchAlerts.watching(m.matchKey())) {
            LiveMatchAlerts.stop(this,m);
            render();
            return;
        }
        if (!LiveMatchAlerts.canWatch(m)) {
            Toast.makeText(this,Settings.t(this,"التنبيهات متاحة قبل البداية بنصف ساعة وأثناء اللعب.",
                "Live alerts are available from 30 minutes before kickoff."),Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},51);
            return;
        }
        startLiveAlerts();
    }

    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(request,permissions,results);
        if (request == 51 && results.length > 0 && results[0] == android.content.pm.PackageManager.PERMISSION_GRANTED)
            startLiveAlerts();
    }

    private void startLiveAlerts() {
        try {
            LiveMatchAlerts.start(this,m);
            handler.postDelayed(() -> { if (foreground && !isDestroyed()) render(); },350);
        } catch (IllegalStateException | SecurityException failed) {
            Toast.makeText(this,Settings.t(this,"تعذر تشغيل تنبيهات المباراة.","Could not start match alerts."),
                Toast.LENGTH_SHORT).show();
        }
    }

    private void matchOptions() {
        String save = Settings.bookmarked(this,m) ? Settings.t(this,"إزالة الحفظ","Remove bookmark")
            : Settings.t(this,"حفظ المباراة","Bookmark match");
        String[] actions = {Settings.t(this,"ملخص المباراة والقنوات","Match overview & TV"),
            Settings.t(this,"المواجهات السابقة","Head-to-head"),Settings.t(this,"الترتيب","Standings"),
            save,Settings.t(this,"تحديث التفاصيل","Refresh details")};
        U.dialog(this).setTitle(Settings.t(this,"خيارات المباراة","Match options")).setItems(actions,(dialog,which) -> {
            switch (which) {
                case 0: changeSection(0); break;
                case 1: changeSection(4); break;
                case 2: changeSection(5); break;
                case 3: Settings.bookmark(this,m); render(); break;
                case 4: load(); break;
            }
        }).show();
    }

    private void addScoreHeader() {
        LinearLayout card = new ScoresCards(this,new ScoresStyle(this)).header(m,this::showCoverage);
        if (FotMob.supports(m.leagueId)) {
            U.space(card,7);
            card.addView(U.leagueFollow(this,m.leagueId,null),U.lp(this,-2,44));
        }
        LinearLayout.LayoutParams params = U.lp(this,-1,-2);
        params.setMargins(U.dp(this,9),0,U.dp(this,9),U.dp(this,8));
        root.addView(card,params);
    }

    private static boolean hasValue(String value) { return value != null && !value.isEmpty(); }

    private void addTabs(LinearLayout parent) {
        HorizontalScrollView strip = new HorizontalScrollView(this);
        strip.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = U.row(this);
        tabs.setBackground(U.glass(this,12));
        U.pad(tabs,3);
        String[] labels = {Settings.t(this,"الملخص","Summary"),Settings.t(this,"الترتيب","Table"),
            Settings.t(this,"المواجهات السابقة","Head-to-head"),Settings.t(this,"الأحداث","Events"),
            Settings.t(this,"الإحصائيات","Statistics"),Settings.t(this,"التشكيلة","Lineup")};
        int[] order = {0,5,4,1,2,3};
        for (int i=0;i<labels.length;i++) {
            final int target = order[i];
            TextView item = U.chip(this,labels[i],section == target);
            item.setSingleLine();
            item.setSelected(section == target);
            item.setOnClickListener(v -> changeSection(target));
            tabs.addView(item,U.lp(this,-2,39));
            if (section == target) strip.post(() -> item.requestRectangleOnScreen(
                new android.graphics.Rect(0,0,item.getWidth(),item.getHeight()),true));
        }
        strip.addView(tabs);
        LinearLayout.LayoutParams params = U.lp(this,-1,-2);
        params.setMargins(U.dp(this,7),0,U.dp(this,7),U.dp(this,4));
        parent.addView(strip,params);
    }

    private void addVenueCard() {
        JSONObject venue = data.optJSONObject("stadium");
        String name = venue == null ? m.venue : venue.optString("name",m.venue == null ? "" : m.venue);
        if (!hasValue(name)) {
            if (loading) return;
            name = Settings.t(this,"الاستاد غير متاح","Stadium unavailable");
        }
        LinearLayout card = U.card(this);
        U.pad(card,11,8,11,8);
        LinearLayout main = U.row(this);
        main.addView(U.icon(this,R.drawable.ui_stadium,33,U.accent(this)));
        LinearLayout labels = U.col(this);
        U.pad(labels,9,0,9,0);
        labels.addView(U.txt(this,venueName(name),16,true,U.text(this)));
        if (venue != null) {
            List<String> location = new ArrayList<>();
            String city = venue.optString("city");
            String country = venue.optString("country");
            if (hasValue(city)) location.add(venueName(city));
            if (hasValue(country)) location.add(venueName(country));
            if (!location.isEmpty()) {
                U.space(labels,3);
                labels.addView(U.txt(this,String.join(Settings.ar(this) ? "، " : ", ",location),12,false,U.sub(this)));
            }
        }
        main.addView(labels,U.weight(this,1));
        card.addView(main,U.lp(this,-1,-2));
        if (venue != null) {
            int capacity = venue.optInt("capacity");
            String surface = venue.optString("surface");
            List<String> details = new ArrayList<>();
            if (capacity > 0) details.add(Settings.t(this,"السعة ","Capacity ") +
                java.text.NumberFormat.getIntegerInstance(Settings.ar(this) ? new Locale("ar","EG") : Locale.ENGLISH).format(capacity));
            if (hasValue(surface)) details.add(venueName(surface));
            if (!details.isEmpty()) {
                U.space(card,5);
                U.line(card);
                U.space(card,5);
                card.addView(U.txt(this,String.join("   ·   ",details),12,true,U.sub(this)));
            }
        }
        LinearLayout.LayoutParams bounds = U.lp(this,-1,-2);
        bounds.setMargins(U.dp(this,9),0,U.dp(this,9),U.dp(this,7));
        root.addView(card,bounds);
    }

    private String venueName(String value) {
        if (!Settings.ar(this)) return value;
        switch (value.toLowerCase(Locale.ROOT)) {
            case "etihad stadium": return "ملعب الاتحاد";
            case "manchester": return "مانشستر";
            case "england": return "إنجلترا";
            case "grass": return "أرضية عشبية";
            case "artificial turf": return "عشب صناعي";
            case "hybrid grass": return "عشب هجين";
            default: return value;
        }
    }

    private void changeSection(int target) {
        rememberSectionScroll();
        section = target;
        scroll = null;
        render();
        if (section == 5 && standings.isEmpty() && !tableLoading) loadTable();
    }

    private void load() {
        if (refreshing || isFinishing() || isDestroyed()) return;
        refreshing = true;
        handler.removeCallbacks(refresh);
        new Thread(() -> {
            ScoreRepository.Summary response = ScoreRepository.summary(getApplicationContext(),m.leagueId,m.id);
            runOnUiThread(() -> {
                refreshing = false;
                if (isFinishing() || isDestroyed()) return;
                boolean changed = loading;
                loading = false;
                if (response.updatedAt > updatedAt && response.data.length() > 0) {
                    updatedAt = response.updatedAt;
                    data = response.data;
                    applyScore(data,m);
                    changed = true;
                }
                if (changed) render();
                if (foreground && !m.finished()) {
                    handler.postDelayed(refresh, m.isLive() ? 25_000L : 60_000L);
                }
            });
        }, "match-summary").start();
    }

    static void applyScore(JSONObject data, Match match) {
        JSONObject header = data.optJSONObject("header");
        JSONArray competitions = header == null ? null : header.optJSONArray("competitions");
        JSONObject contest = competitions == null ? null : competitions.optJSONObject(0);
        if (contest == null) return;
        JSONObject status = contest.optJSONObject("status");
        JSONObject type = status == null ? null : status.optJSONObject("type");
        if (type != null) {
            match.state = type.optString("state",match.state);
            match.status = type.optString("shortDetail",type.optString("detail",match.status));
            if (match.isLive() && status != null && !"STATUS_HALFTIME".equals(type.optString("name"))) {
                String clock = status.optString("displayClock");
                if (hasValue(clock)) match.status = clock;
            }
        }
        JSONArray competitors = contest.optJSONArray("competitors");
        if (competitors == null) return;
        for (int i = 0; i < competitors.length(); i++) {
            JSONObject side = competitors.optJSONObject(i);
            if (side == null || side.isNull("score")) continue;
            String role = side.optString("homeAway");
            JSONObject detail = side.optJSONObject("score");
            String value = detail == null ? side.optString("score") : detail.optString("displayValue");
            if (!hasValue(value)) continue;
            if ("home".equals(role)) match.homeScore = value;
            if ("away".equals(role)) match.awayScore = value;
        }
    }

    private void overview(){
        JSONObject box = data.optJSONObject("boxscore");
        JSONArray teams = box == null ? null : box.optJSONArray("teams");
        if (teams != null && teams.length() == 2) {
            LinearLayout possession = U.card(this);
            U.pad(possession,12);
            if (statisticsRows(possession,teams,true)>0) {
                content.addView(possession,U.lp(this,-1,-2));
                U.space(content,9);
            }
        }
        events(true);
        U.space(content,10);
        LinearLayout card=U.card(this);U.pad(card,16);
        card.addView(U.heading(this,Settings.t(this,"معلومات المباراة","Match information")));
        detailLine(card,Settings.t(this,"البطولة","Competition"),competition(m));
        detailLine(card,Settings.t(this,"الموعد · توقيت القاهرة","Kickoff · Cairo time"),kickoffLabel());
        detailLine(card,Settings.t(this,"الحالة","Status"),MatchText.status(this,m));
        JSONObject gameInfo=data.optJSONObject("gameInfo");
        if(gameInfo!=null){JSONObject attendance=gameInfo.optJSONObject("attendance");if(attendance!=null)detailLine(card,Settings.t(this,"الحضور","Attendance"),attendance.optString("displayValue",""));
            JSONArray officials=gameInfo.optJSONArray("officials");if(officials!=null&&officials.length()>0){JSONObject official=officials.optJSONObject(0);if(official!=null)detailLine(card,Settings.t(this,"الحكم","Referee"),official.optString("displayName",""));}}
        TextView save = U.chip(this, Settings.bookmarked(this,m)
            ? Settings.t(this,"★ محفوظة","★ Saved") : Settings.t(this,"☆ حفظ المباراة","☆ Save match"),
            Settings.bookmarked(this,m));
        save.setOnClickListener(v -> { Settings.bookmark(this,m); render(); });
        card.addView(save);
        content.addView(card);U.space(content,13);
    }

    private String kickoffLabel() {
        try {
            Locale locale = Settings.ar(this) ? new Locale("ar","EG") : Locale.ENGLISH;
            return ScoreRepository.kickoff(m.isoDate).atZone(ScoreRepository.CAIRO)
                .format(java.time.format.DateTimeFormatter.ofPattern("EEE d MMM · HH:mm",locale));
        } catch (RuntimeException ignored) {
            return Settings.t(this,"الموعد غير متاح","Kickoff unavailable");
        }
    }

    private void showCoverage() {
        AlertDialog dialog = U.dialog(this)
            .setTitle(Settings.t(this,"القنوات الناقلة","TV channels"))
            .setMessage(Settings.t(this,"جارٍ التحقق من جدول البث…","Checking the TV schedule…"))
            .setPositiveButton(Settings.t(this,"إغلاق","Close"),null).show();
        TvInfo.loadCoverage(this,m,bySource -> {
            if (!dialog.isShowing()) return;
            List<String> lines = new ArrayList<>();
            for (Map.Entry<String,List<String>> entry : bySource.entrySet()) {
                lines.add(entry.getKey() + "\n" + String.join(" · ",entry.getValue()));
            }
            dialog.setMessage(lines.isEmpty()
                ? Settings.t(this,"لا توجد قناة مؤكدة لهذه المباراة في المصادر المتاحة.","No confirmed channel was found for this match.")
                : String.join("\n\n",lines));
        });
    }

    private void timeline(){content.addView(U.heading(this,Settings.t(this,"التسلسل الزمني","Timeline")));events(false);}
    private JSONArray playArray(){JSONArray events=data.optJSONArray("keyEvents");if(events==null||events.length()==0)events=data.optJSONArray("details");if(events==null)events=data.optJSONArray("scoringPlays");if(events==null){JSONObject header=data.optJSONObject("header");if(header!=null)events=header.optJSONArray("details");}return events;}
    private void events(boolean preview){
        JSONArray events=playArray();if(events==null||events.length()==0){empty(Settings.t(this,"لا تتوفر أحداث من مزود البيانات لهذه المباراة.","No event timeline is provided for this match."));return;}
        LinearLayout card=U.card(this);U.pad(card,5,4,5,6);int count=0;
        if (preview) card.addView(U.heading(this,Settings.t(this,"أبرز أحداث المباراة","Match highlights")));
        for(int i=events.length()-1;i>=0;i--){
            JSONObject e=events.optJSONObject(i);if(e==null)continue;
            String kind = e.optString("kind");
            String note = e.optString("shortText",e.optString("text",e.optString("description","")));
            JSONObject clock = e.optJSONObject("clock");
            String stamp = clock == null ? e.optString("clock","") : clock.optString("displayValue");
            LinearLayout line = U.row(this);
            U.pad(line,7,6,7,6);
            line.setMinimumHeight(U.dp(this,44));
            line.setBackground(U.shape(U.bg(this),8,this));
            TextView minute = U.txt(this,stamp,12,true,U.text(this));
            minute.setGravity(Gravity.CENTER);
            minute.setBackground(U.outlined(this,U.surface(this),U.border(this),8));
            line.addView(minute,U.lp(this,38,25));
            if (!kind.isEmpty()) {
                String label = MatchText.event(this,kind);
                addEventIcon(line,kind,label);
                String player = e.optString("player");
                note = player.isEmpty() ? label : player + " · " + label;
                String incoming = e.optString("incoming"), outgoing = e.optString("outgoing");
                if (!incoming.isEmpty() && !outgoing.isEmpty()) {
                    LinearLayout players = U.col(this);
                    players.addView(U.txt(this,"↑  " + incoming,13,true,0xFF178456));
                    players.addView(U.txt(this,"↓  " + outgoing,13,true,U.red()));
                    line.addView(players,U.weight(this,1));
                    card.addView(line);
                    U.line(card);
                    count++;
                    if (preview && count >= 5) break;
                    continue;
                }
            }
            if (note.isEmpty()) continue;
            LinearLayout description = U.col(this);
            String player = e.optString("player");
            if (!kind.isEmpty()) {
                description.addView(U.txt(this,MatchText.event(this,kind),13,true,U.text(this)));
                if (!player.isEmpty()) description.addView(U.txt(this,player,11,false,U.sub(this)));
            } else description.addView(U.txt(this,note,13,false,U.text(this)));
            line.addView(description,U.weight(this,1));
            if (!player.isEmpty() && e.has("isHome")) {
                boolean home = e.optBoolean("isHome");
                TextView club = U.txt(this,Club.name(this,home ? m.home : m.away),11,true,U.text(this));
                club.setMaxLines(2);
                club.setEllipsize(android.text.TextUtils.TruncateAt.END);
                U.pad(club,3,0,4,0);
                line.addView(club,U.lp(this,58,-2));
                line.addView(U.logo(this,home ? m.homeLogo : m.awayLogo,22));
            }
            card.addView(line);
            U.space(card,2);
            count++;if(preview&&count>=5)break;
        }
        if(count>0){content.addView(card);if(preview&&events.length()>count){TextView more=U.txt(this,Settings.t(this,"عرض كل الأحداث  ›","View full timeline  ›"),14,true,U.accent(this));U.pad(more,9,12,9,8);content.addView(more);more.setOnClickListener(v->{changeSection(1);});}}
        else empty(Settings.t(this,"لا تتوفر أحداث لهذه المباراة.","There are no detailed events for this match."));
    }
    private void addEventIcon(LinearLayout line,String kind,String label) {
        int card = MatchText.card(kind);
        LinearLayout marker = U.row(this);
        marker.setGravity(Gravity.CENTER);
        marker.setContentDescription(label);
        if (card != 0) {
            if (card == 1 || card == 3) addCardMarker(marker,0xFFFFC928);
            if (card == 2 || card == 3) addCardMarker(marker,0xFFE23646);
        } else if (MatchText.key(kind).endsWith("goal")) {
            marker.addView(U.icon(this,R.drawable.ui_ball,19,0xFF70DB67));
        } else if ("substitution".equals(MatchText.key(kind)) || "sub".equals(MatchText.key(kind))) {
            marker.addView(U.txt(this,"↑",17,true,0xFF178456));
            marker.addView(U.txt(this,"↓",17,true,U.red()));
        }
        line.addView(marker,U.lp(this,31,24));
    }

    private void addCardMarker(LinearLayout parent,int color) {
        View tile = new View(this);
        tile.setBackground(U.shape(color,2,this));
        LinearLayout.LayoutParams bounds = U.lp(this,11,17);
        bounds.setMarginEnd(U.dp(this,2));
        parent.addView(tile,bounds);
    }

    private void statistics(){
        JSONObject box=data.optJSONObject("boxscore");JSONArray teams=box==null?null:box.optJSONArray("teams");
        if(teams==null||teams.length()<2){empty(Settings.t(this,"لا تتوفر إحصائيات من مزود النتائج لهذه المباراة.","Match statistics are not provided for this fixture."));return;}
        LinearLayout card=U.col(this);U.pad(card,5,7,5,0);
        if(statisticsRows(card,teams,false)==0)empty(Settings.t(this,"الإحصائيات غير متاحة.","Statistics not available."));else content.addView(card);
    }
    private int statisticsRows(LinearLayout card,JSONArray teams,boolean onlyImportant){
        JSONObject first=teams.optJSONObject(0),second=teams.optJSONObject(1);if(first==null||second==null)return 0;
        JSONArray left=first.optJSONArray("statistics"),right=second.optJSONArray("statistics");if(left==null||right==null)return 0;
        // Reorder to home/away when the provider gives us team IDs.
        JSONObject firstTeam=first.optJSONObject("team");
        if(firstTeam!=null&&m.awayId!=null&&m.awayId.equals(firstTeam.optString("id"))){JSONArray temp=left;left=right;right=temp;}
        int displayed=0;
        for(int i=0;i<left.length();i++){
            JSONObject a=left.optJSONObject(i);if(a==null)continue;
            String key=a.optString("name","");if(key.isEmpty())continue;
            String label=MatchText.stat(this,key,a.optString("label",a.optString("displayName",key)));if(label.isEmpty())continue;
            if (onlyImportant && !key.toLowerCase(Locale.ROOT).contains("possession")) continue;
            JSONObject b=null;for(int j=0;j<right.length();j++){JSONObject r=right.optJSONObject(j);if(r!=null&&key.equals(r.optString("name"))){b=r;break;}}
            if(b==null)continue;
            String leftValue=a.optString("displayValue",a.optString("value","-"));String rightValue=b.optString("displayValue",b.optString("value","-"));
            if (onlyImportant) possessionBar(card,label,leftValue,rightValue);
            else statBar(card,label,leftValue,rightValue);
            displayed++;
            if (onlyImportant) break;
        }
        return displayed;
    }
    private void possessionBar(LinearLayout card,String label,String home,String away) {
        card.addView(U.heading(this,label));
        LinearLayout row = U.row(this);
        TextView first = U.txt(this,home,16,true,U.text(this));
        first.setGravity(Gravity.CENTER);
        row.addView(first,U.lp(this,48,29));
        LinearLayout track = U.row(this);
        track.setBackground(U.shape(U.elevated(this),8,this));
        track.setClipToOutline(true);
        View main = new View(this);
        main.setBackgroundColor(U.iceLine());
        float a = (float)Math.max(.01,number(home)), b = (float)Math.max(.01,number(away));
        track.addView(main,new LinearLayout.LayoutParams(0,U.dp(this,14),a));
        track.addView(new View(this),new LinearLayout.LayoutParams(0,U.dp(this,14),b));
        row.addView(track,U.weight(this,1));
        TextView second = U.txt(this,away,16,true,U.text(this));
        second.setGravity(Gravity.CENTER);
        row.addView(second,U.lp(this,48,29));
        card.addView(row);
    }

    private double number(String s){try{return Double.parseDouble(s.replaceAll("[^0-9.\\-]",""));}catch(Exception e){return 0;}}
    private void statBar(LinearLayout card,String name,String left,String right){
        LinearLayout values = U.row(this);
        values.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        values.addView(U.txt(this,left,13,true,U.text(this)),U.lp(this,45,-2));
        TextView label = U.txt(this,name,13,false,U.text(this));
        label.setGravity(Gravity.CENTER);
        values.addView(label,U.weight(this,1));
        TextView rightValue = U.txt(this,right,13,true,U.text(this));
        rightValue.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        values.addView(rightValue,U.lp(this,45,-2));
        card.addView(values);
        U.space(card,4);
        double a = Math.max(0,number(left)), b = Math.max(0,number(right));
        double max = Math.max(a,b);
        LinearLayout pair = U.row(this);
        pair.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        pair.addView(statTrack(max == 0 ? 0 : a/max,true),U.weight(this,1));
        pair.addView(new View(this),U.lp(this,7,1));
        pair.addView(statTrack(max == 0 ? 0 : b/max,false),U.weight(this,1));
        card.addView(pair);
        U.space(card,11);
    }

    private View statTrack(double share,boolean home) {
        FrameLayout track = new FrameLayout(this);
        track.setBackground(U.shape(U.elevated(this),5,this));
        track.setMinimumHeight(U.dp(this,6));
        View fill = new View(this);
        fill.setBackground(U.shape(home ? U.iceLine() : U.text(this),5,this));
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(0,U.dp(this,6),
            home ? Gravity.RIGHT : Gravity.LEFT);
        track.addView(fill,params);
        track.addOnLayoutChangeListener((view,left,top,right,bottom,oldLeft,oldTop,oldRight,oldBottom) -> {
            int width = (int)Math.round((right-left)*share);
            if (params.width != width) { params.width = width; fill.setLayoutParams(params); }
        });
        return track;
    }

    private void formationHeader(String team, String crest, PitchLineup lineup) {
        LinearLayout row = U.row(this);
        U.pad(row, 8, 6, 8, 6);
        row.addView(U.logo(this,crest,25));
        TextView name = U.txt(this,team,17,true,U.text(this));
        U.pad(name,7,0,7,0);
        row.addView(name,U.weight(this,1));
        row.addView(U.txt(this,lineup.formation,15,true,U.sub(this)));
        if (!lineup.rating.isEmpty()) {
            TextView rating = U.smallPill(this,lineup.rating,true);
            rating.setTextSize(13);
            rating.setContentDescription(Settings.t(this,"تقييم الفريق ","Team rating ") + lineup.rating);
            LinearLayout.LayoutParams params=U.lp(this,-2,-2);
            params.setMarginStart(U.dp(this,7));
            row.addView(rating,params);
        }
        content.addView(row);
    }

    private void lineups(){
        PitchLineup home = PitchLineup.read(data,"home",0xffca2838);
        PitchLineup away = PitchLineup.read(data,"away",0xff263445);
        if (home != null && away != null) {
            PitchLineup lineup = awayLineup ? away : home;
            if (tacticalPitch) content.addView(new PitchView(this,lineup),U.lp(this,-1,-2));
            else content.addView(new LineupPortraits(this,lineup));

            LinearLayout options = U.row(this);
            TextView first = U.chip(this,m.home,!awayLineup);
            TextView second = U.chip(this,m.away,awayLineup);
            first.setSingleLine();
            second.setSingleLine();
            first.setEllipsize(android.text.TextUtils.TruncateAt.END);
            second.setEllipsize(android.text.TextUtils.TruncateAt.END);
            options.addView(first,U.weight(this,1));
            options.addView(new View(this),U.lp(this,6,1));
            options.addView(second,U.weight(this,1));
            first.setOnClickListener(v -> { if (awayLineup) { awayLineup=false; render(); } });
            second.setOnClickListener(v -> { if (!awayLineup) { awayLineup=true; render(); } });
            U.space(content,9);
            content.addView(options);
            formationHeader(awayLineup ? m.away : m.home,awayLineup ? m.awayLogo : m.homeLogo,lineup);
            TextView mode = U.chip(this,tacticalPitch ? Settings.t(this,"الصور والتقييمات","Players & ratings")
                : Settings.t(this,"الملعب","Pitch"),false);
            mode.setOnClickListener(v -> { tacticalPitch=!tacticalPitch; render(); });
            content.addView(mode);
            return;
        }
        JSONArray rosters=data.optJSONArray("rosters");if(rosters==null){JSONObject box=data.optJSONObject("boxscore");if(box!=null)rosters=box.optJSONArray("players");}
        if(rosters==null||rosters.length()==0){empty(Settings.t(this,"التشكيلة غير متاحة من مزود النتائج لهذه المباراة.","Lineups aren't supplied for this fixture."));return;}
        int displayed=0;
        for(int i=0;i<rosters.length();i++){
            JSONObject roster=rosters.optJSONObject(i);if(roster==null)continue;
            JSONObject team=roster.optJSONObject("team");String name=team==null?Settings.t(this,"الفريق","Team"):team.optString("displayName",Settings.t(this,"الفريق","Team"));
            JSONArray players=roster.optJSONArray("roster");if(players==null)players=roster.optJSONArray("athletes");if(players==null)continue;
            LinearLayout card=U.card(this);U.pad(card,15);card.addView(U.heading(this,name));
            int valid=0;
            for(int k=0;k<players.length();k++){
                JSONObject element=players.optJSONObject(k);if(element==null)continue;
                JSONObject player=element.optJSONObject("athlete");if(player==null)player=element;
                String display=player.optString("displayName",player.optString("fullName",""));if(display.isEmpty())continue;
                String jersey=element.optString("jersey",player.optString("jersey",""));
                String starter=element.optBoolean("starter",false)?"● ":"";
                TextView row=U.txt(this,starter+(jersey.isEmpty()?"":jersey+"  ")+display,15,false,U.text(this));U.pad(row,4,10,4,10);card.addView(row);U.line(card);valid++;
            }
            if(valid>0){content.addView(card);U.space(content,13);displayed++;}
        }
        if(displayed==0)empty(Settings.t(this,"لم يتم إعلان التشكيل بعد.","Lineups have not been published."));
    }
    private void headToHead() {
        LinearLayout overview = U.card(this);
        U.pad(overview,10);
        overview.addView(U.heading(this,Settings.t(this,"المواجهات السابقة","Head-to-head")));
        List<Match> previous = FotMob.history(data,m);
        List<Match> visible = new ArrayList<>();
        for (Match match : previous) {
            if (historyHome && !Objects.equals(m.homeId,match.homeId)) continue;
            if (historyLeague && !Objects.equals(m.leagueId,match.leagueId)) continue;
            visible.add(match);
        }
        int[] counts = FotMob.historyCounts(visible,m);
        int total = counts[0]+counts[1]+counts[2];
        if (total > 0) {
            LinearLayout counters = U.row(this);
            counters.addView(historyCount(counts[0],m.homeLogo,Settings.t(this,"فوز ","Wins · ")+Club.name(this,m.home)),U.weight(this,1));
            counters.addView(historyCount(counts[1],null,Settings.t(this,"تعادل","Draws")),U.weight(this,1));
            counters.addView(historyCount(counts[2],m.awayLogo,Settings.t(this,"فوز ","Wins · ")+Club.name(this,m.away)),U.weight(this,1));
            overview.addView(counters,U.lp(this,-1,-2));
            U.space(overview,8);
            LinearLayout bar = U.row(this);
            bar.setBackground(U.shape(U.elevated(this),6,this));
            bar.setClipToOutline(true);
            int[] colors = {0xFF65AAD3,U.border(this),U.iceLine()};
            for (int i=0;i<counts.length;i++) {
                if (counts[i] == 0) continue;
                View segment = new View(this);
                segment.setBackgroundColor(colors[i]);
                bar.addView(segment,new LinearLayout.LayoutParams(0,U.dp(this,8),counts[i]));
            }
            bar.setContentDescription(Settings.t(this,"نسب الفوز والتعادل","Win and draw proportions"));
            overview.addView(bar,U.lp(this,-1,8));
            U.space(overview,9);
        }
        LinearLayout filters = U.row(this);
        String homeLabel = Club.name(this,m.home);
        TextView homeOnly = U.chip(this,Settings.t(this,"ملعب ","Home · ")+homeLabel,historyHome);
        TextView sameLeague = U.chip(this,Settings.t(this,"نفس البطولة","Same competition"),historyLeague);
        homeOnly.setMaxLines(2);
        sameLeague.setMaxLines(2);
        U.pad(homeOnly,3,4,3,4);
        U.pad(sameLeague,3,4,3,4);
        homeOnly.setOnClickListener(v -> { historyHome=!historyHome; render(); });
        sameLeague.setOnClickListener(v -> { historyLeague=!historyLeague; render(); });
        filters.addView(homeOnly,new LinearLayout.LayoutParams(0,U.dp(this,42),1));
        filters.addView(new View(this),U.lp(this,6,1));
        filters.addView(sameLeague,new LinearLayout.LayoutParams(0,U.dp(this,42),1));
        overview.addView(filters,U.lp(this,-1,-2));
        content.addView(overview,U.lp(this,-1,-2));
        U.space(content,8);
        if (visible.isEmpty()) {
            empty(previous.isEmpty() ? Settings.t(this,"سجل المواجهات غير متاح لهذه المباراة","Head-to-head data is unavailable")
                : Settings.t(this,"لا توجد مواجهات تطابق الفلاتر","No meetings match the filters"));
            return;
        }
        content.addView(U.heading(this,Settings.t(this,"آخر المواجهات","Recent meetings")));
        ScoresCards cards = new ScoresCards(this,new ScoresStyle(this));
        for (Match match : visible) {
            LinearLayout row = U.card(this);
            U.pad(row,4);
            TextView meta = U.txt(this,historyDate(match) + " · " + competition(match),11,true,U.sub(this));
            U.pad(meta,7,6,7,5);
            row.addView(meta,U.lp(this,-1,-2));
            row.addView(cards.result(match,true),U.lp(this,-1,-2));
            content.addView(row,U.lp(this,-1,-2));
            U.space(content,6);
        }
    }

    private View historyCount(int count,String logo,String label) {
        LinearLayout cell = U.col(this);
        cell.setGravity(Gravity.CENTER);
        if (hasValue(logo)) cell.addView(U.logo(this,logo,24));
        else U.space(cell,24);
        TextView number = U.txt(this,Integer.toString(count),23,true,U.text(this));
        number.setGravity(Gravity.CENTER);
        cell.addView(number,U.lp(this,-1,31));
        TextView title = U.txt(this,label,11,true,U.sub(this));
        title.setGravity(Gravity.CENTER);
        title.setMaxLines(2);
        cell.addView(title,U.lp(this,-1,31));
        return cell;
    }

    private String historyDate(Match match) {
        Locale locale = Settings.ar(this) ? new Locale("ar","EG") : Locale.ENGLISH;
        return java.time.format.DateTimeFormatter.ofPattern("d MMM uuuu",locale).withZone(ScoreRepository.CAIRO)
            .format(ScoreRepository.kickoff(match.isoDate));
    }

    private String competition(Match match) {
        if (match.leagueId.startsWith("fotmob.") && hasValue(match.competitionName)) return match.competitionName;
        return League.byId(match.leagueId).name(this);
    }

    private void table(){
        content.addView(U.heading(this,Settings.t(this,"ترتيب البطولة","League table")));
        if(tableLoading){ProgressBar pb=new ProgressBar(this);content.addView(pb);return;}
        if(standings.isEmpty()){empty(Settings.t(this,"الترتيب غير متاح لهذه البطولة.","Standings aren't available for this league."));return;}
        LinearLayout card=U.card(this);U.pad(card,10);
        for(int i=0;i<standings.size();i++){
            Standing entry=standings.get(i);LinearLayout row=U.row(this);U.pad(row,6,10,6,10);
            TextView pos=U.txt(this,""+(i+1),11,true,U.sub(this));row.addView(pos,U.lp(this,26,-2));
            ImageView badge=U.logo(this,entry.logo,22);row.addView(badge);
            TextView team=U.txt(this," "+entry.name,12,true,U.text(this));team.setSingleLine();row.addView(team,new LinearLayout.LayoutParams(0,-2,1));
            TextView points=U.txt(this,entry.points,12,true,U.accent(this));points.setGravity(Gravity.CENTER);row.addView(points,U.lp(this,34,-2));
            card.addView(row);row.setOnClickListener(v->U.openTeam(this,entry.id,entry.name,entry.logo,m.leagueId));U.line(card);
        }
        content.addView(card);
        TextView full=U.txt(this,Settings.t(this,"فتح صفحة البطولة  ›","Open league page  ›"),14,true,U.accent(this));U.pad(full,9,17,9,10);content.addView(full);
        full.setOnClickListener(v->{Intent i=new Intent(this,LeagueActivity.class);i.putExtra("league",m.leagueId);startActivity(i);});
    }
    private void loadTable(){tableLoading=true;render();new Thread(()->{java.time.LocalDate matchDay = null;
        try { matchDay = ScoreRepository.kickoff(m.isoDate).atZone(java.time.ZoneId.systemDefault()).toLocalDate(); }
        catch (java.time.DateTimeException | NullPointerException ignored) {}
        List<Standing> rows=ScoreRepository.standings(getApplicationContext(),m.leagueId,matchDay,false);
        runOnUiThread(()->{standings=rows;tableLoading=false;if(section==5)render();});},"table-loader").start();}
    private void detailLine(LinearLayout card,String label,String value){
        LinearLayout row=U.row(this);U.pad(row,0,9,0,9);
        TextView left=U.txt(this,label,13,false,U.sub(this));row.addView(left,new LinearLayout.LayoutParams(0,-2,1));
        TextView right=U.txt(this,value==null?"":value,13,true,U.text(this));right.setGravity(Gravity.END);right.setMaxLines(2);row.addView(right,new LinearLayout.LayoutParams(0,-2,1));
        card.addView(row);U.line(card);
    }
    private void empty(String message){LinearLayout card=U.card(this);U.pad(card,18,27,18,27);
        TextView text=U.txt(this,message,13,false,U.sub(this));text.setGravity(Gravity.CENTER);card.addView(text);content.addView(card);}
}
