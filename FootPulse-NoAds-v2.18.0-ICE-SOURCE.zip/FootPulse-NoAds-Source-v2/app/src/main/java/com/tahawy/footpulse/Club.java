package com.tahawy.footpulse;

import android.content.Context;
import java.util.Locale;
import java.util.Map;
import java.util.LinkedHashMap;

final class Club {
    private static final Map<String,String> ARABIC_NAMES = new LinkedHashMap<>();
    static {
        ARABIC_NAMES.put("zamalek","الزمالك");
        ARABIC_NAMES.put("zamalek sc","الزمالك");
        ARABIC_NAMES.put("real madrid","ريال مدريد");
        ARABIC_NAMES.put("manchester united","مانشستر يونايتد");
        ARABIC_NAMES.put("manchester city","مانشستر سيتي");
        ARABIC_NAMES.put("man utd","مانشستر يونايتد");
        ARABIC_NAMES.put("man city","مانشستر سيتي");
        ARABIC_NAMES.put("al ahly","الأهلي");
        ARABIC_NAMES.put("al ahly sc","الأهلي");
        ARABIC_NAMES.put("al ahly fc","الأهلي");
        ARABIC_NAMES.put("barcelona","برشلونة");
        ARABIC_NAMES.put("pyramids fc","بيراميدز");
        ARABIC_NAMES.put("pyramids","بيراميدز");
        ARABIC_NAMES.put("ghazl el mahalla","غزل المحلة");
        ARABIC_NAMES.put("ghazl al mahalla","غزل المحلة");
        ARABIC_NAMES.put("ghazl el mahalla sc","غزل المحلة");
        ARABIC_NAMES.put("ghazl el mahallah","غزل المحلة");
        ARABIC_NAMES.put("asyut petroleum","بترول أسيوط");
        ARABIC_NAMES.put("assiut petroleum","بترول أسيوط");
        ARABIC_NAMES.put("asyut petroleum sc","بترول أسيوط");
        ARABIC_NAMES.put("petroleum assiut","بترول أسيوط");
        ARABIC_NAMES.put("ismaily sc","الإسماعيلي");
        ARABIC_NAMES.put("ismaily","الإسماعيلي");
        ARABIC_NAMES.put("al masry","المصري");
        ARABIC_NAMES.put("al masry sc","المصري");
        ARABIC_NAMES.put("smouha sc","سموحة");
        ARABIC_NAMES.put("smouha","سموحة");
        ARABIC_NAMES.put("enppi","إنبي");
        ARABIC_NAMES.put("national bank","البنك الأهلي");
        ARABIC_NAMES.put("national bank of egypt","البنك الأهلي");
        ARABIC_NAMES.put("el gouna fc","الجونة");
        ARABIC_NAMES.put("el gouna","الجونة");
        ARABIC_NAMES.put("modern sport fc","مودرن سبورت");
        ARABIC_NAMES.put("modern sport","مودرن سبورت");
        ARABIC_NAMES.put("tala'ea el gaish","طلائع الجيش");
        ARABIC_NAMES.put("el geish","طلائع الجيش");
        ARABIC_NAMES.put("al ittihad alexandria","الاتحاد السكندري");
        ARABIC_NAMES.put("al mokawloon al arab","المقاولون العرب");
        ARABIC_NAMES.put("arab contractors","المقاولون العرب");
        ARABIC_NAMES.put("wadi degla","وادي دجلة");
        ARABIC_NAMES.put("haras el hodoud","حرس الحدود");
        ARABIC_NAMES.put("petrojet","بتروجت");
        ARABIC_NAMES.put("zed fc","زد");
        ARABIC_NAMES.put("zed","زد");
        ARABIC_NAMES.put("we sc","المصرية للاتصالات");
        ARABIC_NAMES.put("telecom egypt","المصرية للاتصالات");
        ARABIC_NAMES.put("ceramica cleopatra","سيراميكا كليوباترا");
        ARABIC_NAMES.put("atletico madrid","أتلتيكو مدريد");
        ARABIC_NAMES.put("sevilla","إشبيلية");
    }

    final String id, name, league;
    Club(String id, String name, String league) {
        this.id = id;
        this.name = name;
        this.league = league;
    }

    static String name(Context c,String name) {
        if (name == null) return "";
        return Settings.ar(c) ? ARABIC_NAMES.getOrDefault(normalize(name),name) : name;
    }

    static String query(String input) {
        String value = normalize(input);
        if (value.equals("مانشستر")) return "manchester";
        if (value.equals("زمالك")) return "zamalek";
        for (Map.Entry<String,String> entry : ARABIC_NAMES.entrySet()) {
            if (value.equals(normalize(entry.getValue()))) return entry.getKey().replaceFirst(" sc$","");
        }
        return value;
    }

    boolean matches(String query) {
        String normalized = normalize(name);
        String localized = ARABIC_NAMES.getOrDefault(normalized,"");
        return normalized.contains(query) || normalize(localized).contains(query) ||
            (!localized.isEmpty() && query(localized).equals(query)) ||
            (normalized.equals("man utd") && "manchester united".contains(query)) ||
            (normalized.equals("man city") && "manchester city".contains(query));
    }

    private static String normalize(String value) {
        return java.text.Normalizer.normalize(value.trim(),java.text.Normalizer.Form.NFD)
            .replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);
    }
}
