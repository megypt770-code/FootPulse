# Changelog

## 2.18.0

- تصميم قائمة المباريات المختصر مع ترتيب الفريقين رأسيًا وعمود للحالة والموعد.
- متابعة البطولة من التقويم وتفاصيل المباراة وتفعيل عرضها تلقائيًا. دعم البحث عن أمم أوروبا وصيغ الاسم الشائعة.

## 2.17.0

- إزالة فلاتر الحالة من الرئيسية وعرض مباريات التاريخ المختار معًا في أقسام البطولات.

## 2.16.0

- إعادة تصميم صفحة الفريق بهوية مختصرة وبطاقة زرقاء للمباراة القادمة ومواعيد مضغوطة.
- إظهار الموعد مرة واحدة وتعريب أسماء الأندية المعروفة حسب لغة التطبيق.

## 2.15.0

- الواجهة الجليدية للرئيسية مع رسم الكرة وكارت مباراة مميزة وكروت مواعيد اليوم والمباشر عند توفره.
- الألوان الزرقاء والكروت الزجاجية وشريط التنقل الموحّد لشاشات التفاصيل والتقويم والدوريات والمتابعة والإعدادات.
- المظهر الأزرق الداكن هو الافتراضي ويمكن اختيار النسخة الفاتحة من الإعدادات.
- توقيع APK مطابق لإصدار 2.14.0.

## 2.14.0

- تقويم شهري بلوحة سفلية، مع أهم مباريات اليوم المختار وشعارات ما يصل إلى ثلاث بطولات يختارها المستخدم.
- كارت الاستاد وملخص المواجهات السابقة وفلترة سجل المواجهات حسب الأرض والبطولة.
- إزالة قسم الأخبار ومصادره وتبويبه، بما في ذلك صفحة البطولة.
- توقيع APK مطابق لإصدار 2.13.0.

## 2.13.0

- تصميم «إضاءة كهرمانية» لشاشات المباريات وتفاصيل المباراة والمتابعة.
- مواعيد وفلاتر أعلى القائمة وأقسام بطولات حسب التاريخ.
- كارت ملعب بألوان كهرمانية، شريط استحواذ وملخص أحداث مع ألوان الإنذار والطرد.
- بحث أندية داخل صفحة المتابعة مع أحدث المتابعات وأقرب مباراة.
- نفس حزمة وتوقيع إصدار 2.12.0.

## 2.12.0

- بطولات قائمة النتائج تأتي من المباريات المعروضة بدل الاختصارات الثابتة.
- البحث عن نادٍ من المتابعة مستقل عن مباريات اليوم ويدعم الأسماء العربية الشائعة.
- شريط التنقل متاح في قائمة المباريات الكاملة، ويستعيد اليوم وموضع التمرير عند التنقل.
- عرض رموز الإنذار والطرد والتبديل وتعريب مسميات الأحداث والإحصائيات الشائعة.
- متابعة أحداث المباراة من جرس صفحة التفاصيل مع خدمة مراقبة ظاهرة في الإشعارات.

## 2.11.0

- أعيد ترتيب الرئيسية والتفاصيل وشريط التنقل العائم وفق الصورة المرجعية.
- دليل القنوات من FotMob للشرق الأوسط وفيلجول ويلا كورة، مع اسم مصدر كل قناة في تفاصيل المباراة.
- الملعب يعرض فريقًا واحدًا في المرة مع تبديل الفريق وعرض صور اللاعبين وتقييماتهم عند توفرها.
- توقيع APK مطابق لتوقيع 2.10.0.

## 2.10.0

- مظهر زجاجي أزرق للشاشات والقوائم في الوضعين الفاتح والداكن.
- شريط تواريخ في الرئيسية وأقسام منفصلة للمباشر والقادمة والنتائج.
- بطاقة نتيجة سداسية وتبويبات دائرية وملعب للتشكيلة بصور اللاعبين عند توفرها.
- أشرطة إحصائيات متقابلة من بيانات المباراة.

## 2.8.0

- المباراة القادمة أولًا: «أبرز المباريات» ترتّب المباشر ثم القادمة (فرق المتابعة والبطولات المثبّتة أولًا)، والمنتهية في الآخر. لو انتهت مباريات اليوم تظهر مباريات أقرب يوم قادم، مع «غدًا» أو التاريخ على الكارت.
- صفحة البطولة تفتح على تبويب المباريات وتنتقل تلقائيًا لأقرب يوم فيه مباراة قادمة، وزر «أقرب يوم» يفضّل القادم على الماضي.
- صفحة الفريق: المباراة القادمة مميّزة في الأعلى بالتاريخ والموعد، ثم باقي القادمة، ثم النتائج السابقة.
- القنوات الناقلة للشرق الأوسط تظهر على كروت المباريات القادمة وفي صفحة الفريق وأعلى ملخص المباراة، مع حفظ بلد البث المختار (مصر افتراضيًا) ومطابقة أكثر مرونة للأسماء والموعد.

## 2.7.0

- صفحات إحصائيات FotMob للاعبين والفرق مع اختيار الموسم، وأفضل ثلاثة وعرض الترتيب الكامل داخل التطبيق.
- تصفيات دوري أبطال أوروبا، وصور وتقييمات اللاعبين في التشكيلات المتاحة.
- دليل بث منفصل من Live Soccer TV للشرق الأوسط حسب الدولة، مع مطابقة اسمي الفريقين وموعد المباراة.
- كروت بنفس الترتيب والأبعاد في اللايت والدارك وخط أكبر للأسماء والقيم.

## 2.6.0

- Moved fixtures, standings, crests, match details, historic seasons, head-to-head and news to FotMob public pages.
- Show match data and news summaries inside the app, with no external data buttons.
- Reuse the same card layouts in light and dark modes, with theme-specific colors.

## 2.5.0

- Adopted the approved blue football logo and high-contrast black and lime theme.
- Added Egyptian Premier League and Egypt Cup fixtures and results from FotMob public pages, with standings, lineups, statistics and events when available.
- Added source links and navigation to the nearest available Egyptian matchday.

## 2.4.0

- Rebuilt the match home and Live Score screens around the reference layout in daylight and dark modes.
- Added team search, seven day selectors, league chips and all/live/followed filtering to Live Score.
- Retained the lineup pitch and live match detail screen.

## 2.3.0

- Added a tactical pitch with jersey markers, formations and a short match timeline.
- Match details refresh while open, and show the time of the last successful response.
- Added a Champions League shortcut and a featured match card.

## 2.2.0

- Rebuilt the daylight match screen with a baby-blue palette, two-line date cells and centred status and score tiles.
- Added Egyptian and international news from FilGoal, BBC Sport and The Guardian alongside ESPN.
- Improved kickoff and score parsing, league badge support and bounded cache fallback.

## 2.1.0

- Added coordinated light and dark palettes and a five-section navigation bar.
- Restyled match dates, filters, status badges and competition cards.
- Added featured news, latest news and league filtering using the existing news feed.
- Added league search and a two-column followed-team grid with provider fixtures when available.
- Moved language, appearance and match options into Settings under More.

## 2.0.0

- Seven-day fixture strip and calendar.
- Pinned leagues and collapsible match groups.
- Expanded selectable competition directory.
- Six-tab match center with statistics comparison and conditional head-to-head.
- Dedicated team profile and team schedule.
- League fixtures date navigation and league news.
- Score snapshot homescreen widget.
- Compact match list setting; richer news cards.
- Favorite team key scoped to the competition; optional score alerts fixed to derive league from followed teams.
- Same package `com.tahawy.footpulse` with incremented version code.
- Remains ad-free, with no analytics SDK and no access to original FotMob source or assets.
