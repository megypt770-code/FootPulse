package org.gradle.wrapper;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Small auditable Gradle bootstrapper included because no official wrapper binary was available. */
public final class GradleWrapperMain {
    private static final String VERSION="8.9";
    private static final String URI="https://services.gradle.org/distributions/gradle-"+VERSION+"-bin.zip";
    public static void main(String[] args) throws Exception {
        Path home=Paths.get(System.getProperty("user.home"),".gradle","wrapper","dists","gradle-"+VERSION+"-bin","footpulse");
        Path gradle=home.resolve("gradle-"+VERSION);
        boolean windows=System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        Path launcher=gradle.resolve(windows?"bin/gradle.bat":"bin/gradle");
        if(!Files.exists(launcher)){
            Files.createDirectories(home);
            Path archive=home.resolve("gradle-"+VERSION+"-bin.zip");
            if(!Files.exists(archive)){
                System.out.println("Downloading Gradle " + VERSION + " from services.gradle.org ...");
                Path temp=home.resolve("download.part");
                URLConnection conn=new URL(URI).openConnection();
                conn.setConnectTimeout(20000);conn.setReadTimeout(60000);
                try(InputStream in=conn.getInputStream();OutputStream out=Files.newOutputStream(temp)){
                    byte[] buffer=new byte[32768];int n;
                    while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
                }
                Files.move(temp,archive,StandardCopyOption.REPLACE_EXISTING);
            }
            try(ZipInputStream zip=new ZipInputStream(Files.newInputStream(archive))){
                ZipEntry entry;
                while((entry=zip.getNextEntry())!=null){
                    Path target=home.resolve(entry.getName()).normalize();
                    if(!target.startsWith(home))throw new IOException("Invalid ZIP entry");
                    if(entry.isDirectory())Files.createDirectories(target);
                    else{Files.createDirectories(target.getParent());Files.copy(zip,target,StandardCopyOption.REPLACE_EXISTING);}
                    zip.closeEntry();
                }
            }
            if(!windows)launcher.toFile().setExecutable(true);
        }
        List<String> command=new ArrayList<>();
        if(windows){command.add("cmd");command.add("/c");}
        command.add(launcher.toAbsolutePath().toString());command.addAll(Arrays.asList(args));
        ProcessBuilder pb=new ProcessBuilder(command).inheritIO();
        int result=pb.start().waitFor();
        if(result!=0)System.exit(result);
    }
}
